param([string]$NdkHome=(Join-Path $env:LOCALAPPDATA 'Android\Sdk\ndk\29.0.13599879'))
$ErrorActionPreference='Stop'
& python (Join-Path $PSScriptRoot 'tools\translate.py')
if($LASTEXITCODE -ne 0){throw 'HPX source translation failed'}
& python (Join-Path $PSScriptRoot 'tools\generate_adapter.py')
if($LASTEXITCODE -ne 0){throw 'HPX input generation failed'}
$build=Join-Path $PSScriptRoot 'build'
New-Item -ItemType Directory -Force -Path $build | Out-Null
$output=Join-Path $build 'libhpxzwave.so'
$clang=Join-Path $NdkHome 'toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe'
$exports=Join-Path $PSScriptRoot 'native\exports.map'
# Every loaded module/classloader owns its C++ runtime. Archive symbols must not
# interpose on MetaQuotes or another copy; only the three C JNI methods cross ABI.
& $clang --target=aarch64-linux-android26 -std=c++17 -O2 -shared -fPIC -fvisibility=hidden -fstack-protector-strong '-Wl,-z,relro,-z,now,-z,noexecstack' '-Wl,--build-id=none' '-Wl,--exclude-libs,ALL' ('-Wl,--version-script='+$exports) '-Wl,--no-undefined-version' -static-libstdc++ (Join-Path $PSScriptRoot 'native\bridge.cpp') -o $output
if($LASTEXITCODE -ne 0){throw 'HPX ARM64 compilation failed'}
$symbols=& (Join-Path $NdkHome 'toolchains\llvm\prebuilt\windows-x86_64\bin\llvm-readelf.exe') --dyn-syms --wide $output
if($LASTEXITCODE -ne 0){throw 'HPX JNI export verification failed'}
$defined=@()
foreach($line in $symbols){if($line -match '^\s*\d+:\s+[0-9a-f]+\s+\d+\s+\S+\s+(GLOBAL|WEAK)\s+\S+\s+(\S+)\s+(\S+)\s*$' -and $Matches[2] -ne 'UND'){$defined+=$Matches[3]}}
$expected=@('Java_converted_hpxzwave_HPXZwave_nativeCreate','Java_converted_hpxzwave_HPXZwave_nativeDestroy','Java_converted_hpxzwave_HPXZwave_nativeRender')
if($defined.Count -ne 3 -or @(Compare-Object ($defined|Sort-Object) ($expected|Sort-Object)).Count -ne 0){throw ('HPX payload leaks symbols outside JNI: '+($defined -join ', '))}
Write-Output 'HPX native ABI verified: exactly three JNI exports; C++ runtime symbols isolated.'
& (Join-Path $NdkHome 'toolchains\llvm\prebuilt\windows-x86_64\bin\llvm-strip.exe') --strip-unneeded $output
if($LASTEXITCODE -ne 0){throw 'HPX payload strip failed'}
& python (Join-Path $PSScriptRoot 'tools\embed_payload.py') $output
if($LASTEXITCODE -ne 0){throw 'HPX payload embedding failed'}
