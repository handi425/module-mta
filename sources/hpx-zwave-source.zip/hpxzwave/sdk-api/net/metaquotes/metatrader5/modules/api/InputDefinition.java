package net.metaquotes.metatrader5.modules.api;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Typed editable input; values cross the module boundary as normalized strings. */
public final class InputDefinition {
    public enum Type { INTEGER, DECIMAL, BOOLEAN, TEXT, COLOR, CHOICE }
    public final String key, label, defaultValue;
    public final Type type;
    public final double min, max;
    public final List<String> options;

    public InputDefinition(String key, String label, Type type, String defaultValue,
                           double min, double max, List<String> options) {
        if (key == null || !key.matches("[A-Za-z][A-Za-z0-9_]{0,47}") || label == null ||
                label.isEmpty() || label.length() > 96 || type == null || !finite(min) || !finite(max) || min > max)
            throw new IllegalArgumentException("Invalid input definition");
        this.key = key; this.label = label; this.type = type; this.min = min; this.max = max;
        List<String> choices = options == null ? new ArrayList<String>() : new ArrayList<String>(options);
        if (choices.size() > 64 || (type == Type.CHOICE && choices.isEmpty()))
            throw new IllegalArgumentException("Invalid input choices");
        for (String option : choices) if (option == null || option.isEmpty() || option.length() > 128)
            throw new IllegalArgumentException("Invalid input choice");
        if (new java.util.HashSet<String>(choices).size() != choices.size())
            throw new IllegalArgumentException("Duplicate input choice");
        this.options = Collections.unmodifiableList(choices);
        this.defaultValue = validate(defaultValue);
    }

    public static InputDefinition integer(String key, String label, int value, int min, int max) {
        return new InputDefinition(key, label, Type.INTEGER, String.valueOf(value), min, max, null);
    }
    public static InputDefinition decimal(String key, String label, double value, double min, double max) {
        return new InputDefinition(key, label, Type.DECIMAL, String.valueOf(value), min, max, null);
    }
    public static InputDefinition bool(String key, String label, boolean value) {
        return new InputDefinition(key, label, Type.BOOLEAN, String.valueOf(value), 0, 1, null);
    }
    public static InputDefinition text(String key, String label, String value) {
        return new InputDefinition(key, label, Type.TEXT, value, 0, 256, null);
    }
    public static InputDefinition color(String key, String label, int argb) {
        return new InputDefinition(key, label, Type.COLOR, String.format(Locale.ROOT, "#%08X", argb), 0, 0, null);
    }
    public static InputDefinition choice(String key, String label, String value, String... options) {
        return new InputDefinition(key, label, Type.CHOICE, value, 0, 0, java.util.Arrays.asList(options));
    }

    public String validate(String raw) {
        if (raw == null || raw.length() > 256) throw new IllegalArgumentException("Invalid value for " + key);
        String value = raw.trim();
        switch (type) {
            case INTEGER: {
                int number;
                try { number = Integer.parseInt(value); } catch (NumberFormatException error) {
                    throw new IllegalArgumentException(label + " must be an integer");
                }
                if (number < min || number > max) throw new IllegalArgumentException(label + " is outside its range");
                return String.valueOf(number);
            }
            case DECIMAL: {
                double number;
                try { number = Double.parseDouble(value); } catch (NumberFormatException error) {
                    throw new IllegalArgumentException(label + " must be numeric");
                }
                if (!finite(number) || number < min || number > max)
                    throw new IllegalArgumentException(label + " is outside its range");
                return Double.toString(number);
            }
            case BOOLEAN:
                if (!value.equals("true") && !value.equals("false")) throw new IllegalArgumentException(label + " must be true or false");
                return value;
            case COLOR: return String.format(Locale.ROOT, "#%08X", parseColor(value));
            case CHOICE:
                if (!options.contains(value)) throw new IllegalArgumentException("Unsupported " + label);
                return value;
            case TEXT: return raw;
            default: throw new IllegalArgumentException("Unsupported input type");
        }
    }

    public static int parseColor(String value) {
        if (value == null || !value.matches("#[0-9A-Fa-f]{6}([0-9A-Fa-f]{2})?"))
            throw new IllegalArgumentException("Color must be #RRGGBB or #AARRGGBB");
        long color = Long.parseLong(value.substring(1), 16);
        return (int) (value.length() == 7 ? color | 0xff000000L : color);
    }
    private static boolean finite(double value) { return !Double.isNaN(value) && !Double.isInfinite(value); }
}
