package net.metaquotes.metatrader5.modules.api;

/** Declarative native-builtin plot; the host performs the audited native translation. */
public final class IndicatorSpec {
    public enum Kind { MOVING_AVERAGE, RELATIVE_STRENGTH_INDEX }
    public enum Window { MAIN, SEPARATE }
    public final String plotId;
    public final Kind kind;
    public final Window window;
    public final int period, shift, method, appliedPrice, colorARGB, width, style;
    public PlotFrame.Oscillator oscillator;

    public IndicatorSpec(String plotId, Kind kind, Window window, int period, int shift, int method,
                         int appliedPrice, int colorARGB, int width, int style) {
        if (plotId == null || !plotId.matches("[A-Za-z][A-Za-z0-9_]{0,31}") || kind == null || window == null ||
                period < 1 || period > 10000 || shift < -1000 || shift > 1000 || method < 0 || method > 3 ||
                appliedPrice < 0 || appliedPrice > 6 || width < 1 || width > 5 || style < 1 || style > 3)
            throw new IllegalArgumentException("Unsupported indicator specification");
        this.plotId = plotId; this.kind = kind; this.window = window; this.period = period; this.shift = shift;
        this.method = method; this.appliedPrice = appliedPrice; this.colorARGB = colorARGB; this.width = width; this.style = style;
    }
    public static IndicatorSpec movingAverage(int period, int shift, int method, int appliedPrice,
                                              int colorARGB, int width, int style) {
        return new IndicatorSpec("main", Kind.MOVING_AVERAGE, Window.MAIN, period, shift, method, appliedPrice, colorARGB, width, style);
    }
    public static IndicatorSpec relativeStrengthIndex(PlotFrame.Oscillator oscillator){
        IndicatorSpec spec=new IndicatorSpec("rsi",Kind.RELATIVE_STRENGTH_INDEX,Window.SEPARATE,oscillator.period,0,0,oscillator.appliedPrice,oscillator.color,oscillator.width,3);
        spec.oscillator=oscillator;return spec;
    }
}
