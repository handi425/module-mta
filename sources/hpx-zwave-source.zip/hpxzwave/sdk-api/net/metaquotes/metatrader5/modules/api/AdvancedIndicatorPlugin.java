package net.metaquotes.metatrader5.modules.api;
import java.util.Map;
/** Trusted Java port, executed with host-app privileges; this is not a sandbox. */
public interface AdvancedIndicatorPlugin extends IndicatorPlugin {
    @Override default IndicatorSpec create(Map<String, String> inputs) throws Exception { return null; }
    void onChartUpdate(ModuleEnvironment environment, ChartData chart, Map<String, String> inputs) throws Exception;
    void onDetach(ModuleEnvironment environment, int chartId) throws Exception;
}
