package net.metaquotes.metatrader5.modules.api;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
/** Immutable OHLC snapshot; closedBars excludes the current forming candle. */
public final class ChartData {
    public final int chartId, period;
    public final String server, symbol;
    public final List<Bar> closedBars;
    public final Bar formingBar;
    public final int digits,periodSeconds;
    public final double point;
    public final double tickSize;
    public final String currencyBase,currencyProfit;
    public final int backgroundColor;
    public final long quoteTime;
    private final Map<Integer,List<Bar>> histories;
    public ChartData(int chartId, String server, String symbol, int period, List<Bar> closedBars) {
        this(chartId,server,symbol,period,closedBars,null,5,seconds(period),0,Collections.<Integer,List<Bar>>emptyMap());
    }
    public ChartData(int chartId,String server,String symbol,int period,List<Bar> closedBars,Bar formingBar,int digits,int periodSeconds,long quoteTime,Map<Integer,List<Bar>> histories) {
        this(chartId,server,symbol,period,closedBars,formingBar,digits,periodSeconds,quoteTime,histories,Math.pow(10,-digits),"","",0xff000000);
    }
    public ChartData(int chartId,String server,String symbol,int period,List<Bar> closedBars,Bar formingBar,int digits,int periodSeconds,long quoteTime,Map<Integer,List<Bar>> histories,double tickSize,String currencyBase,String currencyProfit,int backgroundColor) {
        if (chartId < 0 || server == null || symbol == null || period <= 0 || closedBars == null || closedBars.size() > 100000)
            throw new IllegalArgumentException("Invalid chart snapshot");
        List<Bar> copy = new ArrayList<Bar>(closedBars);
        long previous = 0;
        for (Bar bar : copy) {
            if (bar == null || bar.time <= previous) throw new IllegalArgumentException("Bars must be time ordered");
            previous = bar.time;
        }
        this.chartId = chartId; this.server = server; this.symbol = symbol; this.period = period;
        this.closedBars = Collections.unmodifiableList(copy);
        if(formingBar!=null&&formingBar.time<=previous)throw new IllegalArgumentException("Forming bar must follow closed history");
        this.formingBar=formingBar;this.digits=digits;this.periodSeconds=periodSeconds;this.point=Math.pow(10,-digits);this.quoteTime=quoteTime;
        this.tickSize=tickSize;this.currencyBase=currencyBase;this.currencyProfit=currencyProfit;this.backgroundColor=backgroundColor;
        this.histories=new HashMap<Integer,List<Bar>>();
        for(Map.Entry<Integer,List<Bar>> e:histories.entrySet())this.histories.put(e.getKey(),Collections.unmodifiableList(new ArrayList<Bar>(e.getValue())));
    }
    public List<Bar> allBars(){List<Bar> out=new ArrayList<Bar>(closedBars);if(formingBar!=null)out.add(formingBar);return Collections.unmodifiableList(out);}
    public List<Bar> history(int period){List<Bar> bars=histories.get(period);return bars==null?Collections.<Bar>emptyList():bars;}
    private static int seconds(int p){if(p<16384)return p*60;if(p<32768)return (p-16384)*3600;if(p==32769)return 604800;if(p==49153)return 2592000;return 0;}
    public static final class Bar {
        public final long time;
        public final double open, high, low, close;
        public final long tickVolume,realVolume;
        public Bar(long time, double open, double high, double low, double close) {
            this(time,open,high,low,close,0,0);
        }
        public Bar(long time,double open,double high,double low,double close,long tickVolume,long realVolume) {
            if (time <= 0 || !finite(open) || !finite(high) || !finite(low) || !finite(close) ||
                    high < low || open < low || open > high || close < low || close > high)
                throw new IllegalArgumentException("Invalid OHLC bar");
            this.time = time; this.open = open; this.high = high; this.low = low; this.close = close;
            if(tickVolume<0||realVolume<0)throw new IllegalArgumentException("Invalid volume");
            this.tickVolume=tickVolume;this.realVolume=realVolume;
        }
        private static boolean finite(double value) { return !Double.isNaN(value) && !Double.isInfinite(value); }
    }
}
