package net.metaquotes.metatrader5.modules.api;
import java.util.Map;
public interface IndicatorPlugin {
    ModuleDescriptor describe();
    IndicatorSpec create(Map<String, String> inputs) throws Exception;
}
