package net.metaquotes.metatrader5.modules.api;
/** An explicit chart control event. It never describes an order or trade action. */
public final class ChartEvent {
    public final String type,key;public final long time;public final double price;
    public ChartEvent(String type,String key,long time,double price){this.type=type;this.key=key;this.time=time;this.price=price;}
}
