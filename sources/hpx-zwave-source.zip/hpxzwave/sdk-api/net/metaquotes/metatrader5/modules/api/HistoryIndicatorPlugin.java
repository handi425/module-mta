package net.metaquotes.metatrader5.modules.api;
import java.util.Map;
/** Declares native history leases; callbacks still receive immutable snapshots only. */
public interface HistoryIndicatorPlugin extends AdvancedIndicatorPlugin {
    int[] historyPeriods(Map<String,String> inputs);
    int historyBars(Map<String,String> inputs);
}
