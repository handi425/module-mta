"""Generate visible inputs while retaining the original 65-slot native protocol."""
from pathlib import Path
import re,json
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'original/HPX/Indicators/HPX_Zwave_Pro.mq5').read_text(encoding='utf-8-sig')
inputs=re.findall(r'^input\s+(double|int|bool|color|string|ZWBaseDegree|ZWTargetDegree)\s+(\w+)\s*=\s*(.*?);\s*(?://\s*(.*))?$',s,re.M)
assert len(inputs)>60
ranges={
'InpLargeReversal':(.00001,100),'InpSubwaveDivisor':(1.0000000001,20),'InpLargeDepth':(2,200),'InpChildDepth':(2,100),
'InpHistoryBars':(100,10000),'InpVisibleLargePivots':(2,100),'InpRecentPatterns':(1,5),'InpHierarchyDepth':(4,16),
'InpHierarchyNodes':(100,5000),'InpLabelSize':(6,20),'InpLabelGap':(.05,5),'InpLabelRows':(.1,5),
'InpBoundaryForward':(0,200),'InpFibonacciForward':(1,200),'InpProjectionHorizon':(1,200),
'InpProjectionButtonRight':(0,2000),'InpProjectionButtonTop':(0,2000),'InpHiddenMinBars':(1,10000),
'InpHiddenMaxBars':(1,10000),'InpWorkLimit':(10000,200000),'InpCandidateLimit':(6,48)}
enums={'ZWBaseDegree':['Grand Supercycle','Supercycle','Cycle','Primary','Intermediate','Minor','Minute'],
       'ZWTargetDegree':['Large','Child','Micro']}
enum_defaults={'ZW_PRIMARY':'Primary','ZW_CHILD':'Child'}
hidden_protocol={'InpProjectionButton':'false','InpProjectionButtonRight':'0','InpProjectionButtonTop':'0',
                 'InpSeparateLabels':'false','InpLabelRows':'0.35'}
definitions=[];bindings=[];normalized=[];defaults=[]
for i,(kind,name,default,comment) in enumerate(inputs):
    label=comment.strip() or name
    quoted=lambda v:json.dumps(v,ensure_ascii=False)
    head=f'InputDefinition.'
    if kind=='bool':definition=f'bool({quoted(name)},{quoted(label)},{default})';native=f'(v.at({i})=="true")'
    elif kind=='color':
        rgb=[int(n) for n in re.fullmatch(r"C'(\d+),(\d+),(\d+)'",default).groups()]
        argb=0xff000000|(rgb[0]<<16)|(rgb[1]<<8)|rgb[2]
        definition=f'color({quoted(name)},{quoted(label)},0x{argb:08x})';native=f'static_cast<color>(std::stoul(v.at({i})))'
    elif kind=='string':definition=f'text({quoted(name)},{quoted(label)},{default})';native=f'string(v.at({i}))'
    elif kind in enums:
        options=enums[kind];value=enum_defaults[default]
        definition=f'choice({quoted(name)},{quoted(label)},{quoted(value)},'+','.join(quoted(x) for x in options)+')'
        native=f'static_cast<decltype(s.{name})>(std::stoi(v.at({i})))'
    else:
        low,high=ranges[name];fn='integer' if kind=='int' else 'decimal'
        definition=f'{fn}({quoted(name)},{quoted(label)},{default},{low},{high})'
        native=f'std::{"stoi" if kind=="int" else "stod"}(v.at({i}))'
    if name not in hidden_protocol:definitions.append('            '+head+definition)
    bindings.append(f'    s.{name}={native};')
    if name in hidden_protocol:normalize=quoted(hidden_protocol[name])
    elif kind=='color':normalize=f'Integer.toUnsignedString(toBgr(InputDefinition.parseColor(v.get({quoted(name)}))))'
    elif kind in enums:normalize=f'Integer.toString(Arrays.asList('+','.join(quoted(x) for x in enums[kind])+f').indexOf(v.get({quoted(name)})))'
    else:normalize=f'v.get({quoted(name)})'
    normalized.append('        '+normalize)
    if kind=='color':defaults.append(str(rgb[0]|(rgb[1]<<8)|(rgb[2]<<16)))
    elif kind in enums:defaults.append(str(enums[kind].index(enum_defaults[default])))
    elif kind=='string':defaults.append(json.loads(default))
    else:defaults.append(default)
defs='''package converted.hpxzwave;
import java.util.Arrays;
import java.util.Map;
import net.metaquotes.metatrader5.modules.api.*;
/** Source inputs without chart-button controls or notification fields; native slots remain stable. */
final class Inputs {
    static final ModuleDescriptor DESCRIPTOR=new ModuleDescriptor("hpx.zwave","HPX Zwave Pro","1.0.0",ModuleDescriptor.API_VERSION,Arrays.asList(
'''+',\n'.join(definitions)+'''));
    static String[] values(Map<String,String> v) {
        return new String[]{
'''+',\n'.join(normalized)+'''};
    }
    private static int toBgr(int argb) { return ((argb>>>16)&255)|(argb&0xff00)|((argb&255)<<16); }
}
'''
out=ROOT/'src/converted/hpxzwave';out.mkdir(parents=True,exist_ok=True)
(out/'Inputs.java').write_text(defs,encoding='utf-8')
(ROOT/'native/generated/config_bindings.hpp').write_text('#pragma once\ninline void setInputs(HPXSession& s,const std::vector<std::string>& v) {\n'+
    f'    if(v.size()!={len(inputs)})throw std::invalid_argument("Incomplete ZWave inputs");\n'+'\n'.join(bindings)+'\n}\n',encoding='utf-8')
(ROOT/'native/generated/input_defaults.hpp').write_text('#pragma once\ninline std::vector<std::string> defaultInputs() { return {'+
    ','.join(json.dumps(x,ensure_ascii=False) for x in defaults)+'}; }\n',encoding='utf-8')
print('Generated',len(definitions),'visible inputs with',len(inputs),'native protocol slots.')
