"""Reproducible, deliberately narrow MQL value-array -> C++ adapter for HPX ZWave.

The algorithm/proof/target bodies stay in the supplied MPL sources. This script
only rewrites MQL declaration/cast syntax and replaces desktop scene publication.
"""
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'original'/'HPX'
OUT=ROOT/'native'/'generated'
OUT.mkdir(parents=True,exist_ok=True)

def split_variables(s):
    result=[];last=0;level=0;quote=None;escaped=False
    for i,c in enumerate(s):
        if quote:
            if escaped:escaped=False
            elif c=='\\':escaped=True
            elif c==quote:quote=None
        elif c in '\"\'':quote=c
        elif c in '([{':level+=1
        elif c in ')]}':level-=1
        elif c==',' and level==0:result.append(s[last:i]);last=i+1
    result.append(s[last:]);return result

TYPES=r'(?:int|double|bool|datetime|string|color|long|ulong|ushort|ENUM_LINE_STYLE|MqlRates|ZW\w+)'
def translate(s):
    s=re.sub(r'#include "(HPX\w+)\.mqh"',r'#include "\1.hpp"',s)
    s=re.sub(r"C'(\d+),(\d+),(\d+)'",lambda m:str(int(m[1])|(int(m[2])<<8)|(int(m[3])<<16)),s)
    # MQL exposes members through a class pointer with '.', C++ uses '->'.
    s=s.replace('m_c.','m_c->')
    s=re.sub(r'\b(const\s+)?('+TYPES+r')\s*&\s*(\w+)\s*\[\s*\]',
             lambda m:('const ' if m[1] else '')+'MArray<'+m[2]+'>& '+m[3],s)
    # Each dynamic/fixed declaration becomes a value-owning, bounds-checked array.
    pattern=re.compile(r'\b('+TYPES+r')\s+(\w+)\s*\[')
    pos=0
    while (m:=pattern.search(s,pos)):
        end=s.find(';',m.start())
        if end<0:raise ValueError('Unterminated array declaration')
        declaration=s[m.start():end]
        kind=m[1];variables=split_variables(declaration[len(kind):].strip())
        statements=[]
        for variable in variables:
            a=re.fullmatch(r'\s*(\w+)\s*\[([^\]]*)\]\s*(?:=\s*(.*))?',variable,re.S)
            if a:
                name,size,initializer=a.groups()
                expression=('='+initializer) if initializer else ('=MArray<'+kind+'>('+size+')') if size.strip() else ''
                statements.append('MArray<'+kind+'> '+name+expression+';')
            else:statements.append(kind+' '+variable.strip()+';')
        replacement=''.join(statements)
        s=s[:m.start()]+replacement+s[end+1:];pos=m.start()+len(replacement)
    # Unlike MQL, C++ cannot concatenate two string literals returned by ?:.
    # Convert source literals to the value string wrapper; leave comments and
    # preprocessor include paths byte-for-byte intact.
    def wrap_line(line):
        if line.lstrip().startswith(('#','//')):return line
        pieces=[];at=0
        token=re.compile(r'"(?:\\.|[^"\\])*"|//.*$')
        for found in token.finditer(line):
            pieces.append(line[at:found.start()]);value=found.group()
            pieces.append(value if value.startswith('//') else 'string('+value+')');at=found.end()
        return ''.join(pieces)+line[at:]
    return '\n'.join(wrap_line(line) for line in s.split('\n'))

names=['HPXZWaveTypes','HPXZWaveCore','HPXZWaveStructures','HPXZWaveTargets']
for name in names:
    s=(SOURCE/'Include'/(name+'.mqh')).read_text(encoding='utf-8-sig')
    (OUT/(name+'.hpp')).write_text(translate(s),encoding='utf-8')

# Keep the source's scene accumulation, shared-pivot joining and wave notation;
# the Android host owns pixel mapping and atomically publishes the scene.
render=(SOURCE/'Include'/'HPXZWaveRender.mqh').read_text(encoding='utf-8-sig')
scene=render[render.index('struct ZWVisualLine'):render.index('   void Style(')]
scene+='   void Flush() { }\n   void Clear() { Begin(); }\n};\n'
notation=render[render.index('string ZWNotationToken'):render.rindex('#endif')]
(OUT/'HPXZWaveRender.hpp').write_text('#pragma once\n#include "HPXZWaveCore.hpp"\n'+translate(scene+notation),encoding='utf-8')

main=(SOURCE/'Indicators'/'HPX_Zwave_Pro.mq5').read_text(encoding='utf-8-sig')
start=main.index('enum ZWBaseDegree');end=main.index('bool ZWValidTag')
fields=main[start:end]
fields=re.sub(r'^input group.*\n','',fields,flags=re.M)
fields=re.sub(r'^input ','',fields,flags=re.M)

def function(name):
    m=re.search(r'^(?:void|int|double|bool|color|string) '+name+r'\([^)]*\)\s*\{',main,re.M)
    if not m:raise ValueError(name)
    depth=1;i=m.end();quote=None;escape=False
    while depth:
        c=main[i]
        if quote:
            if escape:escape=False
            elif c=='\\':escape=True
            elif c==quote:quote=None
        elif c in '\"\'':quote=c
        elif c=='{':depth+=1
        elif c=='}':depth-=1
        i+=1
    return main[m.start():i]+'\n'

methods=''.join(function(n) for n in ['ZWValidTag','ZWValidInputs','ZWConfigure','ZWInk','ZWDegreeName','ZWVisible','ZWLabel','ZWATR','ZWShowPattern','ZWFamilyCaption','ZWDrawPattern','ZWPaint','ZWAnalyze'])
methods=methods.replace('double tick=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);if(tick<=0)tick=_Point;','double tick=m_tick;')
# Desktop button collision reservation is omitted; no chart button is published.
paint_start=methods.index('   if(InpProjectionButton)\n   {')
paint_end=methods.index('   int visible=ZWVisible()',paint_start)
methods=methods[:paint_start]+methods[paint_end:]
session='''#pragma once
#include "HPXZWaveStructures.hpp"
#include "HPXZWaveTargets.hpp"
class HPXSession {
public:
int _Period=60;
double m_tick=.00001;
void ZWProjectionButton() { }
'''+fields+methods+'\n};\n'
(OUT/'HPXSession.hpp').write_text(translate(session),encoding='utf-8')
print('Translated four computation headers, source scene builder, and source session methods.')
