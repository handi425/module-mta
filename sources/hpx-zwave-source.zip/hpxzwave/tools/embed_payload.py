from pathlib import Path
import base64,hashlib,sys,zlib
root=Path(__file__).resolve().parents[1]
binary=Path(sys.argv[1]).read_bytes()
sha=hashlib.sha256(binary).hexdigest()
payload=base64.b64encode(zlib.compress(binary,9)).decode('ascii')
parts=[payload[i:i+16000] for i in range(0,len(payload),16000)]
code='package converted.hpxzwave;\n/** Build-generated embedded payload; covered by signed module DEX. */\nfinal class NativePayload {\n'
code+=f'    static final String SHA256="{sha}";\n    static final int LENGTH={len(binary)};\n    static final String[] PARTS={{\n'
code+=',\n'.join('        "'+part+'"' for part in parts)+'};\n}\n'
(root/'src/converted/hpxzwave/NativePayload.java').write_text(code,encoding='utf-8')
print('Embedded ARM64 ELF',len(binary),'bytes; compressed',len(payload),'base64 bytes; SHA256',sha)
