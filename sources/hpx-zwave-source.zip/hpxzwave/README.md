# HPX Zwave Pro — converted module

The supplied HPX source and its MPL-2.0 notices are retained under `original/HPX/`.
The module keeps 60 functional inputs and the complete causal ZigZag,
counting, MACD divergence, Elliott family geometry, bounded subdivision/hierarchy
proofs, Fibonacci profiles, conditional projections, degree notation and shared
pivot labels. Every line endpoint and text anchor retains the source's time and
price. `InpLabelGap` remains a functional ATR-based price offset. There is no
viewport/font collision packing or repositioning when the chart is zoomed/panned.
The unused `InpSeparateLabels` and `InpLabelRows` controls are removed. The
projection degree follows `InpFibonacciDegree`. There is no chart projection
button or saved button state. The native 65-slot protocol keeps fixed `false`,
`0`, `0` values for the three removed button controls, with `false` and `0.35`
for the unused separation/row slots. No notification input,
notification permission or delivery code is present.

The supplied MQL value-array syntax is mechanically lowered into C++ by
`tools/translate.py`; the calculation bodies are retained. `mql_compat.hpp`
implements value copies, checked arrays, numeric/string helpers and the minimal
desktop information read by the source. Scene primitives are published through
the host PlotFrame API. The chart host uses native coordinate projection on a
transient Canvas; converted geometry creates no chart objects. The scene adapter
publishes source anchors without reading a viewport, measuring fonts or changing
prices/times. The computation output preserves source ATR gaps.

The ARM64 payload is embedded in the signed module DEX. Its exact SHA-256 is
verified before extraction and again before loading from app-private code cache.
It uses a distinct path per payload digest and module classloader. There is no
runtime native-code download, root requirement or separate APK installation.
The native export map exposes only the three JNI entry points. Its statically
linked C++ runtime stays local to the payload, so allocator, locale and exception
symbols cannot interpose on the host or another module classloader. The build
checks this ABI allowlist before embedding the payload.
The current custom host's extended PlotFrame/events API and ARM64 process are
required; the official MT5 APK does not implement this module API.

Build on Windows with Python, PowerShell and Android NDK29:

```powershell
./build-native.ps1
../../build-converted-module.ps1 -SourceDirectory ./src -EntryClass converted.hpxzwave.HPXZwave -OutputPath ../../../output/indicators/hpx-zwave.mt5ind -OriginalMq5Path ./original/HPX/Indicators/HPX_Zwave_Pro.mq5
```

`run-native-tests.ps1` compiles the same source algorithms for the x86_64 Android
emulator and runs closed-bar, Elliott geometry, Fibonacci, grammar, causal pivot,
proof bounds, scene and incremental-history fixtures. The test executable is
independent of the broker terminal and does not place or change orders.

The original 9% Large reversal default remains unchanged. A short, low-volatility
history can legitimately produce no confirmed Large pivots. `InpHistoryBars`
counts completed broker candles; optional preceding candles seed MACD only.

`tests/converted/ZWaveControlsTest.java` passes 82 assertions for the 60 functional
settings, unchanged 65-slot native protocol, disabled chart controls, functional
ATR gap and viewport-independent source anchors. Labels use the source's centered
normal Arial font anchor; offscreen time/price coordinates are retained and clipped
by the host Canvas instead of being moved into view.
