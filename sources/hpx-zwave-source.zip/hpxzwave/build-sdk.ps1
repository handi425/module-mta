param(
    [string]$JdkHome='C:\Program Files\Microsoft\jdk-21.0.8.9-hotspot',
    [string]$AndroidJar=(Join-Path $env:LOCALAPPDATA 'Android\Sdk\platforms\android-36\android.jar')
)
$ErrorActionPreference='Stop'
$build=Join-Path $PSScriptRoot 'build'
$classes=Join-Path $build ('sdk-'+[Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $classes | Out-Null
$sources=@(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'sdk-api') -Recurse -Filter '*.java' | ForEach-Object FullName)
if(-not $sources.Count){throw 'SDK API source is missing'}
if(-not (Test-Path -LiteralPath $AndroidJar -PathType Leaf)){throw 'Android SDK platform android.jar is missing'}
& (Join-Path $JdkHome 'bin\javac.exe') --release 8 '-Xlint:-options' -encoding UTF-8 -cp $AndroidJar -d $classes @sources
if($LASTEXITCODE -ne 0){throw 'SDK API 3 compilation failed'}
$sdk=Join-Path $build 'mt5-indicator-sdk-v3.jar'
& (Join-Path $JdkHome 'bin\jar.exe') --create --file $sdk -C $classes .
if($LASTEXITCODE -ne 0){throw 'SDK API 3 JAR packaging failed'}
Write-Output $sdk
