package converted.hpxzwave;

import java.util.Map;
import net.metaquotes.metatrader5.modules.api.ChartData;
import net.metaquotes.metatrader5.modules.api.ModuleEnvironment;
import net.metaquotes.metatrader5.modules.api.PlotFrame;

/** Publish source time/price anchors verbatim; viewport changes only project them. */
final class ZWaveScene {
    private ZWaveScene() { }
    static PlotFrame frame(String json,ModuleEnvironment env,ChartData chart,Map<String,String> inputs)throws Exception {
        return HPXZwave.frame(json);
    }
}
