package converted.hpxzwave;

import android.content.Context;
import android.util.Base64;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.MessageDigest;
import java.util.List;
import java.util.Map;
import java.util.zip.InflaterInputStream;
import net.metaquotes.metatrader5.modules.api.*;
import org.json.JSONArray;
import org.json.JSONObject;

/** The original HPX source algorithms run inside this module's signed ARM64 payload. */
public final class HPXZwave implements HistoryIndicatorPlugin {
    private static boolean libraryLoaded;
    private long session;
    public ModuleDescriptor describe() { return Inputs.DESCRIPTOR; }
    public int[] historyPeriods(Map<String,String> input) { return new int[0]; }
    public int historyBars(Map<String,String> supplied) {
        Map<String,String> v=describe().normalizeInputs(supplied);
        return Integer.parseInt(v.get("InpHistoryBars"))+(Boolean.parseBoolean(v.get("InpDivergence"))?300:0)+1;
    }

    public void onChartUpdate(ModuleEnvironment env,ChartData chart,Map<String,String> supplied) throws Exception {
        Map<String,String> input=describe().normalizeInputs(supplied);
        if(chart.closedBars.size()<2)throw new IllegalStateException("Menunggu candle HPX Zwave");
        loadLibrary(env.appContext);
        if(session==0)session=nativeCreate();
        int degree=degree(input.get("InpFibonacciDegree"));
        int count=Math.min(chart.closedBars.size(),historyBars(input)-1),offset=chart.closedBars.size()-count;
        long[] times=new long[count];double[] ohlc=new double[count*4];
        for(int i=0;i<count;i++) {
            ChartData.Bar bar=chart.closedBars.get(offset+i);times[i]=bar.time;
            ohlc[i*4]=bar.open;ohlc[i*4+1]=bar.high;ohlc[i*4+2]=bar.low;ohlc[i*4+3]=bar.close;
        }
        ChartData.Bar latest=chart.closedBars.get(chart.closedBars.size()-1),forming=chart.formingBar;
        long now=forming==null?latest.time+chart.periodSeconds:forming.time;
        double live=forming==null?latest.close:forming.close;
        double tick=chart.tickSize>0?chart.tickSize:chart.point;
        String scene=nativeRender(session,times,ohlc,Inputs.values(input),chart.periodSeconds,chart.digits,now,live,tick,degree,chart.backgroundColor);
        PlotFrame frame=ZWaveScene.frame(scene,env,chart,input);
        env.publish(chart.chartId,frame);
    }
    public void onDetach(ModuleEnvironment env,int chartId) throws Exception {
        try { env.clear(chartId); } finally { if(session!=0) { nativeDestroy(session);session=0; } }
    }
    private static int degree(String value) { return "Large".equals(value)?0:"Micro".equals(value)?2:1; }
    public static PlotFrame frame(String scene) throws Exception {
        JSONObject object=new JSONObject(scene);PlotFrame frame=new PlotFrame();
        JSONArray lines=object.getJSONArray("lines"),texts=object.getJSONArray("texts");
        for(int i=0;i<lines.length();i++) {
            JSONArray row=lines.getJSONArray(i);
            long a=row.getLong(0),b=row.getLong(2);double p=row.getDouble(1),q=row.getDouble(3);int color=(int)row.getLong(4);
            if(row.getBoolean(6))frame.rectangle("zone_"+i,0,a,p,b,q,color,true);
            else frame.line("line_"+i,0,a,p,b,q,color,1,row.getInt(5));
        }
        for(int i=0;i<texts.length();i++) {
            JSONArray row=texts.getJSONArray(i);
            frame.anchoredText("text_"+i,0,row.getLong(0),row.getDouble(1),row.getString(2),(int)row.getLong(3),row.getInt(4),3,false);
        }
        return frame;
    }
    private static synchronized void loadLibrary(Context context) throws Exception {
        if(libraryLoaded)return;
        boolean arm64=false;
        for(String abi:android.os.Build.SUPPORTED_ABIS)if("arm64-v8a".equals(abi))arm64=true;
        if(!arm64)throw new IllegalStateException("Modul HPX Zwave membutuhkan host ARM64");
        ByteArrayOutputStream encoded=new ByteArrayOutputStream();
        for(String part:NativePayload.PARTS)encoded.write(part.getBytes("US-ASCII"));
        byte[] compressed=Base64.decode(encoded.toByteArray(),Base64.DEFAULT);
        ByteArrayOutputStream binary=new ByteArrayOutputStream();
        try(InflaterInputStream in=new InflaterInputStream(new ByteArrayInputStream(compressed))) {
            byte[] block=new byte[16384];int n;
            while((n=in.read(block))!=-1) { if(binary.size()+n>NativePayload.LENGTH)throw new SecurityException("Payload HPX terlalu besar");binary.write(block,0,n); }
        }
        byte[] bytes=binary.toByteArray();
        if(bytes.length!=NativePayload.LENGTH||!NativePayload.SHA256.equals(sha256(bytes)))throw new SecurityException("Payload HPX tidak sesuai signature modul");
        String loader=Integer.toHexString(System.identityHashCode(HPXZwave.class.getClassLoader()));
        File folder=new File(context.getCodeCacheDir(),"indicator-native/hpx-zwave/"+NativePayload.SHA256+"/"+loader);
        if(!folder.isDirectory()&&!folder.mkdirs())throw new IllegalStateException("Cache HPX tidak tersedia");
        File target=new File(folder,"libhpxzwave_"+NativePayload.SHA256+".so");
        if(target.isFile()&&!NativePayload.SHA256.equals(fileHash(target))) {
            if(!target.delete())throw new SecurityException("Cache HPX tidak sesuai");
        }
        if(!target.isFile()) {
            File temporary=File.createTempFile("hpx-", ".tmp",folder);
            try {
                try(FileOutputStream out=new FileOutputStream(temporary)) { out.write(bytes);out.getFD().sync(); }
                if(!temporary.setReadable(true,true)||!temporary.setWritable(false,false))throw new SecurityException("Izin cache HPX tidak tersedia");
                if(!temporary.renameTo(target))throw new IllegalStateException("Cache HPX gagal diterapkan");
            } finally { if(temporary.exists())temporary.delete(); }
        }
        if(!NativePayload.SHA256.equals(fileHash(target)))throw new SecurityException("Hash cache HPX berubah");
        System.load(target.getAbsolutePath());libraryLoaded=true;
    }
    private static String fileHash(File file) throws Exception {
        MessageDigest hash=MessageDigest.getInstance("SHA-256");
        try(FileInputStream input=new FileInputStream(file)) {byte[] b=new byte[16384];int n;while((n=input.read(b))!=-1)hash.update(b,0,n);}
        return hex(hash.digest());
    }
    private static String sha256(byte[] bytes) throws Exception { return hex(MessageDigest.getInstance("SHA-256").digest(bytes)); }
    private static String hex(byte[] bytes) { StringBuilder s=new StringBuilder();for(byte b:bytes)s.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return s.toString(); }
    private static native long nativeCreate();
    private static native void nativeDestroy(long session);
    private static native String nativeRender(long session,long[] times,double[] ohlc,String[] input,int seconds,int digits,long formingTime,double live,double tick,int degree,int background);
}
