param([string]$Serial='127.0.0.1:7555',[string]$NdkHome=(Join-Path $env:LOCALAPPDATA 'Android\Sdk\ndk\29.0.13599879'))
$ErrorActionPreference='Stop'
& python (Join-Path $PSScriptRoot 'tools\translate.py')
if($LASTEXITCODE -ne 0){throw 'HPX translation failed'}
$build=Join-Path $PSScriptRoot 'build'
New-Item -ItemType Directory -Force -Path $build | Out-Null
$output=Join-Path $build 'hpx-zwave-selftest'
$clang=Join-Path $NdkHome 'toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe'
& $clang --target=x86_64-linux-android26 -std=c++17 -O1 -static-libstdc++ (Join-Path $PSScriptRoot 'native\selftest.cpp') -o $output
if($LASTEXITCODE -ne 0){throw 'HPX self-test compilation failed'}
& adb -s $Serial push $output '/data/local/tmp/hpx-zwave-selftest'
if($LASTEXITCODE -ne 0){throw 'HPX self-test upload failed'}
& adb -s $Serial shell chmod 700 '/data/local/tmp/hpx-zwave-selftest'
if($LASTEXITCODE -ne 0){throw 'HPX self-test permissions failed'}
& adb -s $Serial shell '/data/local/tmp/hpx-zwave-selftest'
if($LASTEXITCODE -ne 0){throw 'HPX native algorithm fixture failed'}
& python (Join-Path $PSScriptRoot 'tools\generate_adapter.py')
if($LASTEXITCODE -ne 0){throw 'HPX input adapter generation failed'}
$bridge=Join-Path $build 'hpx-zwave-bridge-selftest'
& $clang --target=x86_64-linux-android26 -std=c++17 -O1 -static-libstdc++ (Join-Path $PSScriptRoot 'native\bridge_selftest.cpp') -o $bridge
if($LASTEXITCODE -ne 0){throw 'HPX bridge fixture compilation failed'}
& adb -s $Serial push $bridge '/data/local/tmp/hpx-zwave-bridge-selftest'
if($LASTEXITCODE -ne 0){throw 'HPX bridge fixture upload failed'}
& adb -s $Serial shell chmod 700 '/data/local/tmp/hpx-zwave-bridge-selftest'
if($LASTEXITCODE -ne 0){throw 'HPX bridge fixture permissions failed'}
& adb -s $Serial shell '/data/local/tmp/hpx-zwave-bridge-selftest'
if($LASTEXITCODE -ne 0){throw 'HPX native scene bridge fixture failed'}
