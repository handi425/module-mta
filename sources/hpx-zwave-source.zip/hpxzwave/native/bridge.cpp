// Android scene adapter for the supplied HPX MPL-2.0 computation sources.
#include "mql_compat.hpp"
#include "generated/HPXSession.hpp"
#include <jni.h>
#include <vector>
#include <memory>
#include "generated/config_bindings.hpp"

namespace {
std::string json(const std::string& value) {
    std::ostringstream out;out<<'"';
    for(unsigned char c:value) {
        if(c=='"')out<<"\\\"";else if(c=='\\')out<<"\\\\";else if(c=='\n')out<<"\\n";
        else if(c=='\r')out<<"\\r";else if(c=='\t')out<<"\\t";
        else if(c<32)out<<"\\u"<<std::hex<<std::setw(4)<<std::setfill('0')<<(int)c<<std::dec;
        else out<<c;
    }
    out<<'"';return out.str();
}
uint32_t argb(color c) {
    uint32_t alpha=c>>24;if(alpha==0)alpha=255;
    return (alpha<<24)|((c&255)<<16)|(c&0xff00)|((c>>16)&255);
}
struct Session {
    HPXSession source;
    std::vector<std::string> inputs;
    int bars=0;datetime firstTime=0,lastTime=0;
    Session(){source.g_owner=true;}
};
std::string render(Session& session,const MArray<MqlRates>& closed,const std::vector<std::string>& input,
                   int seconds,int digits,datetime formingTime,double livePrice,double tick,int degree,int background) {
    auto& s=session.source;
    bool changed=session.inputs!=input;session.inputs=input;
    setInputs(s,input);
    if(closed.size()<2||!s.ZWValidInputs())throw std::invalid_argument("Parameter HPX Zwave tidak sesuai batas source asli");
    _Digits=digits;HPXBackground=((background>>16)&255)|(background&0xff00)|((background&255)<<16);
    s._Period=seconds;s.m_tick=tick;s.ZWConfigure();s.g_targetOptions.degree=degree;
    s.g_livePrice=livePrice;s.g_formingTime=formingTime;
    if(!s.g_ready||changed||session.bars!=closed.size()||session.firstTime!=closed[0].time||session.lastTime!=closed[closed.size()-1].time) {
        int count=MathMin(s.InpHistoryBars+(s.InpDivergence?300:0),closed.size());
        MArray<MqlRates> source;ArrayCopy(source,closed,0,closed.size()-count,count);
        s.ZWAnalyze(source);
        if(!s.g_ready)throw std::runtime_error("HPX Zwave analysis rejected chart history");
        session.bars=closed.size();session.firstTime=closed[0].time;session.lastTime=closed[closed.size()-1].time;
    }
    s.ZWPaint();
    std::ostringstream out;out.imbue(std::locale::classic());out<<std::setprecision(17);
    out<<"{\"lines\":[";
    for(int i=0;i<s.g_draw.lines.size();i++) {
        const auto& line=s.g_draw.lines[i];if(i)out<<',';
        out<<'['<<line.a<<','<<line.p<<','<<line.b<<','<<line.q<<','<<argb(line.ink)<<','
           <<(line.style==STYLE_SOLID?3:line.style)<<','<<(line.zone?"true":"false")<<']';
    }
    out<<"],\"texts\":[";
    for(int i=0;i<s.g_draw.texts.size();i++) {
        const auto& text=s.g_draw.texts[i];if(i)out<<',';
        double price=text.p+(text.fixed?0:text.side*s.g_draw.atr*s.g_draw.gap);
        out<<'['<<text.t<<','<<price<<','<<json(text.text)<<','<<argb(text.ink)<<','<<text.size<<','
           <<text.side<<','<<(text.fixed?"true":"false")<<']';
    }
    out<<"],\"atr\":"<<s.g_draw.atr<<",\"row\":"<<s.g_draw.row<<",\"separate\":"<<(s.g_draw.separate?"true":"false")
       <<",\"patterns\":"<<s.g_patterns.size()<<",\"proofs\":"<<s.g_proofs.size()<<",\"workUsed\":"<<s.g_zw.work_used
       <<",\"streams\":"<<s.g_zw.streams.size()<<",\"counts\":"<<s.g_zw.counts.size()<<",\"paths\":"<<s.g_zw.paths.size()<<'}';
    return out.str();
}
void fail(JNIEnv* env,const std::exception& error) { env->ThrowNew(env->FindClass("java/lang/IllegalStateException"),error.what()); }
}

extern "C" JNIEXPORT jlong JNICALL Java_converted_hpxzwave_HPXZwave_nativeCreate(JNIEnv* env,jclass) {
    try{return reinterpret_cast<jlong>(new Session());}catch(const std::exception& error){fail(env,error);return 0;}
}
extern "C" JNIEXPORT void JNICALL Java_converted_hpxzwave_HPXZwave_nativeDestroy(JNIEnv*,jclass,jlong handle) { delete reinterpret_cast<Session*>(handle); }
extern "C" JNIEXPORT jstring JNICALL Java_converted_hpxzwave_HPXZwave_nativeRender(JNIEnv* env,jclass,jlong handle,
        jlongArray times,jdoubleArray ohlc,jobjectArray values,jint seconds,jint digits,jlong formingTime,
        jdouble livePrice,jdouble tick,jint degree,jint background) {
    try {
        if(!handle||!times||!ohlc||!values)throw std::invalid_argument("Missing ZWave session or input");
        int n=env->GetArrayLength(times);
        if(n<2||n>100000||env->GetArrayLength(ohlc)!=n*4||seconds<1||digits<0||digits>12||
            degree<0||degree>2||tick<=0||!std::isfinite(tick)||!std::isfinite(livePrice))
            throw std::invalid_argument("Invalid ZWave chart data");
        std::vector<jlong> t(n);std::vector<jdouble> prices(n*4);
        env->GetLongArrayRegion(times,0,n,t.data());env->GetDoubleArrayRegion(ohlc,0,n*4,prices.data());
        if(env->ExceptionCheck())return nullptr;
        MArray<MqlRates> bars(n);
        for(int i=0;i<n;i++) { bars[i].time=t[i];bars[i].open=prices[i*4];bars[i].high=prices[i*4+1];bars[i].low=prices[i*4+2];bars[i].close=prices[i*4+3]; }
        std::vector<std::string> input;
        for(int i=0;i<env->GetArrayLength(values);i++) {
            auto v=static_cast<jstring>(env->GetObjectArrayElement(values,i));
            if(!v)throw std::invalid_argument("Missing ZWave input value");
            const char* bytes=env->GetStringUTFChars(v,nullptr);if(!bytes)return nullptr;
        input.emplace_back(bytes);env->ReleaseStringUTFChars(v,bytes);env->DeleteLocalRef(v);
        }
        auto output=render(*reinterpret_cast<Session*>(handle),bars,input,seconds,digits,formingTime,livePrice,tick,degree,background);
        return env->NewStringUTF(output.c_str());
    }catch(const std::exception& error){fail(env,error);return nullptr;}
}
