#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cfloat>
#include <cstdlib>
#include <deque>
#include <iomanip>
#include <initializer_list>
#include <sstream>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <chrono>

// MQL structs and dynamic arrays are values, including nested arrays. Bounds
// checks turn an unsupported input into a module error instead of memory access.
template<class T> class MArray {
    std::deque<T> items;
public:
    MArray()=default;
    explicit MArray(int n) { resize(n); }
    MArray(std::initializer_list<T> init):items(init) { }
    int size() const { return static_cast<int>(items.size()); }
    void resize(int n) { if(n<0||n>2000000)throw std::out_of_range("MQL array limit");items.resize(n); }
    T& operator[](int i) { return items.at(i); }
    const T& operator[](int i) const { return items.at(i); }
    auto begin() { return items.begin(); } auto end() { return items.end(); }
    auto begin() const { return items.begin(); } auto end() const { return items.end(); }
};
template<class T> int ArraySize(const MArray<T>& a) { return a.size(); }
template<class T> int ArrayResize(MArray<T>& a,int n) { a.resize(n);return n; }
template<class T,class V> void ArrayInitialize(MArray<T>& a,V v) { for(auto& x:a)x=static_cast<T>(v); }
template<class T,size_t N,class V> void ArrayInitialize(T (&a)[N],V v) { for(auto& x:a)x=static_cast<T>(v); }
template<class T> int ArrayCopy(MArray<T>& dst,const MArray<T>& src,int to=0,int from=0,int count=-1) {
    if(count<0)count=src.size()-from;
    if(to<0||from<0||count<0||from+count>src.size())throw std::out_of_range("MQL ArrayCopy");
    if(dst.size()<to+count)dst.resize(to+count);
    if(&dst==&src) { MArray<T> copy=src;return ArrayCopy(dst,copy,to,from,count); }
    for(int i=0;i<count;i++)dst[to+i]=src[from+i];return count;
}
template<class T> void ZeroMemory(T& v) { v=T{}; }
template<class T> T* GetPointer(T& v) { return &v; }
template<class T,class U> auto MathMin(T a,U b) { using R=typename std::common_type<T,U>::type;return std::min<R>(a,b); }
template<class T,class U> auto MathMax(T a,U b) { using R=typename std::common_type<T,U>::type;return std::max<R>(a,b); }
template<class T> auto MathAbs(T v) { return std::abs(v); }
inline double MathExp(double v) { return std::exp(v); }
inline double MathLog(double v) { return std::log(v); }
inline double MathPow(double a,double b) { return std::pow(a,b); }
inline double MathSqrt(double a) { return std::sqrt(a); }
inline double MathFloor(double a) { return std::floor(a); }
inline double MathCeil(double a) { return std::ceil(a); }
inline double MathRound(double a) { return std::round(a); }
inline bool MathIsValidNumber(double a) { return std::isfinite(a); }

class MString:public std::string {
public:
    using std::string::string;
    using std::string::operator=;
    MString()=default;
    MString(const std::string& s):std::string(s) { }
    MString(bool v):std::string(v?"true":"false") { }
    template<class T,typename std::enable_if<std::is_arithmetic<T>::value&&!std::is_same<T,bool>::value,int>::type=0>
    explicit MString(T v):std::string(std::to_string(v)) { }
};
using string=MString;
inline string operator+(const string& a,const string& b) { return static_cast<const std::string&>(a)+static_cast<const std::string&>(b); }
using datetime=int64_t;
using color=uint32_t;
using ulong=uint64_t;
using ushort=uint16_t;
using ENUM_LINE_STYLE=int;
constexpr double EMPTY_VALUE=DBL_MAX;
constexpr int STYLE_SOLID=0,STYLE_DASH=1,STYLE_DOT=2;
constexpr color clrMagenta=0xff00ff,clrTeal=0x808000,clrGray=0x808080;
inline thread_local int _Digits=5;
inline thread_local color HPXBackground=0;
constexpr int CHART_COLOR_BACKGROUND=0;
inline color ChartGetInteger(int,int) { return HPXBackground; }
struct MqlRates { datetime time=0;double open=0,high=0,low=0,close=0;int64_t tick_volume=0,real_volume=0;int spread=0; };
inline int StringLen(const string& s) { return static_cast<int>(s.size()); }
inline ushort StringGetCharacter(const string& s,int i) { return static_cast<unsigned char>(s.at(i)); }
inline int StringFind(const string& s,const string& token,int start=0) {
    if(start<0)return -1;auto p=s.find(token,start);return p==std::string::npos?-1:static_cast<int>(p);
}
inline string StringSubstr(const string& s,int start,int count=-1) {
    if(start<0||start>=StringLen(s))return "";
    return s.substr(start,count<0?std::string::npos:static_cast<size_t>(count));
}
inline int StringReplace(string& s,const string& from,const string& to) {
    if(from.empty())return 0;size_t at=0;int n=0;
    while((at=s.find(from,at))!=std::string::npos) { s.replace(at,from.size(),to);at+=to.size();n++; }return n;
}
inline void StringToLower(string& s) { for(auto& c:s)if(c>='A'&&c<='Z')c+='a'-'A'; }
inline int64_t StringToInteger(const string& s) { return std::strtoll(s.c_str(),nullptr,10); }
inline int StringSplit(const string& s,char delimiter,MArray<string>& out) {
    out.resize(0);if(s.empty())return 0;size_t at=0;
    while(true) { auto end=s.find(delimiter,at);int n=out.size();out.resize(n+1);out[n]=s.substr(at,end-at);if(end==std::string::npos)break;at=end+1; }
    return out.size();
}
inline string DoubleToString(double value,int digits=8) { std::ostringstream s;s.imbue(std::locale::classic());s<<std::fixed<<std::setprecision(digits)<<value;return s.str(); }
inline int PeriodSeconds(int period) { return period; }
inline uint64_t GetTickCount64() { return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count(); }
