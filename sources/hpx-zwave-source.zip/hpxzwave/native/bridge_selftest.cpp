#include "bridge.cpp"
#include "generated/input_defaults.hpp"
#include <iostream>
int main() {
    try {
        Session s;auto inputs=defaultInputs();MArray<MqlRates> bars(600);
        for(int i=0;i<bars.size();i++) {
            double p=100+18*std::sin(i*.13)+5*std::sin(i*.51);
            bars[i].time=1700000000+i*60;bars[i].open=bars[i].close=p;bars[i].high=p+.4;bars[i].low=p-.4;
        }
        auto output=render(s,bars,inputs,60,2,bars[599].time+60,bars[599].close,.01,1,0xffeeeeee);
        if(output.find("\"lines\":[[")==std::string::npos||output.find("\"texts\":[[")==std::string::npos)
            throw std::runtime_error("Bridge did not emit source scene");
        if(s.source.g_patterns.size()!=s.source.g_proofs.size())throw std::runtime_error("Bridge lost proof alignment");
        int patterns=s.source.g_patterns.size(),lines=s.source.g_draw.lines.size(),texts=s.source.g_draw.texts.size();
        auto repeated=render(s,bars,inputs,60,2,bars[599].time+60,bars[599].close,.01,1,0xffeeeeee);
        if(repeated!=output)throw std::runtime_error("Unchanged tick changed source scene");
        auto alternative=render(s,bars,inputs,60,2,bars[599].time+60,bars[599].close,.01,0,0xffeeeeee);
        if(s.source.g_targetOptions.degree!=0)throw std::runtime_error("Degree selection not applied");
        inputs[0]="0.00001";
        bool rejected=false;try { render(s,bars,inputs,60,2,bars[599].time+60,bars[599].close,.01,0,0xffeeeeee); }
        catch(const std::invalid_argument&) {rejected=true;}
        if(!rejected)throw std::runtime_error("Cross-input reversal bound not enforced");
        std::cout<<"PASS: HPX ZWave native scene bridge; inputCount="<<inputs.size()<<" patterns="<<patterns<<" lines="<<lines<<" texts="<<texts<<" stableTick=true degreeCycle=true invalidInputsRejected=true\n";
        return 0;
    }catch(const std::exception& failure) {std::cerr<<"FAIL: "<<failure.what()<<"\n";return 1;}
}
