#include "mql_compat.hpp"
#include "generated/HPXSession.hpp"
int main(){HPXSession s;s.ZWConfigure();return 0;}
