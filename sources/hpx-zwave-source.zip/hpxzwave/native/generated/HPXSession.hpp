#pragma once
#include "HPXZWaveStructures.hpp"
#include "HPXZWaveTargets.hpp"
class HPXSession {
public:
int _Period=60;
double m_tick=.00001;
void ZWProjectionButton() { }
enum ZWBaseDegree {ZW_GRAND_SUPERCYCLE=0,ZW_SUPERCYCLE=1,ZW_CYCLE=2,ZW_PRIMARY=3,ZW_INTERMEDIATE=4,ZW_MINOR=5,ZW_MINUTE=6};
enum ZWTargetDegree {ZW_LARGE=0,ZW_CHILD=1,ZW_MICRO=2};
double InpLargeReversal=9.0; // Reversal Large ZigZag (%)
double InpSubwaveDivisor=3.0; // Pembagi reversal subwave
int InpLargeDepth=10; // Kedalaman pivot Large
int InpChildDepth=4; // Kedalaman pivot Child
int InpHistoryBars=10000; // Maksimum candle selesai
int InpVisibleLargePivots=24; // Pivot Large yang ditampilkan
bool InpDeveloping=true; // Counting berkembang dengan tanda ?
bool InpMicroCounting=false; // Label counting Micro tambahan
bool InpLargeZigZag=false; // Garis ZigZag Large
bool InpChildZigZag=false; // Garis ZigZag Child
bool InpImpulses=true; // Deteksi impulse lengkap
bool InpImpulseLines=false; // Tampilkan garis impulse
bool InpDiagonals=true; // Leading / Ending Diagonal
bool InpTriangles=true; // Contracting / Barrier / Expanding Triangle
bool InpABC=true; // Zigzag dan Flat ABC
bool InpCombinations=true; // Double / Triple Zigzag dan Combination
bool InpTruncation=true; // Truncated fifth dengan bukti subwave
bool InpExtensions=true; // Extension W1 / W3 / W5 dengan bukti subwave
bool InpNestedSubwaves=true; // Subwave di dalam subwave
bool InpMicroStructures=true; // Struktur pada derajat Micro
int InpRecentPatterns=2; // Struktur terakhir per keluarga / derajat
bool InpSubdivisionOnly=false; // Hanya pola dengan bukti subdivisi S
bool InpHierarchy=true; // Validasi hierarki
int InpHierarchyDepth=12; // Kedalaman derajat bukti (4-16)
int InpHierarchyNodes=2000; // Maksimum simpul per pola
bool InpCompleteHierarchyOnly=false; // Hanya hierarki sepenuhnya valid
bool InpDegreeNotation=true; // Notasi Elliott menurut derajat
ZWBaseDegree InpBaseDegree=ZW_PRIMARY; // Notasi derajat Large
color InpLargeColor=16426336; // Warna Large
color InpChildColor=3969787; // Warna Child
color InpMicroColor=8445514; // Warna subwave terdalam yang ditampilkan
bool InpSeparateLabels=true; // Pisahkan label yang berdekatan
int InpLabelSize=8; // Ukuran teks wave
double InpLabelGap=.15; // Jarak label dari pivot (ATR)
double InpLabelRows=.35; // Jarak antarbaris label (ATR)
bool InpPatternTitles=true; // Nama pola dan bukti G / S / H
int InpBoundaryForward=20; // Perpanjangan batas pola (candle)
bool InpFibonacci=true; // Fibonacci berdasarkan counting
ZWTargetDegree InpFibonacciDegree=ZW_CHILD; // Derajat proyeksi awal (Large / Child / Micro)
bool InpFibonacciNext=false; // Wave berikutnya; false = aktif / terakhir
bool InpLarryPull=true; // Larry Pull; false = Trend Based
bool InpUncommon=true; // Kategori Tak umum
bool InpMostCommon=true; // Kategori Paling umum
bool InpCommon=true; // Kategori Umum
bool InpVeryCommon=true; // Kategori Sangat umum
bool InpRare=false; // Kategori Langka
bool InpFibonacciShade=true; // Latar zona Fibonacci
int InpFibonacciForward=20; // Panjang ke kanan (candle)
bool InpProjection=true; // Tampilkan skenario bersyarat
bool InpProjectionAlternative=true; // Skenario alternatif setelah 5 / C / E
bool InpProjectionLevels=true; // Level pemicu dan invalidasi
int InpProjectionHorizon=30; // Ruang gambar skenario (candle)
bool InpProjectionButton=true; // Tombol pergantian ZW Large / Child / Micro
int InpProjectionButtonRight=8; // Jarak tombol dari pojok kanan (piksel)
int InpProjectionButtonTop=8; // Jarak tombol dari pojok atas (piksel)
bool InpDivergence=false; // Aktifkan Divergence (bawaan Off)
bool InpRegularDivergence=true; // Divergence MACD W3-W5
bool InpHiddenDivergence=true; // Hidden Divergence MACD
int InpHiddenMinBars=5; // Minimum jarak pivot
int InpHiddenMaxBars=500; // Maksimum jarak pivot
bool InpHiddenSwingExtremes=true; // Gunakan ekstrem MACD pada swing
bool InpHiddenSameSide=false; // MACD harus pada sisi nol yang sama
int InpWorkLimit=80000; // Batas pekerjaan geometri per candle
int InpCandidateLimit=24; // Maksimum kandidat bukti per candle
string InpInstanceTag=string("1"); // ID unik tiap instance pada chart

CZWCore g_zw;
CZWStructures g_structures;
CZWRender g_draw;
CZWTargets g_targets;
MArray<ZWPattern> g_patterns;
MArray<ZWProof> g_proofs;
ZWOptions g_options;
ZWTargetOptions g_targetOptions;
datetime g_closedTime=0,g_formingTime=0;
double g_livePrice=0;
bool g_ready=false,g_dirty=true,g_owner=false;
string g_lock=string("");
string g_projectionKey=string("");
int g_projectionDegree=1;
ulong g_lastPaint=0,g_waitUntil=0;
int g_lastTotal=0;

bool ZWValidTag()
{
   int n=StringLen(InpInstanceTag);if(n<1||n>12)return false;
   for(int i=0;i<n;i++){ushort c=StringGetCharacter(InpInstanceTag,i);if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'))return false;}
   return true;
}
bool ZWValidInputs()
{
   return ZWValidTag()&&MathIsValidNumber(InpLargeReversal)&&InpLargeReversal>=.00001&&InpLargeReversal<=100&&
      MathIsValidNumber(InpSubwaveDivisor)&&InpSubwaveDivisor>1&&InpSubwaveDivisor<=20&&InpLargeReversal/(InpSubwaveDivisor*InpSubwaveDivisor)>=.00001&&
      InpLargeDepth>=2&&InpLargeDepth<=200&&InpChildDepth>=2&&InpChildDepth<=100&&InpHistoryBars>=100&&InpHistoryBars<=10000&&
      InpVisibleLargePivots>=2&&InpVisibleLargePivots<=100&&InpRecentPatterns>=1&&InpRecentPatterns<=5&&
      InpHierarchyDepth>=4&&InpHierarchyDepth<=16&&InpHierarchyNodes>=100&&InpHierarchyNodes<=5000&&
      InpWorkLimit>=10000&&InpWorkLimit<=200000&&InpCandidateLimit>=6&&InpCandidateLimit<=48&&
      InpLabelSize>=6&&InpLabelSize<=20&&MathIsValidNumber(InpLabelGap)&&InpLabelGap>=.05&&InpLabelGap<=5&&
      MathIsValidNumber(InpLabelRows)&&InpLabelRows>=.1&&InpLabelRows<=5&&InpBoundaryForward>=0&&InpBoundaryForward<=200&&
      InpFibonacciForward>=1&&InpFibonacciForward<=200&&InpProjectionHorizon>=1&&InpProjectionHorizon<=200&&
      (int)InpFibonacciDegree>=0&&(int)InpFibonacciDegree<=2&&InpProjectionButtonRight>=0&&InpProjectionButtonRight<=2000&&InpProjectionButtonTop>=0&&InpProjectionButtonTop<=2000&&
      InpHiddenMinBars>=1&&InpHiddenMaxBars>=InpHiddenMinBars&&InpHiddenMaxBars<=10000;
}
void ZWConfigure()
{
   ZWDefaults(g_options);g_options.deviation=InpLargeReversal;g_options.factor=InpSubwaveDivisor;
   g_options.depth=InpLargeDepth;g_options.child_depth=InpChildDepth;g_options.history=InpHistoryBars;
   g_options.max_depth=InpHierarchyDepth;g_options.max_nodes=InpHierarchyNodes;g_options.work_limit=InpWorkLimit;
   g_options.candidate_limit=InpCandidateLimit;g_options.recent_patterns=InpRecentPatterns;
   g_options.subwaves=InpNestedSubwaves;g_options.hierarchy=InpHierarchy;g_options.divergence=InpDivergence;
   g_options.triangles=InpTriangles;g_options.abc=InpABC;g_options.impulses=InpImpulses;g_options.diagonals=InpDiagonals;
   g_options.combinations=InpCombinations;g_options.truncation=InpTruncation;g_options.extensions=InpExtensions;
   g_options.show_developing=InpDeveloping;g_options.show_micro=InpMicroCounting;g_options.capture_micro_paths=true;g_options.show_hidden=InpHiddenDivergence;
   g_options.hidden_min_bars=InpHiddenMinBars;g_options.hidden_max_bars=InpHiddenMaxBars;
   g_options.hidden_extremes=InpHiddenSwingExtremes;g_options.hidden_same_side=InpHiddenSameSide;
   ZWTargetDefaults(g_targetOptions);g_targetOptions.fibonacci=InpFibonacci;g_targetOptions.degree=(int)InpFibonacciDegree;
   g_targetOptions.next_wave=InpFibonacciNext;g_targetOptions.developing=InpDeveloping;g_targetOptions.larry=InpLarryPull;
   g_targetOptions.categories[0]=InpUncommon;g_targetOptions.categories[1]=InpMostCommon;g_targetOptions.categories[2]=InpCommon;g_targetOptions.categories[3]=InpVeryCommon;
   g_targetOptions.rare=InpRare;g_targetOptions.shade=InpFibonacciShade;g_targetOptions.forward=InpFibonacciForward;
   g_targetOptions.projection=InpProjection;g_targetOptions.alternative=InpProjectionAlternative;
   g_targetOptions.levels=InpProjectionLevels;g_targetOptions.horizon=InpProjectionHorizon;
   g_draw.separate=InpSeparateLabels;g_draw.gap=InpLabelGap;g_draw.row=InpLabelRows;
}
color ZWInk(const int degree){return degree==0?InpLargeColor:degree==1?InpChildColor:InpMicroColor;}
string ZWDegreeName(const int degree){return degree==0?string("Large"):degree==1?string("Child"):string("Micro");}
int ZWVisible()
{
   if(ArraySize(g_zw.streams)==0)return 0;int n=ArraySize(g_zw.streams[0].pivots);
   return n>InpVisibleLargePivots?g_zw.streams[0].pivots[n-InpVisibleLargePivots].b:0;
}
void ZWLabel(const ZWPivot &p,const int degree,const string caption,const string tip)
{
   string key=(string)degree+string("_")+(string)p.t+string("_")+DoubleToString(p.p,16)+string("_")+(string)p.hi;
   string label=ZWNotation(caption,(int)InpBaseDegree+degree,InpDegreeNotation);
   g_draw.Text(p.t,p.p,label,ZWInk(degree),InpLabelSize,p.hi?1:-1,tip,key);
}
double ZWATR()
{
   int n=ArraySize(g_zw.rates);double sum=0;int count=0;
   for(int i=(int)MathMax(1,n-14);i<n;i++){sum+=MathMax(g_zw.rates[i].high-g_zw.rates[i].low,MathMax(MathAbs(g_zw.rates[i].high-g_zw.rates[i-1].close),MathAbs(g_zw.rates[i].low-g_zw.rates[i-1].close)));count++;}
   return MathMax(g_zw.mintick*10,count>0?sum/count:MathAbs(g_livePrice)*.001);
}
bool ZWShowPattern(const int i)
{
   if(g_patterns[i].degree==2&&!InpMicroStructures)return false;
   if(!g_proofs[i].designatedVerified||(g_patterns[i].resolvedWave>0&&!g_proofs[i].subdivisionVerified))return false;
   if(InpCompleteHierarchyOnly&&g_proofs[i].status!=string("valid"))return false;
   if(InpSubdivisionOnly&&!g_proofs[i].subdivisionVerified)return false;
   return g_patterns[i].count>1&&g_patterns[i].points[0].b>=ZWVisible();
}
string ZWFamilyCaption(string family)
{
   StringReplace(family,string("Impulse Truncated Fifth"),string("Impulse · fifth terpotong"));
   StringReplace(family,string("Impulse Extension"),string("Impulse · ekstensi"));
   StringReplace(family,string("Contracting"),string("kontraksi"));StringReplace(family,string("Expanding"),string("ekspansi"));
   StringReplace(family,string("Running"),string("berjalan"));StringReplace(family,string("Regular"),string("reguler"));
   return family;
}
void ZWDrawPattern(const int index)
{
   ZWPattern p=g_patterns[index];ZWProof proof=g_proofs[index];color ink=ZWInk(p.degree);
   if(StringLen(proof.resolvedFamily)>0)p.family=proof.resolvedFamily;
   bool impulse=StringFind(p.family,string("Impulse"))==0,triangle=StringFind(p.family,string("Triangle"))==0;
   bool combo=StringFind(p.family,string("Double"))==0||StringFind(p.family,string("Triple"))==0;
   string kind=proof.subdivisionVerified?string("S"):string("G");
   string tip=ZWFamilyCaption(p.family)+string(" | ")+ZWDegreeName(p.degree)+string(" | ")+kind+string("\nHierarki: ")+proof.status+string("\n")+proof.reason+string("\nG = geometri; S = subdivisi terbukti; H = hierarki penuh valid.\nHarga dan waktu titik adalah koordinat candle asli.");
   for(int j=1;j<p.count;j++)
   {
      if(!impulse||InpImpulseLines)g_draw.Line(p.points[j-1].t,p.points[j-1].p,p.points[j].t,p.points[j].p,ink,proof.subdivisionVerified?STYLE_SOLID:STYLE_DASH);
      string name=impulse||StringFind(p.family,string("Diagonal"))>=0?(string)j:triangle?StringSubstr(string("ABCDE"),j-1,1):combo?(j==4?string("X2"):StringSubstr(string("WXYXZ"),j-1,1)):StringSubstr(string("ABC"),j-1,1);
      ZWLabel(p.points[j],p.degree,name,tip);
   }
   if(triangle||StringFind(p.family,string("Diagonal"))>=0)
   {
      int seconds=PeriodSeconds(_Period);datetime right=p.points[p.count-1].t+(datetime)(seconds*InpBoundaryForward);
      for(int k=1;k<=2;k++)
      {
         int e=k+2;double dt=(double)(p.points[e].t-p.points[k].t);
         if(dt>0){double price=p.points[e].p+(p.points[e].p-p.points[k].p)*(double)(right-p.points[e].t)/dt;g_draw.Line(p.points[k].t,p.points[k].p,right,price,ink,STYLE_DASH);}
      }
   }
   if(InpPatternTitles)
   {
      ZWPivot end=p.points[p.count-1];string caption=ZWFamilyCaption(p.family)+string(" · ")+kind+(proof.status==string("valid")?string("/H"):string(""))+string(" · ")+ZWDegreeName(p.degree);
      g_draw.Text(end.t,end.p,caption,ink,InpLabelSize,end.hi?1:-1,tip);
   }
}
void ZWPaint()
{
   if(!g_owner||!g_ready)return;
   g_draw.Begin();g_draw.atr=ZWATR();ZWProjectionButton();
   int visible=ZWVisible(),n=ArraySize(g_zw.rates);if(n==0)return;
   int seconds=PeriodSeconds(_Period);if(seconds<1)seconds=60;
   if(!InpCompleteHierarchyOnly&&!InpSubdivisionOnly)g_targets.Draw(g_zw,g_draw,g_targetOptions,g_livePrice,g_formingTime,seconds);
   for(int d=0;d<2&&d<ArraySize(g_zw.streams);d++)if(d==0?InpLargeZigZag:InpChildZigZag)
      for(int i=1;i<ArraySize(g_zw.streams[d].pivots);i++)if(g_zw.streams[d].pivots[i-1].b>=visible)
         g_draw.Line(g_zw.streams[d].pivots[i-1].t,g_zw.streams[d].pivots[i-1].p,g_zw.streams[d].pivots[i].t,g_zw.streams[d].pivots[i].p,ZWInk(d));
   if(InpDivergence&&!InpCompleteHierarchyOnly&&!InpSubdivisionOnly)for(int i=0;i<ArraySize(g_zw.links);i++)
   {
      ZWDivLink link=g_zw.links[i];if(link.anchor.b<visible||(link.hidden?!InpHiddenDivergence:!InpRegularDivergence))continue;
      color ink=link.endpoint.hi?39167:16760576;
      g_draw.Line(link.anchor.t,link.anchor.p,link.endpoint.t,link.endpoint.p,ink,STYLE_DOT);
      g_draw.Text(link.endpoint.t,link.endpoint.p,(link.hidden?string("H"):string(""))+(link.endpoint.hi?string("Bear"):string("Bull"))+string(" · ")+ZWDegreeName(link.degree),ink,8,link.endpoint.hi?1:-1,string("Divergence MACD; tidak mengubah bukti Elliott."));
   }
   if(!InpCompleteHierarchyOnly&&!InpSubdivisionOnly)for(int i=0;i<ArraySize(g_zw.counts);i++)
   {
      ZWCount c=g_zw.counts[i];if(c.pivot.b>=visible&&c.degree<3&&(c.degree!=2||InpMicroCounting))ZWLabel(c.pivot,c.degree,c.wave_name,string("Counting ")+ZWDegreeName(c.degree)+string("\n? = berkembang; pivot memakai candle selesai."));
   }
   for(int i=0;i<ArraySize(g_patterns);i++)if(ZWShowPattern(i))
   {
      bool superseded=false;
      for(int j=0;j<ArraySize(g_patterns);j++)if(i!=j&&ZWShowPattern(j)&&g_patterns[i].degree==g_patterns[j].degree&&g_patterns[i].points[0].t==g_patterns[j].points[0].t&&g_patterns[i].points[g_patterns[i].count-1].t==g_patterns[j].points[g_patterns[j].count-1].t)
      {
         if((g_patterns[i].family==string("Impulse")&&StringFind(g_patterns[j].family,string("Extension"))>=0)||(g_patterns[i].resolvedWave==0&&g_patterns[j].resolvedWave>0&&g_patterns[i].family==g_patterns[j].family)){superseded=true;break;}
      }
      if(!superseded)ZWDrawPattern(i);
   }
   g_draw.Flush();g_lastPaint=GetTickCount64();g_dirty=false;
}
void ZWAnalyze(const MArray<MqlRates>& closed)
{
   double tick=m_tick;
   if(!g_zw.Build(closed,g_options,tick))return;
   g_structures.Scan(g_zw,g_patterns);
   MArray<ZWPattern> queued;int quota=(int)MathMax(2,InpCandidateLimit/3),visible=ZWVisible();
   for(int degree=0;degree<3;degree++)
   {
      if(degree==2&&(!InpNestedSubwaves||!InpMicroStructures))continue;
      int used=0;
      for(int i=0;i<ArraySize(g_patterns)&&used<quota&&ArraySize(queued)<InpCandidateLimit;i++)
      {
         if(g_patterns[i].degree!=degree||g_patterns[i].points[0].b<visible)continue;
         int n=ArraySize(queued);ArrayResize(queued,n+1);queued[n]=g_patterns[i];used++;
      }
   }
   ArrayResize(g_patterns,ArraySize(queued));for(int i=0;i<ArraySize(queued);i++)g_patterns[i]=queued[i];
   int count=ArraySize(g_patterns);ArrayResize(g_proofs,count);
   int hardLimit=g_options.work_limit;
   for(int i=0;i<count;i++)
   {
      // Every candidate receives a share of the remaining proof work.
      int share=(hardLimit-g_zw.work_used)/(count-i);g_zw.opt.work_limit=(int)MathMin(hardLimit,g_zw.work_used+MathMax(0,share));
      g_proofs[i]=g_structures.Validate(g_zw,g_patterns[i]);
   }
   g_zw.opt.work_limit=hardLimit;
   for(int i=0;i<count;i++)if(ZWShowPattern(i))
   {
      ZWPattern p=g_patterns[i];
      if(p.resolvedWave>0)
      {
         string role=p.resolvedWave==4?string("4"):string("B");
         for(int j=ArraySize(g_zw.counts)-1;j>=0;j--)if(g_zw.counts[j].degree==p.degree&&g_zw.counts[j].pivot.t==p.originalEndpoint.t)
         {
            MArray<string> names;string raw=g_zw.counts[j].wave_name;StringReplace(raw,string(" / "),string("|"));StringSplit(raw,'|',names);string retained=string("");
            for(int k=0;k<ArraySize(names);k++){string token=names[k];StringReplace(token,string("?"),string(""));if(token!=role)retained+=(retained==string("")?string(""):string(" / "))+names[k];}
            g_zw.counts[j].wave_name=retained;
         }
      }
      if(StringFind(p.family,string("Triangle"))==0&&p.degree<=2&&!InpCompleteHierarchyOnly)
      {MArray<ZWPivot> points;ArrayResize(points,p.count);for(int j=0;j<p.count;j++)points[j]=p.points[j];g_zw.RecordPath(points,p.degree,false,false,p.family);}
   }
   g_ready=true;g_dirty=true;
}

};
