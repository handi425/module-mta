// This Source Code Form is subject to the Mozilla Public License, v. 2.0.
// https://mozilla.org/MPL/2.0/  XoRonX | Mr Poleks / HPX Markets.
// Native port of the HPX Elliott geometry and bounded G/S/H proof engine.
#ifndef HPX_ZWAVE_STRUCTURES_MQH
#define HPX_ZWAVE_STRUCTURES_MQH
#include "HPXZWaveCore.hpp"

struct ZWSModes { bool zigzag,flat,triangle; };
struct ZWSLeg { string role,hint; bool motive; };
struct ZWSGrammar { MArray<ZWSLeg> legs; string form; };
struct ZWSNode
  {
   int mode,degree,state,observed,special,resolved;
   MArray<ZWPivot> points;
   string family,role,hint,reason,form;
   bool motive,checked,localGeometry,immediate,five,designated,cut;
   MArray<int> children;
   ZWPivot originalEndpoint;
  };

bool ZWSStarts(const string s,const string prefix) { return StringFind(s,prefix)==0; }
bool ZWSEnds(const string s,const string suffix)
  { int n=StringLen(s),k=StringLen(suffix); return n>=k && StringSubstr(s,n-k)==suffix; }
bool ZWSHas(const string s,const string token) { return StringFind(s,token)>=0; }
string ZWSCategory(const string family)
  {
   if(ZWSStarts(family,string("Impulse"))) return string("impulse");
   if(ZWSHas(family,string("Diagonal"))) return string("diagonal");
   if(ZWSStarts(family,string("Triangle"))) return string("triangle");
   if(family==string("Zigzag")) return string("zigzag");
   if(ZWSEnds(family,string("Flat"))) return string("flat");
   if(ZWSStarts(family,string("Double")) || ZWSStarts(family,string("Triple"))) return string("combination");
   return string("unknown");
  }
bool ZWSSame(const ZWPivot &a,const ZWPivot &b,const bool confirmation=true)
  { return a.b==b.b && a.t==b.t && a.p==b.p && a.hi==b.hi && (!confirmation || a.known==b.known); }
int ZWSSpecial(const string family)
  {
   if(ZWSHas(family,string("Truncated"))) return 5;
   if(!ZWSHas(family,string("Extension"))) return -1;
   return ZWSHas(family,string("Wave 1")) ? 1 : ZWSHas(family,string("Wave 3")) ? 3 : ZWSHas(family,string("Wave 5")) ? 5 : -1;
  }
string ZWSRole(string r)
  {
   StringToLower(r); StringReplace(r,string(" "),string("")); StringReplace(r,string("_"),string("")); StringReplace(r,string("-"),string(""));
   if(StringLen(r)==8 && ZWSStarts(r,string("impulse"))) r=StringSubstr(r,7,1);
   if(StringLen(r)==5 && ZWSStarts(r,string("wave"))) r=StringSubstr(r,4,1);
   return r;
  }
bool ZWSTriangleRole(const string role)
  {
   string r=ZWSRole(role);
   return r==string("4") || r==string("b") || r==string("finalx") || r==string("finaly") || r==string("finalz") || r==string("z") || r==string("trianglee");
  }
bool ZWSHint(const string family,const string hint)
  {
   string c=ZWSCategory(family);
   bool motive=c==string("impulse") || c==string("diagonal");
   bool z=family==string("Zigzag") || family==string("Double Zigzag") || family==string("Triple Zigzag");
   if(hint==string("") || hint==string("all") || hint==family) return true;
   if(hint==string("motive")) return motive;
   if(hint==string("corrective")) return !motive;
   if(hint==string("impulse_only")) return family==string("Impulse") || family==string("Impulse Truncated Fifth");
   if(hint==string("Zigzag")) return family==string("Zigzag");
   if(hint==string("Flat")) return c==string("flat");
   if(hint==string("Triangle")) return c==string("triangle");
   if(hint==string("zigzag_only")) return z;
   if(hint==string("triangle_e")) return z || c==string("triangle");
   return false;
  }
bool ZWSAllowed(const string family,const string role,const bool motive,const string hint)
  {
   string c=ZWSCategory(family),r=ZWSRole(role);
   bool okay=true;
   if(r==string("diagonalalternative")) okay=c==string("impulse") || family==string("Zigzag") || family==string("Double Zigzag") || family==string("Triple Zigzag");
   else if(motive)
      okay=c==string("impulse") || (c==string("diagonal") && r!=string("3") && r!=string("diagonalmotive") &&
         (r==string("") || (ZWSHas(family,string("Leading")) && (r==string("1") || r==string("a") || r==string("zigzaga"))) ||
                     (ZWSHas(family,string("Ending")) && (r==string("5") || r==string("c")))));
   else
     {
      okay=c!=string("impulse") && c!=string("diagonal") && c!=string("unknown");
      if(c==string("triangle")) okay=okay && ZWSTriangleRole(role);
      else if(r==string("diagonalzigzag") || ZWSStarts(r,string("triangle")))
         okay=okay && (family==string("Zigzag") || family==string("Double Zigzag") || family==string("Triple Zigzag"));
     }
   if(hint==string("impulse_only")) okay=okay && c==string("impulse");
   else if(hint==string("Zigzag")) okay=okay && family==string("Zigzag");
   else if(hint==string("Flat")) okay=okay && c==string("flat");
   else if(hint==string("Triangle")) okay=okay && c==string("triangle");
   else if(hint==string("zigzag_only") || hint==string("triangle_e"))
      okay=okay && (family==string("Zigzag") || family==string("Double Zigzag") || family==string("Triple Zigzag") ||
                   (hint==string("triangle_e") && c==string("triangle") && ZWSTriangleRole(role)));
   return okay;
  }
double ZWSFit(const double r,const double target)
  { return r>0 && target>0 ? MathExp(-MathAbs(MathLog(r/target))*2) : 0; }
double ZWSBest(const double r,const double a,const double b=0,const double c=0,const double d=0,const double e=0)
  { return MathMax(MathMax(ZWSFit(r,a),ZWSFit(r,b)),MathMax(ZWSFit(r,c),MathMax(ZWSFit(r,d),ZWSFit(r,e)))); }
double ZWSScore(const MArray<ZWPivot>& p,const int n,const int kind)
  {
   if(n<2) return 0;
   double a=MathAbs(p[1].p-p[0].p),sum=0; int terms=0;
   if(a<=0) return 0;
   if(kind==1 || kind==2)
     {
      if(n>=3) {sum+=ZWSBest(MathAbs(p[2].p-p[1].p)/a,.5,.618,.786,.886);terms++;}
      if(n>=4) {sum+=ZWSBest(MathAbs(p[3].p-p[2].p)/a,1,1.618,2,2.618,3);terms++;}
      if(n>=5) {sum+=ZWSBest(MathAbs(p[4].p-p[3].p)/MathAbs(p[3].p-p[2].p),.236,.382);terms++;}
      if(n>=6)
        { double five=MathAbs(p[5].p-p[4].p);sum+=MathMax(ZWSBest(five/MathAbs(p[4].p-p[3].p),1.236,1.618),ZWSBest(five/MathAbs(p[3].p-p[2].p),.5,.618,1));terms++; }
     }
   else
     {
      if(n>=3) {double r=MathAbs(p[2].p-p[1].p)/a;sum+=kind==4 ? ZWSBest(r,.382,.5,.618) : ZWSBest(r,.9,1,1.13);terms++;}
      if(n>=4) {sum+=ZWSBest(MathAbs(p[3].p-p[2].p)/a,.786,1,1.236,1.618);terms++;}
     }
   return terms>0 ? sum/terms : 0;
  }

class CZWStructures
  {
private:
   CZWCore *m_c;
   bool m_stopped;
   MArray<int> m_next;
   MArray<ZWSNode> m_nodes;
   MArray<int> m_stack;

   bool Spend(const int n=1) { bool ok=m_c->Spend(n); if(!ok) m_stopped=true; return ok; }
   bool Basic(const MArray<ZWPivot>& p,const int n)
     {
      if(n<2) return false;
      for(int j=0;j<n;j++)
        {
         if(!Spend() || !m_c->Known(p[j])) return false;
         if(j>0 && (p[j].b<=p[j-1].b || p[j].t<=p[j-1].t || p[j].hi==p[j-1].hi ||
                    (p[j].hi ? p[j].p-p[j-1].p : p[j-1].p-p[j].p)<=m_c->eps)) return false;
        }
      return true;
     }
   bool Geometry(const MArray<ZWPivot>& p,const int n,const int kind)
     {
      double e=m_c->eps; int d=p[0].hi ? -1 : 1;
      for(int j=1;j<n;j++) if((j%2==1 ? d : -d)*(p[j].p-p[j-1].p)<=e) return false;
      if(kind==1 || kind==2)
        {
         if(n>=3 && d*(p[2].p-p[0].p)<=e) return false;
         if(n>=4 && d*(p[3].p-p[1].p)<=e) return false;
         if(n>=5 && d*(p[4].p-p[1].p)<=e) return false;
         if(n>=6)
           {
            double one=MathAbs(p[1].p-p[0].p),three=MathAbs(p[3].p-p[2].p),five=MathAbs(p[5].p-p[4].p);
            if((kind==1 ? d*(p[5].p-p[3].p)<=e : d*(p[5].p-p[3].p)>e) || three+e<MathMin(one,five)) return false;
           }
         return true;
        }
      if(kind==5 && n>=3 && MathAbs(p[2].p-p[1].p)+e<.886*MathAbs(p[1].p-p[0].p)) return false;
      if(n>=4)
        {
         double origin=d*(p[2].p-p[0].p),finish=d*(p[3].p-p[1].p);
         return kind==4 ? origin>e && finish>e : kind==5 ? origin>=-e && finish>e : kind==6 ? origin<-e && finish>e :
                kind==7 ? origin<-e && finish<-e && d*(p[3].p-p[0].p)>e : false;
        }
      return true;
     }
   bool InsideAll(const MArray<ZWPivot>& p,const int n)
     {
      for(int j=1;j<n;j++) if(!Spend() || !m_c->Inside(p[j-1],p[j],MathMin(p[j-1].p,p[j].p),MathMax(p[j-1].p,p[j].p),m_c->eps)) return false;
      return true;
     }
   bool Impulse(const MArray<ZWPivot>& p,const int n,const int kind)
     {
      if(n!=6 || !Spend() || !Geometry(p,n,kind)) return false;
      for(int j=1;j<=5;j+=2) if(!Spend() || !m_c->Inside(p[j-1],p[j],MathMin(p[j-1].p,p[j].p),MathMax(p[j-1].p,p[j].p),m_c->eps)) return false;
      int d=p[0].hi ? -1 : 1;
      for(int j=2;j<=4;j+=2) if(!Spend() || !m_c->Adverse(p[j-1],p[j],d,p[j==2 ? 0 : 1].p,m_c->eps)) return false;
      return true;
     }
   bool ABC(const MArray<ZWPivot>& p,const int n,const int kind)
     {
      if(n!=4 || !Spend() || !Geometry(p,n,kind)) return false;
      int d=p[0].hi ? -1 : 1;
      if(kind==4 && (!Spend() || !m_c->Adverse(p[1],p[2],d,p[0].p,m_c->eps))) return false;
      for(int j=kind==4 ? 1 : 3;j<=3;j+=2) if(!Spend() || !m_c->Inside(p[j-1],p[j],MathMin(p[j-1].p,p[j].p),MathMax(p[j-1].p,p[j].p),m_c->eps)) return false;
      return true;
     }
   string Triangle(const MArray<ZWPivot>& p,const int n)
     {
      if(n!=6 || !Spend()) return string("");
      double e=m_c->eps,d=p[1].p>p[0].p ? 1 : -1;
      double a=d*(p[1].p-p[0].p),b=d*(p[2].p-p[0].p),c=d*(p[3].p-p[0].p),v=d*(p[4].p-p[0].p),z=d*(p[5].p-p[0].p);
      double tolerance=MathMax(e*2,a*.05);
      bool contract=c<a-tolerance && v>b+tolerance && z<c-e;
      bool barrierLow=c<a-tolerance && MathAbs(v-b)<=tolerance && z<c-e;
      bool barrierHigh=MathAbs(c-a)<=tolerance && v>b+tolerance && z<c+tolerance;
      bool expand=c>a+tolerance && v<b-tolerance && z>c+e;
      double upper=(c-a)/(p[3].b-p[1].b),lower=(v-b)/(p[4].b-p[2].b);
      double upperE=a+upper*(p[5].b-p[1].b),lowerE=b+lower*(p[5].b-p[2].b);
      string morphology=string("");
      if(a>e && upperE>lowerE+e && z>lowerE-tolerance && z<=upperE+tolerance)
        {
         if((contract || barrierLow || barrierHigh) && upper<lower) morphology=barrierLow || barrierHigh ? string("Barrier") : b<-e ? string("Running contracting") : string("Contracting");
         else if(expand && upper>lower) morphology=string("Expanding");
        }
      if(morphology==string("")) return string("");
      for(int j=1;j<=5;j++)
        {
         int bound=j==5 && morphology!=string("Expanding") ? 3 : j;
         if(!Spend() || !m_c->Inside(p[j-1],p[j],MathMin(p[j-1].p,p[bound].p),MathMax(p[j-1].p,p[bound].p),e)) return string("");
        }
      return morphology;
     }
   string Diagonal(const MArray<ZWPivot>& p,const int n,bool &truncated)
     {
      truncated=false;
      if(n!=6 || !Spend() || !InsideAll(p,n)) return string("");
      double e=m_c->eps,d=p[1].p>p[0].p ? 1 : -1,x[6];
      for(int j=0;j<6;j++) x[j]=d*(p[j].p-p[0].p);
      if(!(x[2]>e && x[3]>x[1]+e && x[4]>x[2]+e && x[4]<x[1]-e)) return string("");
      double one=MathAbs(x[1]),two=MathAbs(x[2]-x[1]),three=MathAbs(x[3]-x[2]),four=MathAbs(x[4]-x[3]),five=MathAbs(x[5]-x[4]);
      double upper=(x[3]-x[1])/(p[3].b-p[1].b),lower=(x[4]-x[2])/(p[4].b-p[2].b);
      double u4=x[1]+upper*(p[4].b-p[1].b),u5=x[1]+upper*(p[5].b-p[1].b),l5=x[2]+lower*(p[5].b-p[2].b);
      if(three+e<MathMin(one,five) || MathMin(upper,lower)<=0 || u4<=x[4]+e || u5<=l5+e) return string("");
      truncated=x[5]<=x[3]+e;
      if(five<MathMin(one,three)-e && two>four+e && upper<lower) return string("Contracting");
      if(three>one+e && five>three+e && four>two+e && upper>lower && !truncated) return string("Expanding");
      return string("");
     }
   bool Extension(const MArray<ZWPivot>& p,const int wave)
     {
      double other=0;
      for(int j=1;j<=5;j+=2) if(j!=wave) other=MathMax(other,MathAbs(p[j].p-p[j-1].p));
      return MathAbs(p[wave].p-p[wave-1].p)+m_c->eps>=1.618*other;
     }
   bool ComboProgress(const MArray<ZWPivot>& p,const int n)
     {
      int d=p[0].hi ? -1 : 1;
      for(int j=1;j<n-2;j+=2)
         if(!Spend() || d*(p[j+1].p-p[j-1].p)<=m_c->eps || d*(p[j+2].p-p[j].p)<=m_c->eps || !m_c->Adverse(p[j],p[j+1],d,p[j-1].p,m_c->eps)) return false;
      return true;
     }
   void AddCandidate(MArray<ZWPattern>& out,const string family,const MArray<ZWPivot>& p,const int n,const int degree,const double score,const string hint,const int resolved=0)
     {
      if(!ZWSHint(family,hint) || !Spend()) return;
      for(int i=0;i<ArraySize(out);i++)
        {
         bool same=out[i].family==family && out[i].count==n;
         for(int j=0;same && j<n;j++) same=out[i].points[j].b==p[j].b;
         if(same) return;
        }
      int k=ArraySize(out); if(k>=128) {m_stopped=true;return;}
      ArrayResize(out,k+1); out[k].family=family;out[k].count=n;out[k].degree=degree;out[k].score=score;out[k].resolvedWave=resolved;
      ZeroMemory(out[k].originalEndpoint);
      for(int j=0;j<n;j++) out[k].points[j]=p[j];
     }
   void Local(const MArray<ZWPivot>& p,const int n,const int degree,const string hint,MArray<ZWPattern>& out)
     {
      if(!Basic(p,n)) return;
      if(n==6)
        {
         for(int kind=1;kind<=2;kind++) if(Impulse(p,n,kind))
           {
            double score=ZWSScore(p,n,kind);
            AddCandidate(out,kind==1 ? string("Impulse") : string("Impulse Truncated Fifth"),p,n,degree,score,hint);
            if(kind==1) for(int wave=1;wave<=5;wave+=2) if(Extension(p,wave)) AddCandidate(out,string("Impulse Wave ")+(string)wave+string(" Extension"),p,n,degree,score,hint);
           }
         bool truncated=false;string diag=Diagonal(p,n,truncated);
         if(diag!=string(""))
           {
            string family=truncated ? string("Ending Diagonal ")+diag :
               (ZWSStarts(hint,string("Leading Diagonal")) || ZWSStarts(hint,string("Ending Diagonal"))) ? (ZWSEnds(hint,diag) ? hint : string("")) : string("Leading/Ending Diagonal ")+diag;
            if(family!=string("")) AddCandidate(out,family,p,n,degree,.5,hint);
           }
         string triangle=Triangle(p,n);
         if(triangle!=string("")) AddCandidate(out,string("Triangle ")+triangle,p,n,degree,.5,hint);
        }
      if(n==4) for(int kind=4;kind<=7;kind++) if(ABC(p,n,kind))
         AddCandidate(out,kind==4 ? string("Zigzag") : kind==5 ? string("Regular Flat") : kind==6 ? string("Expanded Flat") : string("Running Flat"),p,n,degree,ZWSScore(p,n,kind),hint);
      if(n==4 || n==6)
        {
         string prefix=n==6 ? string("Triple") : string("Double");
         if(ComboProgress(p,n)) AddCandidate(out,prefix+string(" Zigzag"),p,n,degree,.5,hint);
         AddCandidate(out,prefix+string(" Three"),p,n,degree,.5,hint);
        }
     }
   int Bound(const int degree,const int index,const bool right)
     {
      int lo=0,hi=ArraySize(m_c->streams[degree].pivots);
      while(lo<hi && Spend())
        {int mid=(lo+hi)/2,at=m_c->streams[degree].pivots[mid].b;if(at<index || (right && at==index))lo=mid+1;else hi=mid;}
      return lo;
     }
   int Resolve(const MArray<ZWPivot>& p,const int n,const int degree,MArray<ZWPivot>& alternative,ZWPivot &original)
     {
      ArrayResize(alternative,n);ArrayCopy(alternative,p,0,0,n);ZeroMemory(original);
      if(!m_c->opt.subwaves || degree+1>=ArraySize(m_c->streams) || (n!=4 && n!=6)) return 0;
      int at=n==6 ? 4 : 2;
      if(n==6 && !Geometry(p,5,1)) return 0;
      int left=Bound(degree+1,p[at-1].b,true),right=Bound(degree+1,p[at+1].b,false);
      if(right-left<5) return 0;
      ZWPivot endpoint=m_c->streams[degree+1].pivots[left+4];
      if(endpoint.b<=p[at].b || endpoint.hi!=p[at].hi || !m_c->Known(endpoint)) return 0;
      MArray<ZWPivot> triangle=MArray<ZWPivot>(6);triangle[0]=p[at-1];
      for(int j=0;j<5;j++) triangle[j+1]=m_c->streams[degree+1].pivots[left+j];
      if(!Basic(triangle,6) || Triangle(triangle,6)==string("")) return 0;
      alternative[at]=endpoint;
      bool valid=Basic(alternative,n);
      if(valid && n==6) valid=Geometry(alternative,5,1) && Spend() && m_c->Adverse(p[at-1],endpoint,p[0].hi ? -1 : 1,p[1].p,m_c->eps);
      if(!valid) {alternative[at]=p[at];return 0;}
      original=p[at];return at;
     }
   bool HintLegs(const string hint,const int legs)
     {
      string c=ZWSCategory(hint);
      bool five=hint==string("motive") || hint==string("impulse_only") || hint==string("Triangle") || c==string("impulse") || c==string("diagonal") || c==string("triangle") || ZWSStarts(hint,string("Triple"));
      bool three=hint==string("Zigzag") || hint==string("Flat") || c==string("flat") || ZWSStarts(hint,string("Double"));
      return five ? legs==5 : three ? legs==3 : true;
     }
   void Candidates(const MArray<ZWPivot>& p,const int n,const int degree,const string hint,MArray<ZWPattern>& out)
     {
      ArrayResize(out,0);m_stopped=false;
      if(n>50) {m_stopped=true;return;}
      if(n<4 || !Basic(p,n)) return;
      int attempts=0;
      for(int pass=0;pass<2 && !m_stopped;pass++)
        {
         int legs=pass==0 ? 3 : 5,k=legs-1;
         if(n<legs+1 || !HintLegs(hint,legs)) continue;
         MArray<int> idx=MArray<int>(4); for(int j=0;j<k;j++) idx[j]=j+1;
         bool more=true;
         while(more && !m_stopped)
           {
            if(++attempts>128 || !Spend()) {m_stopped=true;break;}
            MArray<ZWPivot> selected=MArray<ZWPivot>(6);selected[0]=p[0];selected[legs]=p[n-1];
            for(int j=0;j<k;j++) selected[j+1]=p[idx[j]];
            Local(selected,legs+1,degree,hint,out);
            string category=ZWSCategory(hint);
            bool any=hint==string("") || hint==string("all");
            bool mayResolve=legs==5 ? any || hint==string("motive") || hint==string("impulse_only") || category==string("impulse") :
                any || hint==string("corrective") || hint==string("Zigzag") || hint==string("Flat") || hint==string("zigzag_only") || hint==string("triangle_e") || category==string("flat");
            if(mayResolve && !m_stopped)
              {
               MArray<ZWPivot> alternative;ZWPivot original;int resolved=Resolve(selected,legs+1,degree,alternative,original);
               if(resolved>0)
                 {
                  MArray<ZWPattern> trials;Local(alternative,legs+1,degree,hint,trials);
                  for(int q=0;q<ArraySize(trials);q++)
                    {
                     string c=ZWSCategory(trials[q].family);
                     if((c==string("impulse") && resolved==4) || ((c==string("zigzag") || c==string("flat")) && resolved==2))
                       {
                        int before=ArraySize(out);AddCandidate(out,trials[q].family,alternative,legs+1,degree,trials[q].score,hint,resolved);
                        if(ArraySize(out)>before) out[before].originalEndpoint=original;
                       }
                    }
                 }
              }
            int cursor=k-1;
            while(cursor>=0 && idx[cursor]>=n-2-(k-1-cursor)) cursor--;
            if(cursor<0) more=false;
            else {idx[cursor]++;for(int j=cursor+1;j<k;j++)idx[j]=idx[j-1]+1;}
           }
        }
     }
   ZWSModes ComponentModes(const int degree,const ZWPivot &start,const ZWPivot &finish)
     {
      ZWSModes mode;ZeroMemory(mode);
      int left=Bound(degree,start.b,true),right=Bound(degree,finish.b,false),count=right-left+2;
      if(count!=4 && count!=6) return mode;
      MArray<ZWPivot> p=MArray<ZWPivot>(6);p[0]=start;p[count-1]=finish;
      for(int j=left;j<right;j++) p[j-left+1]=m_c->streams[degree].pivots[j];
      if(!Basic(p,count) || !InsideAll(p,count)) return mode;
      if(count==4)
        {mode.zigzag=ABC(p,count,4);for(int kind=5;kind<=7 && !mode.flat;kind++)mode.flat=ABC(p,count,kind);}
      else mode.triangle=Triangle(p,count)!=string("");
      return mode;
     }
   void ComboModes(const MArray<ZWPivot>& p,const int n,const int degree,bool &zigzag,bool &three)
     {
      zigzag=false;three=false;
      if(degree+1>=ArraySize(m_c->streams)) return;
      int count=n-1;MArray<ZWSModes> modes=MArray<ZWSModes>(5);
      for(int j=0;j<count;j++)
        {modes[j]=ComponentModes(degree+1,p[j],p[j+1]);if(!modes[j].zigzag && !modes[j].flat && !modes[j].triangle)return;}
      int forced=0;
      for(int j=1;j<count-1;j+=2) if(!modes[j].zigzag && !modes[j].flat)
        {if(j==count-2 && modes[j].triangle) forced++;else return;}
      int actions=(count+1)/2,variants=actions==3 ? 27 : 9;
      bool progress=ComboProgress(p,n);
      for(int code=0;code<variants && Spend();code++)
        {
         int rem=code,zigs=0,triangles=forced;bool allowed=true;
         for(int j=0;j<actions;j++)
           {int choice=rem%3;rem/=3;ZWSModes mode=modes[j*2];allowed=allowed && (choice==0 ? mode.zigzag : choice==1 ? mode.flat : mode.triangle && j==actions-1);zigs+=choice==0 ? 1 : 0;triangles+=choice==2 ? 1 : 0;}
         if(allowed && triangles<=1) {if(zigs==actions && progress)zigzag=true;if(zigs<=1 && zigs!=actions)three=true;}
        }
     }
   int Group(const string f)
     {return ZWSHas(f,string("Truncated")) ? 2 : ZWSHas(f,string("Extension")) ? 1 : ZWSStarts(f,string("Impulse")) ? 0 : ZWSHas(f,string("Diagonal")) ? 3 : ZWSStarts(f,string("Double")) || ZWSStarts(f,string("Triple")) ? 4 : ZWSStarts(f,string("Triangle")) ? 5 : 6;}
   bool Enabled(const int group)
     {return group==0 ? m_c->opt.impulses : group==1 ? m_c->opt.extensions : group==2 ? m_c->opt.truncation : group==3 ? m_c->opt.diagonals : group==4 ? m_c->opt.combinations : group==5 ? m_c->opt.triangles : m_c->opt.abc;}
   // Hierarchy implementation follows below. Geometry is deliberately separate
   // from finite immediate-subdivision S and recursively observed hierarchy H.
   string BasicReason(const MArray<ZWPivot>& p,const int n)
     {
      if(n<2) return string("missing_pattern_points");
      for(int j=0;j<n;j++)
        {
         if(!Spend()) return string("work_limit");
         if(!m_c->Known(p[j])) return string("unknown_or_unclosed_pivot");
         if(j>0)
           {
            if(p[j].b==p[j-1].b && p[j].hi!=p[j-1].hi) return string("ambiguous_intrabar_order");
            if(p[j].b<=p[j-1].b || p[j].t<=p[j-1].t || p[j].hi==p[j-1].hi ||
               (p[j].hi ? p[j].p-p[j-1].p : p[j-1].p-p[j].p)<=m_c->eps) return string("invalid_pivot_order");
           }
        }
      return string("");
     }
   bool Unresolved(const string r)
     {
      return r==string("work_limit") || r==string("candidate_limit") || r==string("node_limit") || r==string("depth_limit") || r==string("hierarchy_disabled") ||
         r==string("resolution_exhausted") || r==string("missing_pattern_points") || r==string("missing_subdivision") || r==string("partial_subdivision") ||
         r==string("unknown_or_unclosed_pivot") || r==string("ambiguous_intrabar_order");
     }
   bool SamePoints(const MArray<ZWPivot>& a,const int an,const MArray<ZWPivot>& b,const int bn,const bool confirmation=true)
     {
      if(an!=bn) return false;
      for(int j=0;j<an;j++) if(!Spend() || !ZWSSame(a[j],b[j],confirmation)) return false;
      return true;
     }
   bool Contains(const int degree,const ZWPivot &point)
     {
      if(degree<0 || degree>=ArraySize(m_c->streams)) return false;
      for(int j=0;j<ArraySize(m_c->streams[degree].pivots);j++)
        {if(!Spend())return false;if(ZWSSame(m_c->streams[degree].pivots[j],point))return true;}
      return false;
     }
   int NextDegree(const int degree)
     {
      if(degree<0 || degree>=ArraySize(m_c->streams)) return -1;
      if(m_next[degree]!=-2) return m_next[degree];
      int n=ArraySize(m_c->streams[degree].pivots);
      for(int j=degree+1;j<ArraySize(m_c->streams);j++)
        {
         bool same=SamePoints(m_c->streams[degree].pivots,n,m_c->streams[j].pivots,ArraySize(m_c->streams[j].pivots),false);
         if(m_c->work_used>=m_c->opt.work_limit) return -3;
         if(!same) {m_next[degree]=j;return j;}
        }
      m_next[degree]=-1;return -1;
     }
   string Span(const int degree,const ZWPivot &start,const ZWPivot &finish,MArray<ZWPivot>& out)
     {
      ArrayResize(out,1);out[0]=start;string reason=string("");
      if(degree<0 || degree>=ArraySize(m_c->streams)) reason=string("resolution_exhausted");
      else
        {
         bool havePrevious=false;ZWPivot previous;ZeroMemory(previous);
         for(int j=0;j<ArraySize(m_c->streams[degree].pivots) && reason==string("");j++)
           {
            if(!Spend()) {reason=string("work_limit");break;}
            ZWPivot p=m_c->streams[degree].pivots[j];
            if(p.b<start.b || p.b>finish.b) continue;
            bool duplicate=havePrevious && ZWSSame(previous,p);
            if(havePrevious && p.b<previous.b) reason=string("invalid_stream_order");
            else if(havePrevious && p.b==previous.b && !duplicate) reason=string("ambiguous_intrabar_order");
            else if((p.b==start.b && (p.t!=start.t || p.p!=start.p || p.hi!=start.hi)) ||
                    (p.b==finish.b && (p.t!=finish.t || p.p!=finish.p || p.hi!=finish.hi))) reason=string("ambiguous_intrabar_order");
            else if(!duplicate && p.b>start.b && p.b<finish.b)
              {int n=ArraySize(out);if(n>=49)reason=string("candidate_limit");else {ArrayResize(out,n+1);out[n]=p;}}
            previous=p;havePrevious=true;
           }
        }
      int n=ArraySize(out);ArrayResize(out,n+1);out[n]=finish;
      return reason;
     }
   ZWSNode Node(const int mode,const MArray<ZWPivot>& points,const int n,const int degree,const string family,const string role,const string hint,const bool motive)
     {
      ZWSNode node;ZeroMemory(node);node.mode=mode;node.degree=degree;node.family=family;node.role=role;node.hint=hint;node.motive=motive;
      node.state=1;node.observed=1;node.designated=true;node.special=-1;node.resolved=-1;node.reason=string("missing_subdivision");
      ArrayResize(node.points,n);for(int j=0;j<n;j++)node.points[j]=points[j];
      return node;
     }
   bool Push(ZWSNode &parent,const ZWSNode &child,const bool expand=true)
     {
      int n=ArraySize(m_nodes);
      if(n>=m_c->opt.max_nodes || !Spend())
        {parent.cut=true;parent.reason=n>=m_c->opt.max_nodes ? string("node_limit") : string("work_limit");return false;}
      ArrayResize(m_nodes,n+1);m_nodes[n]=child;
      int k=ArraySize(parent.children);ArrayResize(parent.children,k+1);parent.children[k]=n;
      if(expand) {k=ArraySize(m_stack);ArrayResize(m_stack,k+1);m_stack[k]=n;}
      return true;
     }
   void AddLeg(ZWSGrammar &g,const string role,const bool motive,const string hint)
     {int n=ArraySize(g.legs);ArrayResize(g.legs,n+1);g.legs[n].role=role;g.legs[n].motive=motive;g.legs[n].hint=hint;}
   void AddGrammar(MArray<ZWSGrammar>& out,const ZWSGrammar &g)
     {int n=ArraySize(out);ArrayResize(out,n+1);out[n]=g;}
   void Grammars(const string family,const string role,const int resolved,MArray<ZWSGrammar>& out)
     {
      ArrayResize(out,0);string c=ZWSCategory(family);int special=ZWSSpecial(family);
      ZWSGrammar g;g.form=string("");
      if(c==string("impulse"))
        {
         for(int j=1;j<=5;j++) {bool m=j%2==1;AddLeg(g,(string)j,m,j==resolved ? string("Triangle") : j==special ? string("impulse_only") : m ? string("motive") : string("corrective"));}
         AddGrammar(out,g);
        }
      else if(c==string("zigzag") || c==string("flat"))
        {
         AddLeg(g,c==string("zigzag") ? string("zigzag_A") : string("flat_A"),c==string("zigzag"),c==string("zigzag") ? string("motive") : string("corrective"));
         AddLeg(g,string("B"),false,resolved==2 ? string("Triangle") : string("corrective"));AddLeg(g,string("C"),true,string("motive"));AddGrammar(out,g);
        }
      else if(c==string("triangle"))
        {
         MArray<string> names={string("A"),string("B"),string("C"),string("D"),string("E")};
         for(int j=0;j<5;j++)AddLeg(g,string("triangle_")+names[j],false,j==4 ? string("triangle_e") : string("zigzag_only"));
         AddGrammar(out,g);
        }
      else if(c==string("diagonal"))
        {
         string r=ZWSRole(role);
         bool leading=ZWSHas(family,string("Leading")) && r!=string("5") && r!=string("c");
         bool ending=ZWSHas(family,string("Ending")) && r!=string("1") && r!=string("a") && r!=string("zigzaga");
         if(leading)
           {
            g.form=string("leading_five");
            for(int j=1;j<=5;j++) {bool m=j%2==1;AddLeg(g,m ? (string)j : string("diagonal_zigzag"),m,j==3 ? string("impulse_only") : m ? string("motive") : string("zigzag_only"));}
            AddGrammar(out,g);ArrayResize(g.legs,0);
           }
         if(leading || ending)
           {g.form=string("diagonal_three");for(int j=0;j<5;j++)AddLeg(g,string("diagonal_zigzag"),false,string("zigzag_only"));AddGrammar(out,g);}
        }
      else if(c==string("combination"))
        {
         int count=ZWSStarts(family,string("Triple")) ? 5 : 3;
         if(ZWSEnds(family,string("Zigzag")))
           {
            for(int j=0;j<count;j++) AddLeg(g,j==count-2 ? string("final_X") : string("component"),false,j%2==0 ? string("Zigzag") : string("corrective"));
            AddGrammar(out,g);
           }
         else
           {
            int components=(count+1)/2,variants=components==3 ? 27 : 9;
            MArray<string> names={string("W"),string("X"),string("Y"),string("X2"),string("Z")};MArray<string> hints={string("Zigzag"),string("Flat"),string("Triangle")};
            for(int code=0;code<variants;code++)
              {
               int rem=code,choices[3],zigzags=0;bool triangle=false,valid=true;
               for(int j=0;j<components;j++) {int choice=rem%3;rem/=3;choices[j]=choice;zigzags+=choice==0 ? 1 : 0;triangle=triangle || choice==2;valid=valid && (choice!=2 || j==components-1);}
               if(!valid || zigzags>1)continue;
               ArrayResize(g.legs,0);
               for(int j=0;j<count;j++)
                 {
                  bool connector=j%2==1;
                  string childRole=connector ? (j==count-2 && !triangle ? string("final_X") : string("component")) : j==count-1 ? string("final_")+names[j] : string("component");
                  AddLeg(g,childRole,false,connector ? string("corrective") : hints[choices[j/2]]);
                 }
               AddGrammar(out,g);
              }
           }
        }
     }
   bool Fixed(const MArray<ZWPivot>& p,const int n,const string family,const int degree)
     {
      if(degree<0 || degree>=ArraySize(m_c->streams)) return false;
      string c=ZWSCategory(family);
      if(c==string("impulse"))
        {
         bool named=family==string("Impulse") || family==string("Impulse Truncated Fifth") || family==string("Impulse Wave 1 Extension") || family==string("Impulse Wave 3 Extension") || family==string("Impulse Wave 5 Extension");
         return named && n==6 && Impulse(p,n,ZWSHas(family,string("Truncated")) ? 2 : 1) && (!ZWSHas(family,string("Extension")) || Extension(p,ZWSSpecial(family)));
        }
      if(c==string("zigzag") || c==string("flat"))
        {int kind=family==string("Zigzag") ? 4 : family==string("Regular Flat") ? 5 : family==string("Expanded Flat") ? 6 : family==string("Running Flat") ? 7 : 0;return n==4 && kind!=0 && ABC(p,n,kind);}
      if(c==string("triangle")) {string morph=Triangle(p,n);return morph!=string("") && (family==string("Triangle") || family==string("Triangle ")+morph);}
      if(c==string("diagonal"))
        {
         bool truncated=false;string morph=Diagonal(p,n,truncated);
         bool named=family==string("Leading Diagonal ")+morph || family==string("Ending Diagonal ")+morph || family==string("Leading/Ending Diagonal ")+morph;
         return morph!=string("") && named && (!truncated || family==string("Ending Diagonal ")+morph);
        }
      if(c==string("combination"))
        {
         bool triple=ZWSStarts(family,string("Triple"));string prefix=triple ? string("Triple") : string("Double");
         bool named=family==prefix+string(" Zigzag") || family==prefix+string(" Three") || family==prefix+string(" Combination");
         return named && n==(triple ? 6 : 4) && (!ZWSEnds(family,string("Zigzag")) || ComboProgress(p,n));
        }
      return false;
     }

public:
   CZWStructures() {m_c=NULL;m_stopped=false;}
   // Exposed for independent native fixtures; never promotes G into S/H.
   bool FixedGeometry(CZWCore &core,const ZWPattern &pattern)
     {m_c=GetPointer(core);return Basic(pattern.points,pattern.count) && Fixed(pattern.points,pattern.count,pattern.family,pattern.degree);}

   void Scan(CZWCore &core,MArray<ZWPattern>& out)
     {
      m_c=GetPointer(core);ArrayResize(out,0);m_stopped=false;
      int oldLimit=core.opt.work_limit;
      // Reserve work for all three display degrees before recursive proof.
      int scanLimit=MathMin(oldLimit,core.work_used+(oldLimit-core.work_used)*3/5);
      for(int degree=0;degree<3 && degree<ArraySize(core.streams);degree++)
        {
         if(degree==2 && !core.opt.subwaves) continue;
         int remaining=3-degree;
         int degreeLimit=MathMin(scanLimit,core.work_used+MathMax(0,scanLimit-core.work_used)/remaining);
         core.opt.work_limit=degreeLimit;
         int n=ArraySize(core.streams[degree].pivots),totals[7],before[7];
         ArrayInitialize(totals,0);ArrayInitialize(before,2147483647);
         int first=MathMax(3,n-81);
         for(int at=n-2;at>=first && core.work_used<degreeLimit;at--)
           {
            ZWPivot endpoint=core.streams[degree].pivots[at],opposite=core.streams[degree].pivots[at+1];
            if(!core.Known(endpoint) || !core.Known(opposite) || opposite.b<=endpoint.b || opposite.hi==endpoint.hi) continue;
            for(int pass=0;pass<2 && core.work_used<degreeLimit;pass++)
              {
               int legs=pass==0 ? 5 : 3;if(at<legs || !Spend())continue;
               MArray<ZWPivot> p=MArray<ZWPivot>(6);for(int j=0;j<=legs;j++)p[j]=core.streams[degree].pivots[at-legs+j];
               MArray<ZWPattern> candidates;Candidates(p,legs+1,degree,string(""),candidates);
               MArray<bool> accepted=MArray<bool>(7);ArrayInitialize(accepted,false);
               bool comboReady=false,comboZig=false,comboThree=false;
               string bestABC=string("");double bestScore=.60;
               for(int j=0;j<ArraySize(candidates);j++) if(candidates[j].count==legs+1 && Group(candidates[j].family)==6 && candidates[j].score>=bestScore)
                 {bestABC=candidates[j].family;bestScore=candidates[j].score;}
               for(int j=0;j<ArraySize(candidates);j++)
                 {
                  ZWPattern q=candidates[j];int group=Group(q.family);
                  if(q.count!=legs+1 || !Enabled(group) || totals[group]>=core.opt.recent_patterns || endpoint.b>=before[group])continue;
                  bool okay=true;
                  if(group==4)
                    {if(!comboReady){ComboModes(p,legs+1,degree,comboZig,comboThree);comboReady=true;}okay=ZWSEnds(q.family,string("Zigzag")) ? comboZig : comboThree;}
                  if(group==6)okay=q.family==bestABC && q.score>=.60;
                  if(okay && core.work_used<degreeLimit)
                    {int k=ArraySize(out);ArrayResize(out,k+1);out[k]=q;accepted[group]=true;}
                 }
               for(int group=0;group<7;group++)if(accepted[group]){totals[group]++;before[group]=p[0].b;}
              }
           }
        }
      core.opt.work_limit=oldLimit;
     }

   ZWProof Validate(CZWCore &core,const ZWPattern &root)
     {
      m_c=GetPointer(core);m_stopped=false;
      ArrayResize(m_nodes,0);ArrayResize(m_stack,0);ArrayResize(m_next,ArraySize(core.streams));ArrayInitialize(m_next,-2);
      string category=ZWSCategory(root.family);
      ZWSNode first=Node(1,root.points,root.count,root.degree,root.family,string(""),root.family,category==string("impulse") || category==string("diagonal"));
      first.special=ZWSSpecial(root.family)-1;first.resolved=root.resolvedWave-1;first.originalEndpoint=root.originalEndpoint;
      first.designated=first.special<0 && first.resolved<0;
      ArrayResize(m_nodes,1);m_nodes[0]=first;
      if(core.opt.subwaves) {ArrayResize(m_stack,1);m_stack[0]=0;}
      else m_nodes[0].reason=string("subwaves_disabled");
      int expanded=0,reached=MathMax(root.degree,0),limit=MathMax(1,core.opt.max_nodes);
      while(ArraySize(m_stack)>0 && expanded<limit && core.work_used<core.opt.work_limit)
        {
         int count=ArraySize(m_stack),index=m_stack[count-1];ArrayResize(m_stack,count-1);
         ZWSNode node=m_nodes[index];expanded++;
         if(!Spend()) node.reason=string("work_limit");
         else if(node.mode==0)
           {
            MArray<ZWPivot> span;string reason=Span(node.degree,node.points[0],node.points[ArraySize(node.points)-1],span);
            if(reason==string(""))reason=BasicReason(span,ArraySize(span));
            if(reason!=string("")) {node.reason=reason;node.state=Unresolved(reason) ? 1 : 0;node.observed=node.state;}
            else
              {
               ArrayResize(node.points,ArraySize(span));ArrayCopy(node.points,span);
               MArray<ZWPattern> candidates;Candidates(span,ArraySize(span),node.degree,node.hint,candidates);
               bool stopped=m_stopped;node.cut=stopped;
               bool missing=ArraySize(span)<(node.motive ? 6 : 4);
               node.reason=stopped ? (core.work_used>=core.opt.work_limit ? string("work_limit") : string("candidate_limit")) : missing ? (ArraySize(span)>2 ? string("partial_subdivision") : string("missing_subdivision")) : string("no_valid_family_geometry");
               node.state=stopped || missing ? 1 : 0;node.observed=node.state;
               int j=0;
               for(;j<ArraySize(candidates) && ArraySize(m_nodes)<limit && core.work_used<core.opt.work_limit;j++)
                 {
                  ZWPattern candidate=candidates[j];
                  if(!ZWSAllowed(candidate.family,node.role,node.motive,node.hint))continue;
                  ZWSNode child=Node(1,candidate.points,candidate.count,candidate.degree,candidate.family,node.role,candidate.family,node.motive);
                  child.checked=true;child.special=ZWSSpecial(candidate.family)-1;child.resolved=candidate.resolvedWave-1;child.originalEndpoint=candidate.originalEndpoint;
                  child.designated=child.special<0 && child.resolved<0;
                  Push(node,child);
                 }
               if(j<ArraySize(candidates)){node.cut=true;node.reason=ArraySize(m_nodes)>=limit ? string("node_limit") : string("work_limit");}
              }
           }
         else
           {
            int n=ArraySize(node.points),resolvedLower=-2;string reason=BasicReason(node.points,n);
            if(node.degree<0 || node.degree>=ArraySize(core.streams)) reason=string("invalid_pattern_degree");
            if(reason==string("") && node.role!=string("") && !ZWSAllowed(node.family,node.role,node.motive,string(""))) reason=string("invalid_placement");
            if(reason==string("") && node.resolved>=0)
              {
               string c=ZWSCategory(node.family);
               if(!((c==string("impulse") && node.resolved==3) || ((c==string("zigzag") || c==string("flat")) && node.resolved==1)))reason=string("invalid_resolved_leg");
               else if(node.originalEndpoint.t==0)reason=string("missing_resolved_origin");
               else
                 {
                  ZWPivot replacement=node.points[node.resolved+1],start=node.points[node.resolved],original=node.originalEndpoint;
                  if(!core.Known(original))reason=string("unknown_or_unclosed_pivot");
                  else if(original.b<=start.b || original.b>=replacement.b || original.hi!=replacement.hi)reason=string("invalid_resolved_origin");
                  else if(!Contains(node.degree,original))reason=core.work_used>=core.opt.work_limit ? string("work_limit") : string("invalid_resolved_origin");
                  else
                    {
                     resolvedLower=NextDegree(node.degree);
                     if(resolvedLower<0)reason=resolvedLower==-3 ? string("work_limit") : string("resolution_exhausted");
                     else if(!Contains(resolvedLower,replacement))reason=core.work_used>=core.opt.work_limit ? string("work_limit") : string("invalid_resolved_endpoint");
                    }
                 }
              }
            if(reason==string("") && !node.checked && !Fixed(node.points,n,node.family,node.degree)) reason=core.work_used>=core.opt.work_limit ? string("work_limit") : string("invalid_family_geometry");
            if(reason!=string("")) {node.reason=reason;node.state=Unresolved(reason) ? 1 : 0;node.observed=node.state;}
            else
              {
               node.localGeometry=true;reached=MathMax(reached,node.degree);
               int lower=resolvedLower==-2 ? NextDegree(node.degree) : resolvedLower;
               if(lower==-3)node.reason=string("work_limit");
               else if(lower==-1){node.reason=string("resolution_exhausted");node.observed=2;}
               else if(lower>core.opt.max_depth || (!core.opt.hierarchy && node.degree>=root.degree+2))node.reason=core.opt.hierarchy ? string("depth_limit") : string("hierarchy_disabled");
               else
                 {
                  MArray<ZWSGrammar> grammars;Grammars(node.family,node.role,node.resolved+1,grammars);
                  node.reason=ArraySize(grammars)==0 ? string("missing_grammar") : string("unresolved_descendant");
                  int g=0;
                  for(;g<ArraySize(grammars) && ArraySize(m_nodes)<limit && core.work_used<core.opt.work_limit;g++)
                    {
                     ZWSGrammar grammar=grammars[g];
                     ZWSNode branch=Node(2,node.points,n,node.degree,node.family,node.role,string(""),node.motive);
                     branch.special=node.special;branch.resolved=node.resolved;branch.form=grammar.form;branch.designated=node.special<0 && node.resolved<0;
                     int branchIndex=ArraySize(m_nodes);
                     if(Push(node,branch,false))
                       {
                        int j=0;
                        for(;j<ArraySize(grammar.legs) && ArraySize(m_nodes)<limit && core.work_used<core.opt.work_limit;j++)
                          {
                           ZWSLeg leg=grammar.legs[j];MArray<ZWPivot> endpoints=MArray<ZWPivot>(2);endpoints[0]=node.points[j];endpoints[1]=node.points[j+1];
                           ZWSNode child=Node(0,endpoints,2,lower,string(""),leg.role,leg.hint,leg.motive);Push(branch,child);
                          }
                        if(j<ArraySize(grammar.legs)){branch.cut=true;branch.reason=ArraySize(m_nodes)>=limit ? string("node_limit") : string("work_limit");}
                        m_nodes[branchIndex]=branch;
                       }
                    }
                  if(g<ArraySize(grammars)){node.cut=true;node.reason=ArraySize(m_nodes)>=limit ? string("node_limit") : string("work_limit");}
                 }
              }
           }
         m_nodes[index]=node;
        }
      for(int j=0;j<ArraySize(m_stack);j++){m_nodes[m_stack[j]].cut=true;m_nodes[m_stack[j]].reason=string("work_limit");}
      for(int index=ArraySize(m_nodes)-1;index>=0;index--)
        {
         ZWSNode node=m_nodes[index];
         if(ArraySize(node.children)==0)
           {
            // A bounded query can discover viable alternatives but have no
            // node slot left to enqueue them. That is missing evidence,
            // never a certificate that all alternatives are invalid.
            if(node.cut){node.state=1;node.observed=1;m_nodes[index]=node;}
            continue;
           }
         bool conjunction=node.mode==2;
         int state=conjunction ? 2 : node.cut ? 1 : 0,observed=state;
         bool immediate=conjunction && !node.cut,five=false,designated=node.special<0 && node.resolved<0;
         bool specialVerified=node.special<0,resolvedVerified=node.resolved<0;
         string chosenReason=node.reason;
         if(conjunction && node.cut){state=1;observed=1;}
         for(int j=0;j<ArraySize(node.children);j++)
           {
            ZWSNode child=m_nodes[node.children[j]];
            if(conjunction)
              {
               state=MathMin(state,child.state);observed=MathMin(observed,child.observed);immediate=immediate && child.localGeometry;
               if(node.special==j)specialVerified=child.five;
               if(node.resolved==j)resolvedVerified=child.localGeometry;
               if(child.state<2)chosenReason=child.reason;
              }
            else
              {
               if(child.state>state || (child.state==state && child.observed>observed))chosenReason=child.reason;
               state=MathMax(state,child.state);observed=MathMax(observed,child.observed);
               if(node.mode==0)
                 {
                  string c=ZWSCategory(child.family),r=ZWSRole(node.role);
                  bool simple=c==string("impulse") || c==string("zigzag") || c==string("flat");
                  bool usable=child.localGeometry && child.designated && child.state!=0;
                  bool needs=r==string("component") || r==string("finalx") || r==string("finaly") || r==string("finalz");
                  bool finite=(!needs && simple && SamePoints(child.points,ArraySize(child.points),node.points,ArraySize(node.points))) || child.immediate;
                  node.localGeometry=node.localGeometry || (usable && finite);
                  five=five || (usable && finite && c==string("impulse") && ArraySize(child.points)==6);
                 }
               else {immediate=immediate || (child.immediate && child.state!=0);designated=designated || child.designated;}
              }
           }
         if(conjunction)designated=specialVerified && resolvedVerified;
         node.state=state;node.observed=observed;node.immediate=immediate;node.five=five;node.designated=designated;node.reason=state==0 ? string("invalid_descendant") : chosenReason;
         m_nodes[index]=node;
        }
      ZWSNode outcome=m_nodes[0];ZWProof result;ZeroMemory(result);
      result.subdivisionVerified=core.opt.subwaves && outcome.immediate;
      result.observedValid=core.opt.hierarchy && core.opt.subwaves && outcome.observed==2 && outcome.localGeometry;
      result.status=outcome.state==2 ? string("valid") : outcome.state==0 ? string("invalid") : string("incomplete");
      result.reason=!core.opt.subwaves ? string("subwaves_disabled") : !core.opt.hierarchy ? string("hierarchy_disabled") : outcome.reason;
      result.nodes=ArraySize(m_nodes);result.maxDepthReached=reached;result.designatedVerified=outcome.designated;
      bool leadingFive=false,diagonalThree=false;
      for(int j=0;j<ArraySize(outcome.children);j++)
        {
         ZWSNode branch=m_nodes[outcome.children[j]];bool finite=branch.immediate && branch.state!=0;
         leadingFive=leadingFive || (branch.form==string("leading_five") && finite);diagonalThree=diagonalThree || (branch.form==string("diagonal_three") && finite);
        }
      if(core.opt.subwaves && !outcome.cut && leadingFive && !diagonalThree && ZWSStarts(root.family,string("Leading/Ending Diagonal ")))
        {result.resolvedFamily=root.family;StringReplace(result.resolvedFamily,string("Leading/Ending"),string("Leading"));}
      return result;
     }
  };
#endif
