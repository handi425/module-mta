// MPL-2.0. ZWave by XoRonX | Mr Poleks; native HPX adaptation.
#ifndef HPX_ZWAVE_TARGETS_MQH
#define HPX_ZWAVE_TARGETS_MQH
#include "HPXZWaveRender.hpp"
struct ZWBand {double lo,hi;int rank;};
struct ZWFibLevel {double price,ratio;int rank;};
int ZWFibPriority(const int rank){return rank==1?4:rank==3?3:rank==2?2:1;}
void ZWFibLevelAdd(MArray<ZWFibLevel>& out,const double price,const double ratio,const int rank,const double tick)
{
   for(int i=0;i<ArraySize(out);i++)if(MathAbs(out[i].price-price)<tick*.25)
   {if(ZWFibPriority(rank)>ZWFibPriority(out[i].rank))out[i].rank=rank;return;}
   int n=ArraySize(out);if(n>=12)return;ArrayResize(out,n+1);out[n].price=price;out[n].ratio=ratio;out[n].rank=rank;
}
struct ZWTargetOptions
{
   bool fibonacci,next_wave,developing,shade,rare,projection,alternative,levels,larry;
   MArray<bool> categories=MArray<bool>(4);int degree,forward,horizon;
};
void ZWTargetDefaults(ZWTargetOptions &o)
{
   ZeroMemory(o);o.fibonacci=true;o.developing=true;o.shade=true;o.projection=true;o.alternative=true;o.levels=true;o.larry=true;
   for(int i=0;i<4;i++)o.categories[i]=true;o.degree=1;o.forward=20;o.horizon=30;
}
void ZWBandAdd(MArray<ZWBand>& out,const double a,const double b,const int rank)
{int n=ArraySize(out);ArrayResize(out,n+1);out[n].lo=a;out[n].hi=b;out[n].rank=rank;}
void ZWProfile(const int profile,MArray<ZWBand>& out)
{
   ArrayResize(out,0);
   if(profile==1){ZWBandAdd(out,.236,.382,0);ZWBandAdd(out,.618,.786,1);ZWBandAdd(out,.382,.5,2);ZWBandAdd(out,.886,1,4);}
   if(profile==2){ZWBandAdd(out,1,1.618,0);ZWBandAdd(out,3,3.618,0);ZWBandAdd(out,1.618,1.786,1);ZWBandAdd(out,1.786,2.618,1);ZWBandAdd(out,2.618,3,2);ZWBandAdd(out,4,4.618,4);}
   if(profile==3){ZWBandAdd(out,4.236,4.236,0);ZWBandAdd(out,4.414,4.414,0);ZWBandAdd(out,4.618,4.618,0);ZWBandAdd(out,1.236,1.236,1);ZWBandAdd(out,1.618,1.618,1);ZWBandAdd(out,2.236,2.236,1);ZWBandAdd(out,2.618,2.618,2);ZWBandAdd(out,3.236,3.236,2);ZWBandAdd(out,3.618,3.618,2);}
   if(profile==4){ZWBandAdd(out,.236,.272,0);ZWBandAdd(out,.382,.5,1);ZWBandAdd(out,.3414,.382,2);ZWBandAdd(out,.618,.66,2);}
   if(profile==5){ZWBandAdd(out,2,2.618,0);ZWBandAdd(out,1.236,1.618,1);ZWBandAdd(out,1.786,2,2);}
   if(profile==6){ZWBandAdd(out,.236,.272,0);ZWBandAdd(out,.382,.5,1);ZWBandAdd(out,.236,.382,2);ZWBandAdd(out,.618,.66,2);ZWBandAdd(out,.786,.886,2);}
   if(profile==7){ZWBandAdd(out,.618,.618,0);ZWBandAdd(out,2.382,2.618,0);ZWBandAdd(out,1.618,1.786,1);ZWBandAdd(out,1,1,2);ZWBandAdd(out,2,2,2);ZWBandAdd(out,2.236,2.236,2);ZWBandAdd(out,2.272,2.272,2);ZWBandAdd(out,1.236,1.236,3);ZWBandAdd(out,1.272,1.272,3);ZWBandAdd(out,1.382,1.382,3);}
   if(profile==8||profile==10){ZWBandAdd(out,.618,.618,5);ZWBandAdd(out,1,1,5);ZWBandAdd(out,1.236,1.236,5);ZWBandAdd(out,1.382,1.382,5);ZWBandAdd(out,1.618,1.618,5);if(profile==10)ZWBandAdd(out,2.236,2.236,5);}
   if(profile==9){ZWBandAdd(out,1.236,1.236,5);ZWBandAdd(out,1.382,1.382,5);ZWBandAdd(out,1.618,1.618,5);}
   if(profile==11||profile==12){ZWBandAdd(out,.55,.55,5);ZWBandAdd(out,.618,.618,5);ZWBandAdd(out,.66,.66,5);ZWBandAdd(out,.706,.706,5);ZWBandAdd(out,.786,.786,5);if(profile==12)ZWBandAdd(out,.9,.9,5);}
   if(profile==13){ZWBandAdd(out,1.05,1.13,5);ZWBandAdd(out,1.236,1.272,5);ZWBandAdd(out,1.3414,1.382,5);}
}
color ZWCategoryColor(const int rank)
{return rank==0?9141600:rank==1?755384:rank==2?2263842:rank==3?2260710:rank==4?clrMagenta:clrTeal;}
string ZWCategoryName(const int rank)
{return rank==0?string("Tak umum"):rank==1?string("Paling umum"):rank==2?string("Umum"):rank==3?string("Sangat umum"):rank==4?string("Langka"):string("Tanpa peringkat");}
string ZWRatio(const double value){string s=DoubleToString(value,4);while(StringFind(s,string("."))>=0&&StringSubstr(s,StringLen(s)-1)==string("0"))s=StringSubstr(s,0,StringLen(s)-1);if(StringSubstr(s,StringLen(s)-1)==string("."))s=StringSubstr(s,0,StringLen(s)-1);return s;}
bool ZWSamePath(const ZWPath &a,const ZWPath &b)
{if(a.count!=b.count||a.degree!=b.degree||a.motive!=b.motive||a.family!=b.family)return false;for(int i=0;i<a.count;i++)if(a.points[i].b!=b.points[i].b||a.points[i].p!=b.points[i].p||a.points[i].hi!=b.points[i].hi)return false;return true;}
int ZWSelectPath(CZWCore &core,const int degree,const bool developing,bool &ambiguous)
{
   int chosen=-1,last=-1;ambiguous=false;
   for(int i=0;i<ArraySize(core.paths);i++)
   {
      ZWPath path=core.paths[i];if(path.degree!=degree||path.count<2||(!developing&&path.developing))continue;
      bool valid=true;
      if(StringLen(path.family)==0)for(int j=1;j<path.count;j++)
      {
         string token=path.motive?(string)j:j==1?string("A"):j==2?string("B"):string("C");bool found=false;
         for(int k=0;k<ArraySize(core.counts);k++)
         {
            ZWCount c=core.counts[k];string raw=c.wave_name;if(!developing&&StringFind(raw,string("?"))>=0)continue;StringReplace(raw,string("?"),string(""));
            if(c.degree==degree&&c.pivot.b==path.points[j].b&&c.pivot.p==path.points[j].p&&StringFind(string(" / ")+raw+string(" / "),string(" / ")+token+string(" / "))>=0){found=true;break;}
         }
         if(!found){valid=false;break;}
      }
      if(!valid)continue;
      int endpoint=path.points[path.count-1].b;
      if(endpoint>last){chosen=i;last=endpoint;ambiguous=false;}
      else if(endpoint==last&&chosen>=0&&!ZWSamePath(core.paths[chosen],path))ambiguous=true;
   }
   return chosen;
}
int ZWFibSpec(const ZWPath &p,const bool next,const bool larry,double &base,double &unit,string &wave)
{
   int stage=p.count-1,target=stage+(next||stage==1?1:0);base=unit=0;wave=string("");
   if(StringLen(p.family)>0)
   {
      if(next||StringFind(p.family,string("Expanding"))>=0||p.count!=6)return 0;
      base=p.points[4].p;unit=p.points[3].p-base;wave=string("Triangle E");return StringFind(p.family,string("Barrier"))>=0?12:11;
   }
   double origin=p.points[0].p,one=p.points[1].p;
   if(p.motive)
   {
      wave=string("Wave ")+(string)target;
      if(target==2){base=one;unit=origin-one;return 1;}
      if(target==3){base=larry?origin:p.points[2].p;unit=one-origin;return larry?2:3;}
      if(target==4){base=p.points[3].p;unit=p.points[2].p-base;return 4;}
      if(target==5){base=p.points[4].p;unit=p.points[3].p-base;return 5;}
   }
   else
   {
      wave=target==2?string("Wave B"):string("Wave C");
      if(target==2){base=one;unit=origin-one;return stage>=2&&MathAbs(p.points[2].p-one)>MathAbs(unit)?13:6;}
      if(target==3){base=larry?origin:p.points[2].p;unit=one-origin;double ratio=unit!=0?MathAbs(p.points[2].p-one)/MathAbs(unit):0;return larry?7:ratio>1?10:ratio>=.886?9:8;}
   }
   return 0;
}
class CZWTargets
{
public:
   int selected,profile;bool ambiguous;double base,unit;
   CZWTargets(){selected=-1;profile=0;ambiguous=false;base=unit=0;}
   void Draw(CZWCore &core,CZWRender &draw,const ZWTargetOptions &opt,const double price,const datetime now,const int seconds)
   {
      selected=ZWSelectPath(core,opt.degree,opt.developing,ambiguous);profile=0;
      if(selected<0||ambiguous||ArraySize(core.rates)==0)return;
      ZWPath path=core.paths[selected];string wave=string("");
      profile=ZWFibSpec(path,opt.next_wave,opt.larry,base,unit,wave);
      if(opt.fibonacci&&profile>0&&MathAbs(unit)>=core.mintick)
      {
         MArray<ZWBand> bands;ZWProfile(profile,bands);datetime start=path.points[path.count-1].t;
         if(start<now-seconds*80)start=now-seconds*80;datetime right=now+seconds*opt.forward;
         MArray<ZWFibLevel> levels;
         for(int i=0;i<ArraySize(bands);i++)
         {
            ZWBand b=bands[i];if((b.rank==4&&!opt.rare)||(b.rank<4&&!opt.categories[b.rank]))continue;
            ZWFibLevelAdd(levels,base+unit*b.lo,b.lo,b.rank,core.mintick);
            if(b.lo!=b.hi)ZWFibLevelAdd(levels,base+unit*b.hi,b.hi,b.rank,core.mintick);
         }
         if(profile==5&&path.count>=5)
         {
            double one=MathAbs(path.points[1].p-path.points[0].p),three=MathAbs(path.points[3].p-path.points[2].p);
            int rank=three>=2.618*one?2:0;if(opt.categories[rank])ZWFibLevelAdd(levels,path.points[4].p+path.points[1].p-path.points[0].p,-1,rank,core.mintick);
         }
         if(opt.shade)for(int i=0;i<ArraySize(bands);i++)
         {
            ZWBand b=bands[i];if(b.lo==b.hi||(b.rank==4&&!opt.rare)||(b.rank<4&&!opt.categories[b.rank]))continue;
            double a=base+unit*b.lo,z=base+unit*b.hi;bool foundA=false,foundB=false;
            for(int j=0;j<ArraySize(levels);j++){if(MathAbs(levels[j].price-a)<core.mintick*.25)foundA=true;if(MathAbs(levels[j].price-z)<core.mintick*.25)foundB=true;}
            if(foundA&&foundB)draw.Line(start,a,right,z,draw.Blend(ZWCategoryColor(b.rank),.08),STYLE_SOLID,true);
         }
         for(int i=0;i<ArraySize(levels);i++)
         {
            ZWFibLevel v=levels[i];color ink=ZWCategoryColor(v.rank);
            string tip=string("Fibonacci | ")+wave+string(" | ")+ZWCategoryName(v.rank)+string("\n")+(path.developing?string("Counting berkembang (?)"):string("Counting terakhir"))+string("\nKategori referensi; bukan probabilitas hasil backtest.");
            draw.Line(start,v.price,right,v.price,ink,path.developing?STYLE_DOT:STYLE_DASH);
            draw.Text(right+seconds,v.price,wave+string(" | ")+(v.ratio<0?string("1x W1"):ZWRatio(v.ratio)),ink,8,1,tip,string(""),true);
         }
      }
      if(opt.projection)Projection(core,draw,opt,path,price,now,seconds);
   }
   void Projection(CZWCore &core,CZWRender &draw,const ZWTargetOptions &opt,const ZWPath &p,const double price,const datetime now,const int seconds)
   {
      int stage=p.count-1;ZWPivot endpoint=p.points[stage];int d=p.points[1].p>p.points[0].p?1:-1;
      datetime right=now+seconds*opt.horizon;double atr=draw.atr;
      color bull=8096000,bear=2631878;
      if(StringLen(p.family)>0)
      {
         double upper=-DBL_MAX,lower=DBL_MAX;for(int i=1;i<p.count;i++){upper=MathMax(upper,p.points[i].p);lower=MathMin(lower,p.points[i].p);}
         bool up=price>upper+core.mintick,down=price<lower-core.mintick;
         if(opt.levels){draw.Line(now,upper,right,upper,bull,STYLE_DOT);draw.Line(now,lower,right,lower,bear,STYLE_DOT);}
         if(up||(!down&&opt.alternative)){double y=up?price+atr*2:upper+atr*.5;draw.Line(now,price,right,y,bull,STYLE_DASH);draw.Text(right,y,string("Naik? setelah tembus atas"),bull,8,1,string("Skenario bersyarat setelah E; panjang visual ATR, bukan target Fibonacci."),string(""),true);}
         if(down||(!up&&opt.alternative)){double y=down?price-atr*2:lower-atr*.5;draw.Line(now,price,right,y,bear,STYLE_DASH);draw.Text(right,y,string("Turun? setelah tembus bawah"),bear,8,-1,string("Skenario bersyarat setelah E; panjang visual ATR, bukan target Fibonacci."),string(""),true);}
         return;
      }
      double origin=p.points[0].p,one=p.points[1].p,b=0,u=0,trigger=0,invalidation=endpoint.p,structural=endpoint.p;int direction=0,invalidSide=0,pr=0;
      string next=string("");bool open=false;
      if(p.motive&&stage<=4)
      {
         int target=stage+1;next=string("W")+(string)target+string("?");direction=(target==2||target==4)?-d:d;
         if(target==2){pr=1;b=one;u=origin-one;trigger=b+u*.236;invalidation=origin;invalidSide=direction;}
         if(target==3){pr=opt.larry?2:3;b=opt.larry?origin:p.points[2].p;u=one-origin;trigger=one;invalidation=p.points[2].p;invalidSide=-direction;}
         if(target==4){pr=4;b=p.points[3].p;u=p.points[2].p-b;trigger=b+u*.236;invalidation=one;invalidSide=direction;}
         if(target==5){pr=5;b=p.points[4].p;u=p.points[3].p-b;trigger=p.points[3].p;invalidation=p.points[4].p;invalidSide=-direction;}
      }
      else if(!p.motive&&stage<=2)
      {
         direction=stage==1?-d:d;next=stage==1?string("B?"):string("C?");
         if(stage==1){pr=6;b=one;u=origin-one;trigger=b+u*.236;}
         else{pr=7;b=origin;u=one-origin;trigger=one;if(!opt.larry&&u!=0){b=p.points[2].p;double ratio=MathAbs(p.points[2].p-one)/MathAbs(u);pr=ratio>1?10:ratio>=.886?9:8;}}
         invalidSide=-direction;
      }
      else
      {
         open=true;direction=-d;next=p.motive?string("Koreksi setelah 5?"):string("Reaksi setelah C?");structural=p.points[p.motive?4:2].p;
         trigger=endpoint.p+direction*MathMax(core.mintick*2,MathAbs(endpoint.p-structural)*.25);invalidSide=-direction;
         if(p.degree+1<ArraySize(core.streams))for(int i=ArraySize(core.streams[p.degree+1].pivots)-2;i>=0&&i>=ArraySize(core.streams[p.degree+1].pivots)-81;i--)
         {ZWPivot x=core.streams[p.degree+1].pivots[i];if(x.b>endpoint.b&&x.hi==(direction>0)&&core.Known(x)){trigger=x.p;break;}}
      }
      bool invalid=false;int last=ArraySize(core.rates)-1;
      if(endpoint.b<last){double extreme=core.Range(endpoint.b+1,last,invalidSide>0?1:-1);invalid=extreme!=EMPTY_VALUE&&(invalidSide>0?extreme>invalidation+core.mintick:extreme<invalidation-core.mintick);}
      if(invalid)return;
      color ink=direction>0?bull:bear;double goal=0;
      if(pr>0)
      {
         MArray<ZWBand> bands;ZWProfile(pr,bands);int best=-1,priority=100;double distance=DBL_MAX;
         for(int i=0;i<ArraySize(bands);i++)
         {
            if(bands[i].rank==4)continue;double a=b+u*bands[i].lo,z=b+u*bands[i].hi,far=direction>0?MathMax(a,z):MathMin(a,z),mid=(a+z)*.5;
            double candidate=direction*(mid-price)>core.mintick?mid:far;
            bool legal=invalidSide!=direction||direction*(far-invalidation)<-core.mintick;
            int rank=bands[i].rank,priorityHere=rank==1?0:rank==3?2:rank==2?3:rank==0?4:5;
            if(legal&&direction*(candidate-price)>core.mintick&&direction*(candidate-trigger)>core.mintick&&(priorityHere<priority||(priorityHere==priority&&direction*(candidate-price)<distance)))
            {priority=priorityHere;distance=direction*(candidate-price);best=i;goal=candidate;}
         }
         if(best>=0)
         {
            double a=b+u*bands[best].lo,z=b+u*bands[best].hi;
            if(opt.shade&&a!=z)draw.Line(now+seconds*2,a,right,z,draw.Blend(ink,.1),STYLE_SOLID,true);
            draw.Line(now+seconds*2,a,right,a,ink,STYLE_DOT);if(a!=z)draw.Line(now+seconds*2,z,right,z,ink,STYLE_DOT);
         }
      }
      else if(open)
      {
         bool ahead=direction*(structural-price)>core.mintick&&direction*(structural-trigger)>core.mintick;
         goal=ahead?structural:direction>0?MathMax(price+atr*2,trigger+atr*.5):MathMin(price-atr*2,trigger-atr*.5);
         if(opt.alternative&&direction*(price-trigger)<0){double opposite=price-direction*atr;draw.Line(now,price,right,opposite,clrGray,STYLE_DASH);draw.Text(right,opposite,string("Alternatif: tren lanjut"),clrGray,8,-direction,string("Alternatif tanpa target Fibonacci"),string(""),true);}
      }
      if(goal!=0){draw.Line(now,price,right,goal,ink,STYLE_DASH);draw.Text(right,goal,(direction>0?string("Naik "):string("Turun "))+next,ink,8,direction,string("Skenario bersyarat; belum membuktikan wave baru. Horizon hanya ruang gambar."),string(""),true);}
      if(opt.levels){draw.Line(now,trigger,right,trigger,ink,STYLE_DOT);draw.Line(now,invalidation,right,invalidation,clrGray,STYLE_DOT);draw.Text(right,invalidation,string("Invalidasi ")+DoubleToString(invalidation,_Digits),clrGray,8,-direction,string("Pelanggaran diperiksa pada seluruh candle tertutup setelah endpoint."),string(""),true);}
   }
};
#endif
