#pragma once
#include "HPXZWaveCore.hpp"
struct ZWVisualLine { datetime a,b; double p,q; color ink; ENUM_LINE_STYLE style; bool zone; };
struct ZWVisualText { datetime t; double p; string text,tip,key; color ink; int size,side; bool fixed; };
struct ZWTextBox { int x,y,w,h; };

// A scene reuses its native objects. A tick never deletes and recreates the chart.
class CZWRender
{
public:
   string prefix;
   MArray<ZWVisualLine> lines;
   MArray<ZWVisualText> texts;
   MArray<ZWTextBox> boxes;
   MArray<ZWTextBox> obstacles;
   int previousLines,previousTexts;
   bool separate;
   double gap,row,atr;
   CZWRender(){previousLines=0;previousTexts=0;separate=true;gap=.15;row=.35;atr=1;}
   void Begin(){ArrayResize(lines,0);ArrayResize(texts,0);ArrayResize(boxes,0);ArrayResize(obstacles,0);}
   void ReserveBox(const int x,const int y,const int width,const int height)
   {int n=ArraySize(obstacles);ArrayResize(obstacles,n+1);obstacles[n].x=x;obstacles[n].y=y;obstacles[n].w=width;obstacles[n].h=height;}
   color Blend(const color ink,const double opacity)
   {
      int a=(int)ink,b=(int)ChartGetInteger(0,CHART_COLOR_BACKGROUND);
      return (color)((int)MathRound((a&255)*opacity+(b&255)*(1-opacity)) |
         ((int)MathRound(((a>>8)&255)*opacity+((b>>8)&255)*(1-opacity))<<8) |
         ((int)MathRound(((a>>16)&255)*opacity+((b>>16)&255)*(1-opacity))<<16));
   }
   void Line(const datetime a,const double p,const datetime b,const double q,const color ink,const ENUM_LINE_STYLE style=STYLE_SOLID,const bool zone=false)
   {
      int n=ArraySize(lines);if(n>=500||a<=0||b<=0||!MathIsValidNumber(p)||!MathIsValidNumber(q))return;
      ArrayResize(lines,n+1);lines[n].a=a;lines[n].b=b;lines[n].p=p;lines[n].q=q;
      lines[n].ink=ink;lines[n].style=style;lines[n].zone=zone;
   }
   void Text(const datetime t,const double p,const string caption,const color ink,const int size=8,const int side=1,const string tooltip=string(""),const string key=string(""),const bool fixed=false)
   {
      if(caption==string("")||!MathIsValidNumber(p))return;
      int n=ArraySize(texts);
      if(key!=string(""))for(int i=0;i<n;i++)if(texts[i].key==key)
      {
         // Join shared pivot letters once. Degree is part of the key.
         string raw=caption;StringReplace(raw,string("?"),string(""));string old=texts[i].text;StringReplace(old,string("?"),string(""));
         if(StringFind(string(" / ")+old+string(" / "),string(" / ")+raw+string(" / "))<0)texts[i].text+=string(" / ")+caption;
         if(StringFind(texts[i].tip,tooltip)<0)texts[i].tip+=string("\n")+tooltip;
         return;
      }
      if(n>=220)return;
      ArrayResize(texts,n+1);texts[n].t=t;texts[n].p=p;texts[n].text=caption;
      texts[n].ink=ink;texts[n].size=size;texts[n].side=side;texts[n].tip=tooltip;
      texts[n].key=key;texts[n].fixed=fixed;
   }
   void Flush() { }
   void Clear() { Begin(); }
};
string ZWNotationToken(const string raw,const int level)
{
   string value=raw;bool developing=StringFind(value,string("?"))>=0;StringReplace(value,string("?"),string(""));
   MArray<string> nums={string("①"),string("②"),string("③"),string("④"),string("⑤")};MArray<string> letters={string("Ⓐ"),string("Ⓑ"),string("Ⓒ"),string("Ⓓ"),string("Ⓔ")};
   MArray<string> roman={string("I"),string("II"),string("III"),string("IV"),string("V")};MArray<string> small={string("i"),string("ii"),string("iii"),string("iv"),string("v")};
   int i=(int)StringToInteger(value)-1;bool numeric=i>=0&&i<5;string out=value;
   int letter=StringFind(string("ABCDE"),value);bool alpha=StringLen(value)==1&&letter>=0;
   if(level==0){if(numeric)out=roman[i];out=string("[")+out+string("]");}
   else if(level==1){if(numeric)out=roman[i];out=string("(")+out+string(")");}
   else if(level==2){if(numeric)out=roman[i];}
   else if(level==3){if(numeric)out=nums[i];else if(alpha)out=letters[letter];else if(value==string("W"))out=string("Ⓦ");else if(value==string("X"))out=string("Ⓧ");else if(value==string("Y"))out=string("Ⓨ");else if(value==string("Z"))out=string("Ⓩ");else if(value==string("X2"))out=string("Ⓧ₂");}
   else if(level==4){out=string("(")+value+string(")");}
   else if(level==6){if(numeric)out=small[i];else StringToLower(out);out=string("[")+out+string("]");}
   else if(level==7){if(numeric)out=string("(")+small[i]+string(")");else {StringToLower(out);out=string("(")+out+string(")");}}
   else if(level>=8){if(numeric)out=small[i];else StringToLower(out);}
   return out+(developing?string("?"):string(""));
}
string ZWNotation(const string raw,const int level,const bool enabled)
{
   if(!enabled)return raw;
   string split=raw;StringReplace(split,string(" / "),string("|"));MArray<string> parts;int n=StringSplit(split,'|',parts);string out=string("");
   for(int i=0;i<n;i++)out+=(i>0?string(" / "):string(""))+ZWNotationToken(parts[i],level);
   return out;
}
