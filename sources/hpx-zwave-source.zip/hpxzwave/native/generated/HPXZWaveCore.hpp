// This Source Code Form is subject to the Mozilla Public License v2.0.
// https://mozilla.org/MPL/2.0/ . Created by XoRonX | Mr Poleks.
// Native closed-bar translation of HPX ZWave's causal ZigZag and counter.
#ifndef HPX_ZWAVE_CORE_MQH
#define HPX_ZWAVE_CORE_MQH
#include "HPXZWaveTypes.hpp"
struct ZWBeam {MArray<int> at=MArray<int>(6); double score;};
struct ZWAnchor {ZWPivot origin,one,two,three; int degree; bool developing;};
struct ZWExtension {ZWPivot two,three; int degree; bool proved;};
class CZWCore
  {
private:
   MArray<double> m_high;MArray<double> m_low;MArray<double> m_maxmacd;MArray<double> m_minmacd;MArray<double> m_macd;
   MArray<int> m_logs;int m_cache_n;int m_cache_levels;
   bool m_have_context;
   MqlRates m_context;
   MArray<ZWCount> m_confirmed;
   MArray<ZWAnchor> m_anchors;
   MArray<ZWExtension> m_extensions;
   string m_signature;
   ZWPattern Empty() {ZWPattern p; ZeroMemory(p);p.score=-1;return p;}
   string Signature(const ZWOptions &o)
     {
      return DoubleToString(o.deviation,12)+string(":")+DoubleToString(o.factor,12)+string(":")+(string)o.depth+string(":")+(string)o.child_depth+string(":")+(string)o.history+string(":")+(string)o.max_depth+string(":")+(string)o.max_nodes+string(":")+(string)o.work_limit+string(":")+(string)o.candidate_limit+string(":")+(string)o.recent_patterns+string(":")+(string)o.subwaves+string(":")+(string)o.hierarchy+string(":")+(string)o.divergence+string(":")+(string)o.triangles+string(":")+(string)o.abc+string(":")+(string)o.impulses+string(":")+(string)o.diagonals+string(":")+(string)o.combinations+string(":")+(string)o.truncation+string(":")+(string)o.extensions+string(":")+(string)o.show_developing+string(":")+(string)o.show_micro+string(":")+(string)o.capture_micro_paths+string(":")+(string)o.show_hidden+string(":")+(string)o.hidden_extremes+string(":")+(string)o.hidden_same_side+string(":")+(string)o.hidden_min_bars+string(":")+(string)o.hidden_max_bars;
     }
   void Cache()
     {
      int n=ArraySize(rates);m_cache_n=n;ArrayResize(m_logs,n+1);m_logs[0]=0;
      if(n==0)return;
      m_logs[1]=0;for(int i=2;i<=n;i++)m_logs[i]=m_logs[i/2]+1;
      m_cache_levels=m_logs[n]+1;int total=n*m_cache_levels;
      ArrayResize(m_high,total);ArrayResize(m_low,total);ArrayResize(m_maxmacd,total);ArrayResize(m_minmacd,total);
      for(int i=0;i<n;i++){m_high[i]=rates[i].high;m_low[i]=rates[i].low;m_maxmacd[i]=m_macd[i];m_minmacd[i]=m_macd[i];}
      for(int k=1;k<m_cache_levels;k++)
        {int half=1<<(k-1),size=1<<k;for(int i=0;i+size<=n;i++)
           {int a=(k-1)*n+i,b=a+half,to=k*n+i;m_high[to]=MathMax(m_high[a],m_high[b]);m_low[to]=MathMin(m_low[a],m_low[b]);m_maxmacd[to]=MathMax(m_maxmacd[a],m_maxmacd[b]);m_minmacd[to]=MathMin(m_minmacd[a],m_minmacd[b]);}}
     }
   bool PivotAt(const int end,const int radius,const bool hi,ZWPivot &p)
     {
      if(end+1+(m_have_context?1:0)<2*radius+1)return false;
      int c=end-radius;double price=hi?rates[c].high:rates[c].low;
      for(int i=c+1;i<=end;i++)if(hi?rates[i].high>price:rates[i].low<price)return false;
      for(int i=c-radius;i<c;i++)
        {
         double value=i<0?(hi?m_context.high:m_context.low):(hi?rates[i].high:rates[i].low);
         if(hi?value>=price:value<=price)return false;
        }
      p.b=c;p.t=rates[c].time;p.p=price;p.hi=hi;p.known=end;return true;
     }
   void Register(const int degree,const ZWPivot &p)
     {
      int n=ArraySize(streams[degree].pivots);
      if(!n){ArrayResize(streams[degree].pivots,1);streams[degree].pivots[0]=p;return;}
      ZWPivot last=streams[degree].pivots[n-1];
      if(p.hi==last.hi){if(p.hi?p.p>last.p:p.p<last.p)streams[degree].pivots[n-1]=p;return;}
      if(last.p==0)return;double move=100.0*(p.p-last.p)/MathAbs(last.p),dev=streams[degree].reversal;
      if((!last.hi && move>=dev)||(last.hi && move<=-dev)){ArrayResize(streams[degree].pivots,n+1);streams[degree].pivots[n]=p;}
     }
   void Keep(MArray<ZWBeam>& pool,const ZWBeam &candidate)
     {
      int n=ArraySize(pool);if(n<24){ArrayResize(pool,n+1);pool[n]=candidate;return;}
      int worst=0;for(int i=1;i<n;i++)if(pool[i].score<pool[worst].score)worst=i;
      if(candidate.score>pool[worst].score)pool[worst]=candidate;
     }
   bool Append(MArray<ZWPivot>& points,const ZWPivot &p)
     {
      int n=ArraySize(points);if(!n){ArrayResize(points,1);points[0]=p;return true;}
      ZWPivot last=points[n-1];if(p.b<=last.b)return false;
      if(p.hi==last.hi){if(n>1 && (p.hi?p.p>last.p:p.p<last.p))points[n-1]=p;}
      else {if(n>=256)return false;ArrayResize(points,n+1);points[n]=p;}
      return true;
     }
   void ToArray(const ZWPattern &p,MArray<ZWPivot>& out)
     {ArrayResize(out,p.count);for(int i=0;i<p.count;i++)out[i]=p.points[i];}
   bool ExtendedThree(const MArray<ZWPivot>& p)
     {return ArraySize(p)>=4 && MathAbs(p[1].p-p[0].p)>eps && MathAbs(p[3].p-p[2].p)>=2.618*MathAbs(p[1].p-p[0].p);}
   bool Counted(const ZWPivot &p,const int degree)
     {for(int i=0;i<ArraySize(counts);i++)if(counts[i].degree==degree && Same(counts[i].pivot,p) && StringFind(counts[i].wave_name,string("?"))<0)return true;return false;}
   bool Conflict(const ZWPivot &p,const int degree,const string wave)
     {for(int i=0;i<ArraySize(counts);i++)if(counts[i].degree==degree && Same(counts[i].pivot,p) && StringFind(counts[i].wave_name,string("?"))<0 && counts[i].wave_name!=wave)return true;return false;}
   void RemoveAt(MArray<ZWCount>& out,const int at)
     {int n=ArraySize(out);for(int i=at;i<n-1;i++)out[i]=out[i+1];ArrayResize(out,n-1);}
   void RemoveThree(MArray<ZWCount>& out,const ZWPivot &p,const int degree)
     {for(int i=ArraySize(out)-1;i>=0;i--)if(out[i].degree==degree && Same(out[i].pivot,p) && (out[i].wave_name==string("3")||out[i].wave_name==string("3?")))RemoveAt(out,i);}
   int RecordThree(const MArray<ZWPivot>& points,const int degree,const bool developing,const bool provedThird)
     {
      int accepted=1;if(ArraySize(points)<4)return accepted;
      ZWPivot origin=points[0],one=points[1],two=points[2],three=points[3];bool extended=ExtendedThree(points);
      bool conflict=Conflict(one,degree,string("1"))||Conflict(two,degree,string("2"));int found=-1;
      for(int i=0;i<ArraySize(m_anchors);i++)if(m_anchors[i].degree==degree && Same(m_anchors[i].origin,origin)&&Same(m_anchors[i].one,one)&&Same(m_anchors[i].two,two)){found=i;break;}
      if(conflict)accepted=0;
      else if(found>=0)
        {
         ZWAnchor prior=m_anchors[found];
         if(!Same(prior.three,three))
           {
            bool further=three.b>prior.three.b && (three.hi?three.p>prior.three.p:three.p<prior.three.p);
            bool provedExtension=extended && (!developing||provedThird);
            if(further&&extended&&developing&&!prior.developing&&degree==1&&!provedThird)
              {ZWPattern proof=Proof(streams[2].pivots,two,three,true);provedExtension=proof.score>=0;}
            if(further && (prior.developing||provedExtension)){RemoveThree(counts,prior.three,degree);RemoveThree(m_confirmed,prior.three,degree);accepted=prior.developing?1:2;}
            else accepted=0;
           }
         else if(extended&&!prior.developing&&developing)accepted=2;
         if(accepted>0){m_anchors[found].three=three;m_anchors[found].developing=developing&&prior.developing;}
        }
      else {int n=ArraySize(m_anchors);ArrayResize(m_anchors,n+1);m_anchors[n].origin=origin;m_anchors[n].one=one;m_anchors[n].two=two;m_anchors[n].three=three;m_anchors[n].degree=degree;m_anchors[n].developing=developing;}
      if(accepted>0&&extended)
        {int at=-1;for(int i=0;i<ArraySize(m_extensions);i++)if(m_extensions[i].degree==degree&&Same(m_extensions[i].two,two)){at=i;break;}
         if(at<0){at=ArraySize(m_extensions);ArrayResize(m_extensions,at+1);}m_extensions[at].two=two;m_extensions[at].three=three;m_extensions[at].degree=degree;m_extensions[at].proved=!developing||accepted==2;}
      return accepted;
     }
   bool InternalExtension(const ZWPivot &p,const int degree,const string wave)
     {for(int i=0;i<ArraySize(m_extensions);i++){ZWExtension s=m_extensions[i];bool outer=degree==s.degree&&Same(p,s.three)&&(wave==string("3")||wave==string("3?"));if(s.two.b<p.b&&p.b<=s.three.b&&degree>=s.degree&&!outer)return true;}return false;}
   bool Divergence(const MArray<ZWPivot>& p)
     {
      if(!opt.divergence||ArraySize(p)!=6)return false;bool up=!p[0].hi;
      double m3=Range(p[2].b,p[3].b,up?2:-2),m5=Range(p[4].b,p[5].b,up?2:-2);
      return p[4].b>p[3].b&&p[3].hi==p[5].hi&&m3!=EMPTY_VALUE&&m5!=EMPTY_VALUE && (up?p[5].p>p[3].p&&m5<m3:p[5].p<p[3].p&&m5>m3);
     }
   void AddLink(const ZWPivot &a,const ZWPivot &b,const int degree,const bool hidden)
     {for(int i=0;i<ArraySize(links);i++)if(links[i].degree==degree&&links[i].hidden==hidden&&Same(links[i].anchor,a)&&Same(links[i].endpoint,b))return;
      int n=ArraySize(links);ArrayResize(links,n+1);links[n].anchor=a;links[n].endpoint=b;links[n].degree=degree;links[n].hidden=hidden;}
   void Emit(const MArray<ZWPivot>& p,const int degree,const bool motive,const bool developing,const bool preserve,const bool provedThird=false)
     {
      int n=ArraySize(p);if(n<=1)return;int accepted=motive?RecordThree(p,degree,developing,provedThird):1;
      if(accepted>0)RecordPath(p,degree,motive,developing);
      if(accepted>0&&motive&&!developing&&Divergence(p))AddLink(p[3],p[5],degree,false);
      for(int i=1;i<n;i++)
        {
         bool extensionThree=motive&&i==3&&ExtendedThree(p);
         if(accepted==0||(developing&&!opt.show_developing&&!(i==3&&accepted==2))||(preserve&&!extensionThree&&Counted(p[i],degree)))continue;
         string name=motive?(string)i:(i==1?string("A"):i==2?string("B"):string("C"));if(developing&&!(i==3&&accepted==2))name+=string("?");
         if(extensionThree && Counted(p[i],degree))
           {if(StringFind(name,string("?"))<0)for(int j=ArraySize(counts)-1;j>=0;j--)if(counts[j].degree==degree&&Same(counts[j].pivot,p[i])&&StringFind(counts[j].wave_name,string("?"))>=0)RemoveAt(counts,j);
            bool found=false;for(int j=0;j<ArraySize(counts);j++)if(counts[j].degree==degree&&Same(counts[j].pivot,p[i])&&(counts[j].wave_name==string("3")||counts[j].wave_name==name))found=true;
            if(!found){int at=ArraySize(counts);ArrayResize(counts,at+1);counts[at].pivot=p[i];counts[at].degree=degree;counts[at].wave_name=name;}}
         else AddCount(p[i],degree,name);
        }
     }
   void Nested(const MArray<ZWPivot>& p)
     {if(!opt.show_micro||ArraySize(streams)<3)return;for(int i=1;i<ArraySize(p);i++){if(i==3&&ExtendedThree(p))continue;ZWPattern five=Proof(streams[2].pivots,p[i-1],p[i],true);MArray<ZWPivot> out;if(five.score>=0){ToArray(five,out);Emit(out,2,true,false,false);}else{ZWPattern abc=Proof(streams[2].pivots,p[i-1],p[i],false);if(abc.score>=0){ToArray(abc,out);Emit(out,2,false,false,false);}}}}
   ZWPattern FirstComplete(const MArray<ZWPivot>& p,const bool motive)
     {int legs=motive?5:3;for(int end=legs;end<ArraySize(p);end++){if(p[end].hi==p[0].hi)continue;MArray<ZWPivot> prefix;ArrayResize(prefix,end+1);ArrayCopy(prefix,p,0,0,end+1);ZWPattern result;if(motive)result=Search(prefix,5,1);else result=Correction(prefix,3);if(result.score>=0)return result;if(work_used>opt.work_limit)break;}return Empty();}
   ZWPattern Partial(const MArray<ZWPivot>& p,const bool motive)
     {
      int legs=MathMin(motive?4:2,ArraySize(p)-1);while(legs>=2){ZWPattern result;if(motive)result=Search(p,legs,1);else result=Correction(p,legs);if(result.score>=0)return result;legs--;}
      if(ArraySize(p)==2){ZWPivot a=p[0],b=p[1];int d=a.hi?-1:1;if(a.hi!=b.hi&&d*(b.p-a.p)>eps&&(!motive||Inside(a,b,MathMin(a.p,b.p),MathMax(a.p,b.p),eps))){ZWPattern r=Empty();r.count=2;r.points[0]=a;r.points[1]=b;r.score=0;return r;}}return Empty();
     }
   ZWPattern LockedExtension(const MArray<ZWPivot>& p,const int degree)
     {
      if(degree!=1||ArraySize(p)<4||work_used>=opt.work_limit)return Empty();ZWPivot origin=p[0],last=p[ArraySize(p)-1];
      for(int i=ArraySize(m_anchors)-1;i>=MathMax(0,ArraySize(m_anchors)-128);i--)
        {
         ZWAnchor a=m_anchors[i];if(a.degree!=degree||!Same(a.origin,origin))continue;ZWPivot three=a.three;
         for(int j=1;j<ArraySize(p);j++)if(p[j].b>a.three.b&&p[j].hi==three.hi&&(three.hi?p[j].p>three.p:p[j].p<three.p))three=p[j];
         if(Same(three,a.three))continue;MArray<ZWPivot> candidate;ArrayResize(candidate,4);candidate[0]=origin;candidate[1]=a.one;candidate[2]=a.two;candidate[3]=three;
         MArray<double> x;ArrayResize(x,5);for(int j=0;j<4;j++)x[j]=candidate[j].p;int d=origin.hi?-1:1;
         if(!ExtendedThree(candidate)||!Geometry(x,3,1,d,eps)||!Inside(a.two,three,MathMin(a.two.p,three.p),MathMax(a.two.p,three.p),eps))continue;
         ZWPattern proof=Proof(streams[2].pivots,a.two,three,true);if(proof.score<0){if(work_used>=opt.work_limit)break;continue;}
         if(last.b>three.b&&last.hi!=three.hi){x[4]=last.p;if(Geometry(x,4,1,d,eps)&&Adverse(three,last,d,a.one.p,eps)){ArrayResize(candidate,5);candidate[4]=last;}}
         ZWPattern result=Empty();result.count=ArraySize(candidate);for(int j=0;j<result.count;j++)result.points[j]=candidate[j];result.score=proof.score;return result;
        }return Empty();
     }
   ZWPattern FirstRealEndpoint(const ZWPivot &start,const int last,const bool motive)
     {for(int i=0;i<ArraySize(streams[1].pivots);i++){ZWPivot p=streams[1].pivots[i];if(p.b<=start.b||p.b>last||p.hi==start.hi)continue;ZWPattern r=Proof(streams[1].pivots,start,p,motive);if(r.score>=0)return r;if(work_used>opt.work_limit)break;}return Empty();}
   bool Sequential(const ZWPivot &start,const ZWPivot &finish,const bool fixedFinish)
     {
      bool havePair=false;ZWPivot anchor=start;MArray<ZWPattern> selected;MArray<bool> motives;int last=fixedFinish?finish.b:ArraySize(rates)-1;
      for(int pass=0;pass<4;pass++){ZWPattern five=FirstRealEndpoint(anchor,last,true);if(five.score<0)break;ZWPattern abc=FirstRealEndpoint(five.points[5],last,false);if(abc.score<0&&!havePair)break;int n=ArraySize(selected);ArrayResize(selected,n+1);ArrayResize(motives,n+1);selected[n]=five;motives[n]=true;if(abc.score<0)break;n++;ArrayResize(selected,n+1);ArrayResize(motives,n+1);selected[n]=abc;motives[n]=false;havePair=true;anchor=abc.points[3];if(fixedFinish&&anchor.b>=finish.b)break;}
      if(havePair)for(int i=0;i<ArraySize(selected);i++){MArray<ZWPivot> p;ToArray(selected[i],p);Emit(p,1,motives[i],false,false);Nested(p);}return havePair;
     }
   void Continue(const MArray<ZWPivot>& finer,const ZWPivot &start,const ZWPivot &finish,const bool fixedFinish,const int degree)
     {
      ZWPivot anchor=start;bool motive=true;int last=fixedFinish?finish.b:ArraySize(rates)-1;
      for(int i=0;i<ArraySize(counts);i++){ZWCount c=counts[i];if(c.degree==degree&&anchor.b<c.pivot.b&&c.pivot.b<=last&&(c.wave_name==string("5")||c.wave_name==string("C"))&&!InternalExtension(c.pivot,c.degree,c.wave_name)){anchor=c.pivot;motive=c.wave_name==string("C");}}
      if(fixedFinish&&anchor.b>=finish.b)return;
      for(int pass=0;pass<12;pass++)
        {
         MArray<ZWPivot> points;Collect(finer,anchor,finish,fixedFinish,points);if(ArraySize(points)<2)break;ZWPattern extended=Empty();if(motive)extended=LockedExtension(points,degree);
         if(extended.score>=0){MArray<ZWPivot> p;ToArray(extended,p);Emit(p,degree,true,true,true,true);break;}
         ZWPattern full=FirstComplete(points,motive);
         if(full.score>=0){MArray<ZWPivot> p;ToArray(full,p);Emit(p,degree,motive,false,true);ZWPivot next=full.points[full.count-1];if(next.b<=anchor.b)break;anchor=next;motive=!motive;if(fixedFinish&&anchor.b>=finish.b)break;}
         else {ZWPattern partial=Partial(points,motive);if(partial.score>=0&&opt.show_developing&&(!fixedFinish||!Settled(finish,degree-1))){MArray<ZWPivot> p;ToArray(partial,p);Emit(p,degree,motive,true,true);}break;}
        }
     }
   void Analysis()
     {
      int m=ArraySize(streams[0].pivots);if(!m)return;
      // Projection-only Micro capture runs after the unchanged parent pass.
      // Keep its remembered extension anchors outside the parent's bounded
      // anchor lookback, so enabling a projection cannot alter parent counts.
      bool captureOnly=opt.capture_micro_paths&&!opt.show_micro;
      MArray<ZWAnchor> microAnchors;MArray<ZWExtension> microExtensions;
      if(captureOnly)
        {
         for(int i=ArraySize(m_anchors)-1;i>=0;i--)if(m_anchors[i].degree>=2)
           {int at=ArraySize(microAnchors);ArrayResize(microAnchors,at+1);microAnchors[at]=m_anchors[i];int n=ArraySize(m_anchors);for(int j=i;j<n-1;j++)m_anchors[j]=m_anchors[j+1];ArrayResize(m_anchors,n-1);}
         for(int i=ArraySize(m_extensions)-1;i>=0;i--)if(m_extensions[i].degree>=2)
           {int at=ArraySize(microExtensions);ArrayResize(microExtensions,at+1);microExtensions[at]=m_extensions[i];int n=ArraySize(m_extensions);for(int j=i;j<n-1;j++)m_extensions[j]=m_extensions[j+1];ArrayResize(m_extensions,n-1);}
        }
      int first=MathMax(1,m-12);MArray<ZWPattern> fiveCache;ArrayResize(fiveCache,m);for(int i=0;i<m;i++)fiveCache[i]=Empty();
      for(int i=first;i<m;i++)
        {
         ZWPivot start=streams[0].pivots[i-1],finish=streams[0].pivots[i];ZWPattern five=Proof(streams[1].pivots,start,finish,true);fiveCache[i]=five;ZWPattern abc=Proof(streams[1].pivots,start,finish,false);
         MArray<ZWPivot> fp;ToArray(five,fp);ZWPattern extended=Empty();if(five.score>=0&&ExtendedThree(fp))extended=five;else{MArray<ZWPivot> p;Collect(streams[1].pivots,start,finish,true,p);extended=LockedExtension(p,1);}
         bool sequential=extended.score<0?Sequential(start,finish,true):false;
         if(extended.score>=0){MArray<ZWPivot> p;ToArray(extended,p);Emit(p,1,true,extended.count<6,false,true);Nested(p);}
         else if(five.score>=0){if(!sequential){Emit(fp,1,true,false,false);Nested(fp);}}
         else if(abc.score>=0&&!sequential){MArray<ZWPivot> p;ToArray(abc,p);Emit(p,1,false,false,false);Nested(p);}
        }
      for(int i=first;i<m-3;i++)
        {if(fiveCache[i].score<0)continue;MArray<ZWPivot> p;ArrayResize(p,4);for(int j=0;j<4;j++)p[j]=streams[0].pivots[i+j];ZWPattern abc=Correction(p,3);if(abc.score<0)continue;ToArray(abc,p);Emit(p,0,false,false,false);if(i+4<m)AddCount(streams[0].pivots[i+4],0,string("D"));}
      ZWPivot origin=streams[0].pivots[m-1],empty;ZeroMemory(empty);MArray<ZWPivot> active;Collect(streams[1].pivots,origin,empty,false,active);ZWPattern five=Search(active,5,1),extended=Empty();MArray<ZWPivot> fp;ToArray(five,fp);
      if(five.score>=0&&ExtendedThree(fp))extended=five;else extended=LockedExtension(active,1);bool sequential=extended.score<0?Sequential(origin,empty,false):false;
      if(extended.score>=0){MArray<ZWPivot> p;ToArray(extended,p);Emit(p,1,true,extended.count<6,false,true);Nested(p);}
      else if(!sequential)
        {if(five.score>=0){Emit(fp,1,true,false,false);Nested(fp);}else{ZWPattern abc=Correction(active,3);if(abc.score>=0){MArray<ZWPivot> p;ToArray(abc,p);Emit(p,1,false,false,false);Nested(p);}if(opt.show_developing&&ArraySize(active)>=3){ZWPattern partial=Partial(active,true);if(partial.score>=0){MArray<ZWPivot> p;ToArray(partial,p);Emit(p,1,true,true,false);Nested(p);}}}}
      for(int i=first;i<m;i++)Continue(streams[1].pivots,streams[0].pivots[i-1],streams[0].pivots[i],true,1);
      Continue(streams[1].pivots,origin,empty,false,1);
      if(captureOnly)
        {
         for(int i=ArraySize(microAnchors)-1;i>=0;i--){int at=ArraySize(m_anchors);ArrayResize(m_anchors,at+1);m_anchors[at]=microAnchors[i];}
         for(int i=ArraySize(microExtensions)-1;i>=0;i--){int at=ArraySize(m_extensions);ArrayResize(m_extensions,at+1);m_extensions[at]=microExtensions[i];}
        }
      int parentLimit=opt.work_limit;bool runMicro=opt.show_micro||opt.capture_micro_paths;
      if(captureOnly)
        {
         int allowance=(int)MathMin(12000,MathMax(0,parentLimit-work_used)/4);
         // The legacy beam counts its rejected stopping edge, so reserve one
         // edge inside this new allowance while leaving its semantics intact.
         if(allowance<2)runMicro=false;else opt.work_limit=work_used+allowance-1;
        }
      if(runMicro)
        {
         int mn=ArraySize(streams[1].pivots),childFirst=MathMax(1,mn-48),visible=streams[0].pivots[MathMax(0,m-13)].b;
         if(captureOnly)
           {
            // The projection button needs the newest eligible anchor first.
            // Older legs may use the remaining bounded capture allowance.
            if(mn&&streams[1].pivots[mn-1].b>=visible)Continue(streams[2].pivots,streams[1].pivots[mn-1],empty,false,2);
            for(int i=mn-1;i>=childFirst&&work_used<opt.work_limit;i--)if(streams[1].pivots[i-1].b>=visible)Continue(streams[2].pivots,streams[1].pivots[i-1],streams[1].pivots[i],true,2);
           }
         else
           {
            for(int i=childFirst;i<mn;i++)if(streams[1].pivots[i-1].b>=visible)Continue(streams[2].pivots,streams[1].pivots[i-1],streams[1].pivots[i],true,2);
            if(mn&&streams[1].pivots[mn-1].b>=visible)Continue(streams[2].pivots,streams[1].pivots[mn-1],empty,false,2);
           }
        }
      opt.work_limit=parentLimit;
     }
   bool HiddenMatch(const bool high,const double oldPrice,const double newPrice,const double oldOsc,const double newOsc)
     {bool side=!opt.hidden_same_side||(high?oldOsc>0&&newOsc>0:oldOsc<0&&newOsc<0);return side&&(high?newPrice<oldPrice&&newOsc>oldOsc:newPrice>oldPrice&&newOsc<oldOsc);}
   void HiddenDegree(const int degree)
     {
      int n=ArraySize(streams[degree].pivots);MArray<double> osc;MArray<int> ob;ArrayResize(osc,n);ArrayResize(ob,n);
      for(int i=0;i<n;i++){ZWPivot p=streams[degree].pivots[i];int left=p.b;if(opt.hidden_extremes){if(!i){osc[i]=EMPTY_VALUE;ob[i]=-1;continue;}left=streams[degree].pivots[i-1].b;}osc[i]=Range(left,p.b,p.hi?2:-2);ob[i]=-1;if(osc[i]!=EMPTY_VALUE)for(int b=p.b;b>=left;b--)if(m_macd[b]==osc[i]){ob[i]=b;break;}}
      int hc=-1,lc=-1;MArray<int> anchorOsc;MArray<double> anchorValue;ArrayResize(anchorOsc,ArraySize(links));ArrayResize(anchorValue,ArraySize(links));
      for(int i=2;i<n;i++)
        {ZWPivot previous=streams[degree].pivots[i-2],current=streams[degree].pivots[i];bool valid=previous.hi==current.hi&&ob[i-2]>=0&&ob[i]>ob[i-2]&&Known(current);bool extended=false;int chain=current.hi?hc:lc;
         if(valid&&chain>=0){bool direction=current.hi?current.p<previous.p:current.p>previous.p;int dist=current.b-links[chain].anchor.b;if(links[chain].endpoint.b==previous.b&&direction&&dist>=opt.hidden_min_bars&&dist<=opt.hidden_max_bars&&ob[i]>anchorOsc[chain]&&HiddenMatch(current.hi,links[chain].anchor.p,current.p,anchorValue[chain],osc[i])){links[chain].endpoint=current;extended=true;}}
         if(!extended){chain=-1;int dist=current.b-previous.b;if(valid&&dist>=opt.hidden_min_bars&&dist<=opt.hidden_max_bars&&HiddenMatch(current.hi,previous.p,current.p,osc[i-2],osc[i])){chain=ArraySize(links);AddLink(previous,current,degree,true);ArrayResize(anchorOsc,ArraySize(links));ArrayResize(anchorValue,ArraySize(links));if(chain<ArraySize(links)){anchorOsc[chain]=ob[i-2];anchorValue[chain]=osc[i-2];}else chain=-1;}}
         if(current.hi)hc=chain;else lc=chain;
        }
     }
   int TimeIndex(const MArray<MqlRates>& r,const datetime t)
     {int lo=0,hi=ArraySize(r);while(lo<hi){int mid=(lo+hi)/2;if(r[mid].time<t)lo=mid+1;else hi=mid;}return lo<ArraySize(r)&&r[lo].time==t?lo:-1;}
   bool Remap(ZWPivot &p,const MArray<MqlRates>& old)
     {if(p.known<0||p.known>=ArraySize(old))return false;int at=TimeIndex(rates,p.t),known=TimeIndex(rates,old[p.known].time);if(at<0||known<=at)return false;p.b=at;p.known=known;return Known(p);}
public:
   MArray<MqlRates> rates;
   MArray<ZWStream> streams;
   MArray<ZWCount> counts;
   MArray<ZWPath> paths;
   MArray<ZWDivLink> links;
   ZWOptions opt;
   double eps,mintick;
   int work_used;
   CZWCore() {m_cache_n=0;m_cache_levels=0;m_have_context=false;eps=0.000001;mintick=0.00001;work_used=0;m_signature=string("");}
   static bool Same(const ZWPivot &a,const ZWPivot &b) {return a.b==b.b&&a.p==b.p&&a.hi==b.hi;}
   static double Fit(const double ratio,const double target) {return ratio>0&&target>0?MathExp(-MathAbs(MathLog(ratio/target))*2):0;}
   static double BestFit(const double r,const double a,const double b=0,const double c=0,const double d=0,const double e=0)
     {return MathMax(MathMax(Fit(r,a),Fit(r,b)),MathMax(Fit(r,c),MathMax(Fit(r,d),Fit(r,e))));}
   static bool Geometry(const MArray<double>& x,const int legs,const int kind,const int d,const double epsilon)
     {
      if(ArraySize(x)<=legs||legs<1)return false;for(int j=1;j<=legs;j++)if((j%2!=0?d:-d)*(x[j]-x[j-1])<=epsilon)return false;
      if(kind==1||kind==2){if(legs>=2&&d*(x[2]-x[0])<=epsilon)return false;if(legs>=3&&d*(x[3]-x[1])<=epsilon)return false;if(legs>=4&&d*(x[4]-x[1])<=epsilon)return false;if(legs>=5){double one=MathAbs(x[1]-x[0]),three=MathAbs(x[3]-x[2]),five=MathAbs(x[5]-x[4]),beyond=d*(x[5]-x[3]);if((kind==1?beyond<=epsilon:beyond>epsilon)||three+epsilon<MathMin(one,five))return false;}}
      else if(kind==5&&legs>=2&&MathAbs(x[2]-x[1])+epsilon<.886*MathAbs(x[1]-x[0]))return false;
      if(kind!=1&&kind!=2&&legs>=3){double origin=d*(x[2]-x[0]),finish=d*(x[3]-x[1]);if(kind==4)return origin>epsilon&&finish>epsilon;if(kind==5)return origin>=-epsilon&&finish>epsilon;if(kind==6)return origin<-epsilon&&finish>epsilon;if(kind==7)return origin<-epsilon&&finish<-epsilon&&d*(x[3]-x[0])>epsilon;return false;}return true;
     }
   static double Score(const MArray<double>& x,const int legs,const int kind)
     {
      if(ArraySize(x)<=legs||legs<1)return 0;double a=MathAbs(x[1]-x[0]),sum=0;int n=0;if(a<=0)return 0;
      if(kind==1||kind==2){if(legs>=2){sum+=BestFit(MathAbs(x[2]-x[1])/a,.5,.618,.786,.886);n++;}if(legs>=3){sum+=BestFit(MathAbs(x[3]-x[2])/a,1,1.618,2,2.618,3);n++;}if(legs>=4){double three=MathAbs(x[3]-x[2]);sum+=BestFit(three>0?MathAbs(x[4]-x[3])/three:0,.236,.382);n++;}if(legs>=5){double four=MathAbs(x[4]-x[3]),three=MathAbs(x[3]-x[2]),five=MathAbs(x[5]-x[4]);sum+=MathMax(BestFit(four>0?five/four:0,1.236,1.618),BestFit(three>0?five/three:0,.5,.618,1));n++;}}
      else {if(legs>=2){double ratio=MathAbs(x[2]-x[1])/a;sum+=kind==4?BestFit(ratio,.382,.5,.618):BestFit(ratio,.9,1,1.13);n++;}if(legs>=3){sum+=BestFit(MathAbs(x[3]-x[2])/a,.786,1,1.236,1.618);n++;}}return n?sum/n:0;
     }
   bool Spend(const int amount=1) {if(amount<0||work_used+amount>opt.work_limit){work_used=opt.work_limit;return false;}work_used+=amount;return true;}
   bool Known(const ZWPivot &p) {return p.b>=0&&p.b<ArraySize(rates)&&p.known>p.b&&p.known<ArraySize(rates)&&rates[p.b].time==p.t&&p.p==(p.hi?rates[p.b].high:rates[p.b].low);}
   bool Settled(const ZWPivot &p,const int degree)
     {if(!Known(p)||degree<0||degree>=ArraySize(streams))return false;for(int i=ArraySize(streams[degree].pivots)-1;i>=0;i--){ZWPivot q=streams[degree].pivots[i];if(q.b<=p.b)break;if(q.hi!=p.hi)return true;}return false;}
   double Range(const int from,const int finish,const int mode)
     {
      if(from<0||finish<from||finish>=m_cache_n||((mode==2||mode==-2)&&!opt.divergence))return EMPTY_VALUE;
      int k=m_logs[finish-from+1],span=1<<k,a=k*m_cache_n+from,b=k*m_cache_n+finish-span+1;
      if(mode==1)return MathMax(m_high[a],m_high[b]);if(mode==-1)return MathMin(m_low[a],m_low[b]);if(mode==2)return MathMax(m_maxmacd[a],m_maxmacd[b]);if(mode==-2)return MathMin(m_minmacd[a],m_minmacd[b]);return EMPTY_VALUE;
     }
   bool Inside(const ZWPivot &a,const ZWPivot &b,const double lo,const double hi,const double epsilon)
     {if(a.b<0||b.b>=ArraySize(rates)||a.b>=b.b)return false;if(b.b<=a.b+1)return true;double l=Range(a.b+1,b.b-1,-1),h=Range(a.b+1,b.b-1,1);return l!=EMPTY_VALUE&&h!=EMPTY_VALUE&&l>=lo-epsilon&&h<=hi+epsilon;}
   bool Adverse(const ZWPivot &a,const ZWPivot &b,const int direction,const double level,const double epsilon)
     {if(a.b<0||b.b>=ArraySize(rates)||a.b>=b.b)return false;if(b.b<=a.b+1)return true;double value=Range(a.b+1,b.b-1,direction>0?-1:1);return value!=EMPTY_VALUE&&(direction>0?value>level+epsilon:value<level-epsilon);}
   void Collect(const MArray<ZWPivot>& stream,const ZWPivot &start,const ZWPivot &finish,const bool fixedFinish,MArray<ZWPivot>& out)
     {ArrayResize(out,0);if(!Known(start)||(fixedFinish&&(!Known(finish)||finish.b<=start.b)))return;ArrayResize(out,1);out[0]=start;for(int i=0;i<ArraySize(stream);i++){ZWPivot p=stream[i];if(p.b<=start.b||(fixedFinish&&p.b>=finish.b))continue;if(!Known(p)||!Append(out,p)){ArrayResize(out,0);return;}}if(fixedFinish){int n=ArraySize(out);if(n>1&&out[n-1].hi==finish.hi)out[n-1]=finish;else if(!Append(out,finish)){ArrayResize(out,0);return;}}if(ArraySize(out)<2)ArrayResize(out,0);}
   ZWPattern Search(const MArray<ZWPivot>& points,const int legs,const int kind)
     {
      int n=ArraySize(points);if(n<legs+1||n>256||legs<2||legs>5||work_used>=opt.work_limit)return Empty();int d=points[0].hi?-1:1,end=n-1;
      for(int i=1;i<n;i++)if(points[i].b<=points[i-1].b)return Empty();if(points[end].hi!=(legs%2!=0?d==1:d==-1))return Empty();
      MArray<ZWBeam> pool;ArrayResize(pool,1);ZeroMemory(pool[0]);int done=0;
      for(int stage=1;stage<=legs;stage++)
        {MArray<ZWBeam> next;for(int i=0;i<ArraySize(pool);i++){int a=pool[i].at[stage-1],move=stage%2!=0?d:-d,first=stage==legs?end:a+1,last=stage==legs?end:end-(legs-stage);
          for(int b=first;b<=last;b++){work_used++;if(work_used>opt.work_limit)break;ZWPivot pa=points[a],pb=points[b];if(pb.hi!=(move==1)||move*(pb.p-pa.p)<=eps)continue;bool role=(kind==1||kind==2)?(stage%2!=0):kind==4?stage!=2:stage==3;if(role&&!Inside(pa,pb,MathMin(pa.p,pb.p),MathMax(pa.p,pb.p),eps))continue;ZWBeam at=pool[i];at.at[stage]=b;MArray<double> x;ArrayResize(x,stage+1);for(int j=0;j<=stage;j++)x[j]=points[at.at[j]].p;if(!Geometry(x,stage,kind,d,eps))continue;if((kind==1||kind==2)&&stage==2&&!Adverse(pa,pb,d,x[0],eps))continue;if((kind==1||kind==2)&&stage==4&&!Adverse(pa,pb,d,x[1],eps))continue;at.score=Score(x,stage,kind);Keep(next,at);}if(work_used>opt.work_limit)break;}
         if(!ArraySize(next)||work_used>opt.work_limit)break;ArrayResize(pool,ArraySize(next));for(int i=0;i<ArraySize(next);i++)pool[i]=next[i];done=stage;}
      if(done!=legs)return Empty();int best=0;for(int i=1;i<ArraySize(pool);i++)if(pool[i].score>pool[best].score)best=i;ZWPattern result=Empty();result.count=legs+1;result.score=pool[best].score;for(int i=0;i<=legs;i++)result.points[i]=points[pool[best].at[i]];return result;
     }
   ZWPattern Correction(const MArray<ZWPivot>& points,const int legs)
     {ZWPattern best=Empty();for(int kind=4;kind<=7;kind++){ZWPattern candidate=Search(points,legs,kind);if(candidate.score>best.score)best=candidate;}return best;}
   ZWPattern Proof(const MArray<ZWPivot>& finer,const ZWPivot &start,const ZWPivot &finish,const bool motive)
     {if(start.hi==finish.hi)return Empty();MArray<ZWPivot> p;Collect(finer,start,finish,true,p);return motive?Search(p,5,1):Correction(p,3);}
   void AddCount(const ZWPivot &p,const int degree,const string wave)
     {bool exists=false,developing=StringFind(wave,string("?"))>=0;for(int i=ArraySize(counts)-1;i>=0;i--){if(counts[i].degree!=degree||!Same(counts[i].pivot,p))continue;bool old=StringFind(counts[i].wave_name,string("?"))>=0;if(!developing&&old)RemoveAt(counts,i);else if(!old||counts[i].wave_name==wave)exists=true;}if(!exists){int n=ArraySize(counts);ArrayResize(counts,n+1);counts[n].pivot=p;counts[n].degree=degree;counts[n].wave_name=wave;}}
   void RecordPath(const MArray<ZWPivot>& p,const int degree,const bool motive,const bool developing,const string family=string(""))
     {
      int size=ArraySize(p);if(size<2||size>6||degree<0||degree>2||(degree==2&&!opt.capture_micro_paths))return;int total=0,oldest=-1;
      for(int i=0;i<ArraySize(paths);i++){if(paths[i].degree!=degree)continue;total++;if(oldest<0||paths[i].points[paths[i].count-1].b<paths[oldest].points[paths[oldest].count-1].b)oldest=i;bool same=paths[i].motive==motive&&paths[i].family==family&&paths[i].count==size;if(same)for(int j=0;j<size;j++)if(!Same(paths[i].points[j],p[j]))same=false;if(same){paths[i].developing=paths[i].developing&&developing;return;}}
      int at=ArraySize(paths);if(total>=12){if(p[size-1].b<paths[oldest].points[paths[oldest].count-1].b)return;at=oldest;}else ArrayResize(paths,at+1);paths[at].count=size;paths[at].degree=degree;paths[at].motive=motive;paths[at].developing=developing;paths[at].family=family;for(int j=0;j<size;j++)paths[at].points[j]=p[j];
     }
   bool Build(const MArray<MqlRates>& closed,const ZWOptions &options,const double tick)
     {
      int inputN=ArraySize(closed);if(inputN<1||!MathIsValidNumber(tick)||tick<=0)return false;
      if(!MathIsValidNumber(options.deviation)||options.deviation<.00001||options.deviation>100||!MathIsValidNumber(options.factor)||options.factor<=1||options.factor>20||options.depth<2||options.depth>200||options.child_depth<2||options.child_depth>100||options.history<1||options.history>10000||options.max_depth<3||options.max_depth>16||options.work_limit<100||options.hidden_min_bars<1||options.hidden_max_bars<options.hidden_min_bars||options.deviation/(options.factor*options.factor)<.00001)return false;
      for(int i=0;i<inputN;i++)if(!MathIsValidNumber(closed[i].open)||!MathIsValidNumber(closed[i].high)||!MathIsValidNumber(closed[i].low)||!MathIsValidNumber(closed[i].close)||closed[i].high<closed[i].low||closed[i].high<MathMax(closed[i].open,closed[i].close)||closed[i].low>MathMin(closed[i].open,closed[i].close)||(i>0&&closed[i].time<=closed[i-1].time))return false;
      MArray<MqlRates> old;ArrayCopy(old,rates);MArray<ZWPath> previousMicro;
      if(options.capture_micro_paths)for(int i=0;i<ArraySize(paths);i++)if(paths[i].degree==2){int at=ArraySize(previousMicro);ArrayResize(previousMicro,at+1);previousMicro[at]=paths[i];}
      string signature=Signature(options);bool restore=signature==m_signature&&mintick==tick&&ArraySize(old)>0&&closed[inputN-1].time>old[ArraySize(old)-1].time;
      int start=MathMax(0,inputN-options.history),n=inputN-start;
      // One pre-window context candle matches the source's closed-history
      // boundary without making an out-of-window endpoint eligible.
      m_have_context=start>0;if(m_have_context)m_context=closed[start-1];
      ArrayResize(rates,n);ArrayCopy(rates,closed,0,start,n);opt=options;mintick=tick;eps=tick*.1;work_used=0;m_signature=signature;
      if(restore){bool shared=false;for(int i=0;i<ArraySize(old);i++){int at=TimeIndex(rates,old[i].time);if(at<0){if(old[i].time>=rates[0].time&&old[i].time<=rates[n-1].time){restore=false;break;}continue;}shared=true;if(old[i].open!=rates[at].open||old[i].high!=rates[at].high||old[i].low!=rates[at].low||old[i].close!=rates[at].close){restore=false;break;}}if(!shared)restore=false;for(int i=0;restore&&i<n;i++)if(rates[i].time>=old[0].time&&rates[i].time<=old[ArraySize(old)-1].time&&TimeIndex(old,rates[i].time)<0)restore=false;}
      ArrayResize(counts,0);ArrayResize(paths,0);ArrayResize(links,0);
      if(restore&&opt.capture_micro_paths)
        {
         // Continue may start at a remembered completed 5/C and need no new
         // emission. Retain that proven source path across a compatible close
         // instead of making its projection disappear for lack of re-emission.
         for(int i=0;i<ArraySize(previousMicro);i++)
           {
            ZWPath p=previousMicro[i];bool valid=p.count>=2&&p.count<=6;MArray<ZWPivot> points;ArrayResize(points,p.count);
            for(int j=0;j<p.count&&valid;j++){points[j]=p.points[j];valid=Remap(points[j],old);}
            if(valid)RecordPath(points,2,p.motive,p.developing,p.family);
           }
        }
      if(restore)
        {for(int i=ArraySize(m_confirmed)-1;i>=0;i--){ZWPivot p=m_confirmed[i].pivot;if(!Remap(p,old))RemoveAt(m_confirmed,i);else m_confirmed[i].pivot=p;}
         for(int i=ArraySize(m_anchors)-1;i>=0;i--){ZWAnchor a=m_anchors[i];bool ok=!a.developing&&Remap(a.origin,old)&&Remap(a.one,old)&&Remap(a.two,old)&&Remap(a.three,old);if(ok)m_anchors[i]=a;else{int size=ArraySize(m_anchors);for(int j=i;j<size-1;j++)m_anchors[j]=m_anchors[j+1];ArrayResize(m_anchors,size-1);}}
         for(int i=ArraySize(m_extensions)-1;i>=0;i--){ZWExtension e=m_extensions[i];bool ok=e.proved&&Remap(e.two,old)&&Remap(e.three,old);if(ok)m_extensions[i]=e;else{int size=ArraySize(m_extensions);for(int j=i;j<size-1;j++)m_extensions[j]=m_extensions[j+1];ArrayResize(m_extensions,size-1);}}}
      else {ArrayResize(m_confirmed,0);ArrayResize(m_anchors,0);ArrayResize(m_extensions,0);}
      ArrayResize(m_macd,n);double fast=closed[0].close,slow=fast;
      for(int i=0;i<inputN;i++){if(i){fast=(2.0/13)*closed[i].close+(11.0/13)*fast;slow=(2.0/27)*closed[i].close+(25.0/27)*slow;}if(i>=start)m_macd[i-start]=opt.divergence?fast-slow:0;}
      int degrees=3,levels=opt.hierarchy&&opt.subwaves?opt.max_depth:3;
      if(opt.subwaves)for(int degree=3;degree<=levels;degree++){if(opt.deviation/MathPow(opt.factor,degree)<.00001)break;degrees=degree+1;}
      ArrayResize(streams,degrees);for(int degree=0;degree<degrees;degree++){ArrayResize(streams[degree].pivots,0);streams[degree].reversal=opt.deviation/MathPow(opt.factor,degree);}
      for(int end=0;end<n;end++)for(int degree=0;degree<degrees;degree++){int legs=degree==0?opt.depth:degree==1?opt.child_depth:2,radius=MathMax(2,legs/2);ZWPivot p;if(PivotAt(end,radius,true,p))Register(degree,p);if(PivotAt(end,radius,false,p))Register(degree,p);}
      Cache();for(int i=ArraySize(m_confirmed)-1;i>=0;i--)if(Known(m_confirmed[i].pivot)){int at=ArraySize(counts);ArrayResize(counts,at+1);counts[at]=m_confirmed[i];}
      Analysis();ArrayResize(m_confirmed,0);for(int i=0;i<ArraySize(counts);i++)if(StringFind(counts[i].wave_name,string("?"))<0&&Settled(counts[i].pivot,counts[i].degree)){int at=ArraySize(m_confirmed);ArrayResize(m_confirmed,at+1);m_confirmed[at]=counts[i];}
      for(int i=ArraySize(counts)-1;i>=0;i--)if(InternalExtension(counts[i].pivot,counts[i].degree,counts[i].wave_name))RemoveAt(counts,i);
      for(int i=ArraySize(links)-1;i>=0;i--){bool remove=false;for(int j=0;j<ArraySize(m_extensions);j++)if(links[i].degree>=m_extensions[j].degree&&links[i].anchor.b>m_extensions[j].two.b&&links[i].endpoint.b<=m_extensions[j].three.b)remove=true;if(remove){int size=ArraySize(links);for(int j=i;j<size-1;j++)links[j]=links[j+1];ArrayResize(links,size-1);}}
      if(opt.divergence&&opt.show_hidden)for(int degree=0;degree<MathMin(3,degrees);degree++)HiddenDegree(degree);
      return true;
     }
  };
#endif
