#include "mql_compat.hpp"
#include "generated/HPXSession.hpp"
#include <iostream>
#include <stdexcept>
static int assertions=0;
void require(bool ok,const char* message) { assertions++;if(!ok)throw std::runtime_error(message); }
void near(double actual,double expected,const char* message) { require(std::abs(actual-expected)<1e-9,message); }

int main() {
    try {
        // Value semantics are essential to the unchanged branching proof code.
        MArray<ZWPattern> a(1);a[0].points[0].p=42;MArray<ZWPattern> b=a;b[0].points[0].p=7;
        near(a[0].points[0].p,42,"nested MQL array copy aliases original");
        ZeroMemory(b[0]);near(b[0].points[0].p,0,"ZeroMemory does not reset nested arrays");
        MArray<double> x={0,10,4,24,16,30};
        require(CZWCore::Geometry(x,5,1,1,1e-8),"valid impulse rejected");
        x[5]=22;require(!CZWCore::Geometry(x,5,1,1,1e-8),"truncated fifth accepted as full impulse");
        require(CZWCore::Geometry(x,5,2,1,1e-8),"truncated fifth geometry rejected");
        x={0,10,4,11,10.5,30};require(!CZWCore::Geometry(x,5,1,1,1e-8),"shortest third accepted");
        x={0,10,-1,24,16,30};require(!CZWCore::Geometry(x,5,1,1,1e-8),"wave2 passed origin");
        x={0,-10,-4,-24,-16,-30};require(CZWCore::Geometry(x,5,1,-1,1e-8),"bearish impulse rejected");
        x={0,10,4,15};require(CZWCore::Geometry(x,3,4,1,1e-8),"zigzag rejected");
        x={0,10,1,15};require(CZWCore::Geometry(x,3,5,1,1e-8),"regular flat rejected");
        x={0,10,-2,15};require(CZWCore::Geometry(x,3,6,1,1e-8),"expanded flat rejected");
        x={0,10,-2,8};require(CZWCore::Geometry(x,3,7,1,1e-8),"running flat rejected");
        near(CZWCore::Fit(.618,.618),1,"Fibonacci perfect-fit score");
        require(CZWCore::Fit(.4,.618)<CZWCore::Fit(.6,.618),"Fibonacci fit ranking");
        MArray<ZWBand> bands;ZWProfile(1,bands);require(bands.size()==4,"wave2 band count");
        near(bands[0].lo,.236,"wave2 lower band");near(bands[1].hi,.786,"wave2 most-common band");
        ZWProfile(7,bands);require(bands.size()==10,"waveC profile completeness");
        ZWProfile(12,bands);require(bands.size()==6,"barrier triangle profile completeness");
        ZWPath path{};path.count=2;path.motive=true;path.points[0].p=100;path.points[1].p=110;
        double base,unit;string wave;
        require(ZWFibSpec(path,false,true,base,unit,wave)==1,"active wave1 targets wave2");
        near(base,110,"wave2 anchor");near(unit,-10,"wave2 retracement direction");
        path.count=4;path.points[2].p=104;path.points[3].p=124;
        require(ZWFibSpec(path,false,true,base,unit,wave)==2,"Larry wave3 profile");near(base,100,"Larry origin anchor");
        require(ZWFibSpec(path,false,false,base,unit,wave)==3,"trend-based wave3 profile");near(base,104,"trend wave3 anchor");
        require(ZWFibSpec(path,true,true,base,unit,wave)==4,"next wave4 profile");near(base,124,"wave4 anchor");near(unit,-20,"wave4 unit");
        require(ZWNotationToken("1",3)==string("①"),"Primary degree notation");
        require(ZWNotationToken("3?",1)==string("(III)?"),"developing Roman notation");
        require(ZWNotation("1 / 3?",3,true)==string("① / ③?"),"joined degree notation");
        require(ZWSAllowed("Triangle Contracting","4",false,""),"wave4 triangle grammar");
        require(!ZWSAllowed("Triangle Contracting","2",false,""),"wave2 triangle prohibited");
        require(!ZWSAllowed("Leading Diagonal Contracting","3",true,""),"third wave diagonal prohibited");
        CZWRender draw;draw.Begin();draw.Text(1,100,"1",1,8,1,"a","same");draw.Text(1,100,"3",1,8,1,"b","same");
        require(draw.texts.size()==1&&draw.texts[0].text==string("1 / 3"),"shared pivot label joining");
        draw.Text(1,100,"1?",1,8,1,"a","same");require(draw.texts.size()==1&&draw.texts[0].text==string("1 / 3"),"developing duplicate caption");
        MArray<MqlRates> history(420);
        for(int i=0;i<history.size();i++) {
            double price=100+15*std::sin(i*.21)+3*std::sin(i*.77);
            history[i].time=1700000000+i*60;history[i].open=history[i].close=price;history[i].high=price+.5;history[i].low=price-.5;
        }
        ZWOptions options;ZWDefaults(options);options.depth=4;options.child_depth=2;options.deviation=9;options.history=400;options.capture_micro_paths=true;
        CZWCore core;require(core.Build(history,options,.01),"full source build rejected valid history");
        require(core.rates.size()==400&&core.rates[0].time==history[20].time,"source history window");
        require(core.streams.size()>=3,"Large Child Micro stream generation");
        require(core.streams[0].pivots.size()>5,"Large causal pivots missing");
        for(int degree=0;degree<3;degree++)for(int i=0;i<core.streams[degree].pivots.size();i++) {
            auto p=core.streams[degree].pivots[i];require(core.Known(p),"noncausal or wrong-coordinate pivot");
            if(i) {auto previous=core.streams[degree].pivots[i-1];require(previous.b<p.b&&previous.hi!=p.hi,"unordered or same-side pivots");}
        }
        for(int from=0;from<380;from+=37) {
            int end=from+19;double high=-DBL_MAX,low=DBL_MAX;
            for(int i=from;i<=end;i++){high=std::max(high,core.rates[i].high);low=std::min(low,core.rates[i].low);}
            near(core.Range(from,end,1),high,"sparse range maximum");near(core.Range(from,end,-1),low,"sparse range minimum");
        }
        require(core.Range(-1,2,1)==EMPTY_VALUE,"out-of-window sparse range accepted");
        CZWStructures structures;MArray<ZWPattern> patterns;structures.Scan(core,patterns);
        for(int i=0;i<patterns.size();i++) {
            require(patterns[i].count>=4&&patterns[i].count<=6,"invalid scanned pattern size");
            auto proof=structures.Validate(core,patterns[i]);
            require(proof.status==string("valid")||proof.status==string("invalid")||proof.status==string("incomplete"),"invalid proof status");
            require(proof.nodes<=options.max_nodes+32,"hierarchy proof exceeded bound");
        }
        HPXSession session;session.g_owner=true;session.InpLargeDepth=4;session.InpChildDepth=2;session.InpHistoryBars=400;
        session.InpLargeZigZag=true;session.ZWConfigure();session.m_tick=.01;session.g_livePrice=history[419].close;
        session.g_formingTime=history[419].time+60;session.ZWAnalyze(history);session.ZWPaint();
        require(session.g_ready,"source analysis not ready");require(session.g_draw.lines.size()>0,"source Paint produced no scene");
        require(session.g_proofs.size()==session.g_patterns.size(),"proof/pattern alignment");
        require(session.g_draw.lines.size()<=500&&session.g_draw.texts.size()<=220,"source scene bounds exceeded");
        auto previous=core.rates[core.rates.size()-1].time;history.resize(421);history[420]=history[419];history[420].time+=60;
        require(core.Build(history,options,.01)&&core.rates[core.rates.size()-1].time>previous,"incremental closed history failed");
        auto broken=history;broken[2].time=broken[1].time;require(!core.Build(broken,options,.01),"duplicate candle timestamp accepted");
        broken=history;broken[2].high=broken[2].low-1;require(!core.Build(broken,options,.01),"invalid OHLC accepted");
        require(!core.Build(history,options,0),"zero tick size accepted");
        session.InpLargeReversal=.00001;session.InpSubwaveDivisor=20;require(!session.ZWValidInputs(),"too-small micro reversal accepted");
        std::cout<<"PASS: "<<assertions<<" HPX ZWave native assertions; patterns="<<patterns.size()<<" sceneLines="<<session.g_draw.lines.size()<<" sceneTexts="<<session.g_draw.texts.size()<<"\n";
        return 0;
    }catch(const std::exception& failure) {std::cerr<<"FAIL after "<<assertions<<": "<<failure.what()<<"\n";return 1;}
}
