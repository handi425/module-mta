// This Source Code Form is subject to the Mozilla Public License, v. 2.0.
// https://mozilla.org/MPL/2.0/. Created by XoRonX | Mr Poleks.
#property copyright "XoRonX | Mr Poleks — HPX Markets"
#property version "1.02"
#property description "HPX Zwave Pro: Elliott Wave, subwave bertingkat, Fibonacci dan skenario bersyarat."
#property description "Menggunakan candle broker MT5. Reversal Large bawaan 9%. Tanpa panel."
#property indicator_chart_window
#property indicator_plots 0
#property indicator_buffers 0
#include "../Include/HPXZWaveStructures.mqh"
#include "../Include/HPXZWaveTargets.mqh"

enum ZWBaseDegree {ZW_GRAND_SUPERCYCLE=0,ZW_SUPERCYCLE=1,ZW_CYCLE=2,ZW_PRIMARY=3,ZW_INTERMEDIATE=4,ZW_MINOR=5,ZW_MINUTE=6};
enum ZWTargetDegree {ZW_LARGE=0,ZW_CHILD=1,ZW_MICRO=2};
input group "ZigZag dan counting"
input double InpLargeReversal=9.0; // Reversal Large ZigZag (%)
input double InpSubwaveDivisor=3.0; // Pembagi reversal subwave
input int InpLargeDepth=10; // Kedalaman pivot Large
input int InpChildDepth=4; // Kedalaman pivot Child
input int InpHistoryBars=10000; // Maksimum candle selesai
input int InpVisibleLargePivots=24; // Pivot Large yang ditampilkan
input bool InpDeveloping=true; // Counting berkembang dengan tanda ?
input bool InpMicroCounting=false; // Label counting Micro tambahan
input bool InpLargeZigZag=false; // Garis ZigZag Large
input bool InpChildZigZag=false; // Garis ZigZag Child
input group "Struktur Elliott"
input bool InpImpulses=true; // Deteksi impulse lengkap
input bool InpImpulseLines=false; // Tampilkan garis impulse
input bool InpDiagonals=true; // Leading / Ending Diagonal
input bool InpTriangles=true; // Contracting / Barrier / Expanding Triangle
input bool InpABC=true; // Zigzag dan Flat ABC
input bool InpCombinations=true; // Double / Triple Zigzag dan Combination
input bool InpTruncation=true; // Truncated fifth dengan bukti subwave
input bool InpExtensions=true; // Extension W1 / W3 / W5 dengan bukti subwave
input bool InpNestedSubwaves=true; // Subwave di dalam subwave
input bool InpMicroStructures=true; // Struktur pada derajat Micro
input int InpRecentPatterns=2; // Struktur terakhir per keluarga / derajat
input bool InpSubdivisionOnly=false; // Hanya pola dengan bukti subdivisi S
input group "Validasi hierarki Elliott"
input bool InpHierarchy=true; // Validasi hierarki
input int InpHierarchyDepth=12; // Kedalaman derajat bukti (4-16)
input int InpHierarchyNodes=2000; // Maksimum simpul per pola
input bool InpCompleteHierarchyOnly=false; // Hanya hierarki sepenuhnya valid
input group "Notasi, warna, dan label"
input bool InpDegreeNotation=true; // Notasi Elliott menurut derajat
input ZWBaseDegree InpBaseDegree=ZW_PRIMARY; // Notasi derajat Large
input color InpLargeColor=C'96,165,250'; // Warna Large
input color InpChildColor=C'251,146,60'; // Warna Child
input color InpMicroColor=C'74,222,128'; // Warna subwave terdalam yang ditampilkan
input bool InpSeparateLabels=true; // Pisahkan label yang berdekatan
input int InpLabelSize=8; // Ukuran teks wave
input double InpLabelGap=.15; // Jarak label dari pivot (ATR)
input double InpLabelRows=.35; // Jarak antarbaris label (ATR)
input bool InpPatternTitles=true; // Nama pola dan bukti G / S / H
input int InpBoundaryForward=20; // Perpanjangan batas pola (candle)
input group "Fibonacci"
input bool InpFibonacci=true; // Fibonacci berdasarkan counting
input ZWTargetDegree InpFibonacciDegree=ZW_CHILD; // Derajat proyeksi awal (Large / Child / Micro)
input bool InpFibonacciNext=false; // Wave berikutnya; false = aktif / terakhir
input bool InpLarryPull=true; // Larry Pull; false = Trend Based
input bool InpUncommon=true; // Kategori Tak umum
input bool InpMostCommon=true; // Kategori Paling umum
input bool InpCommon=true; // Kategori Umum
input bool InpVeryCommon=true; // Kategori Sangat umum
input bool InpRare=false; // Kategori Langka
input bool InpFibonacciShade=true; // Latar zona Fibonacci
input int InpFibonacciForward=20; // Panjang ke kanan (candle)
input group "Skenario arah"
input bool InpProjection=true; // Tampilkan skenario bersyarat
input bool InpProjectionAlternative=true; // Skenario alternatif setelah 5 / C / E
input bool InpProjectionLevels=true; // Level pemicu dan invalidasi
input int InpProjectionHorizon=30; // Ruang gambar skenario (candle)
input group "Tombol pilihan proyeksi"
input bool InpProjectionButton=true; // Tombol pergantian ZW Large / Child / Micro
input int InpProjectionButtonRight=8; // Jarak tombol dari pojok kanan (piksel)
input int InpProjectionButtonTop=8; // Jarak tombol dari pojok atas (piksel)
input group "Divergence"
input bool InpDivergence=false; // Aktifkan Divergence (bawaan Off)
input bool InpRegularDivergence=true; // Divergence MACD W3-W5
input bool InpHiddenDivergence=true; // Hidden Divergence MACD
input int InpHiddenMinBars=5; // Minimum jarak pivot
input int InpHiddenMaxBars=500; // Maksimum jarak pivot
input bool InpHiddenSwingExtremes=true; // Gunakan ekstrem MACD pada swing
input bool InpHiddenSameSide=false; // MACD harus pada sisi nol yang sama
input group "Kinerja dan instance"
input int InpWorkLimit=80000; // Batas pekerjaan geometri per candle
input int InpCandidateLimit=24; // Maksimum kandidat bukti per candle
input string InpInstanceTag="1"; // ID unik tiap instance pada chart

CZWCore g_zw;
CZWStructures g_structures;
CZWRender g_draw;
CZWTargets g_targets;
ZWPattern g_patterns[];
ZWProof g_proofs[];
ZWOptions g_options;
ZWTargetOptions g_targetOptions;
datetime g_closedTime=0,g_formingTime=0;
double g_livePrice=0;
bool g_ready=false,g_dirty=true,g_owner=false;
string g_lock="";
string g_projectionKey="";
int g_projectionDegree=1;
ulong g_lastPaint=0,g_waitUntil=0;
int g_lastTotal=0;

bool ZWValidTag()
{
   int n=StringLen(InpInstanceTag);if(n<1||n>12)return false;
   for(int i=0;i<n;i++){ushort c=StringGetCharacter(InpInstanceTag,i);if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'))return false;}
   return true;
}
bool ZWValidInputs()
{
   return ZWValidTag()&&MathIsValidNumber(InpLargeReversal)&&InpLargeReversal>=.00001&&InpLargeReversal<=100&&
      MathIsValidNumber(InpSubwaveDivisor)&&InpSubwaveDivisor>1&&InpSubwaveDivisor<=20&&InpLargeReversal/(InpSubwaveDivisor*InpSubwaveDivisor)>=.00001&&
      InpLargeDepth>=2&&InpLargeDepth<=200&&InpChildDepth>=2&&InpChildDepth<=100&&InpHistoryBars>=100&&InpHistoryBars<=10000&&
      InpVisibleLargePivots>=2&&InpVisibleLargePivots<=100&&InpRecentPatterns>=1&&InpRecentPatterns<=5&&
      InpHierarchyDepth>=4&&InpHierarchyDepth<=16&&InpHierarchyNodes>=100&&InpHierarchyNodes<=5000&&
      InpWorkLimit>=10000&&InpWorkLimit<=200000&&InpCandidateLimit>=6&&InpCandidateLimit<=48&&
      InpLabelSize>=6&&InpLabelSize<=20&&MathIsValidNumber(InpLabelGap)&&InpLabelGap>=.05&&InpLabelGap<=5&&
      MathIsValidNumber(InpLabelRows)&&InpLabelRows>=.1&&InpLabelRows<=5&&InpBoundaryForward>=0&&InpBoundaryForward<=200&&
      InpFibonacciForward>=1&&InpFibonacciForward<=200&&InpProjectionHorizon>=1&&InpProjectionHorizon<=200&&
      (int)InpFibonacciDegree>=0&&(int)InpFibonacciDegree<=2&&InpProjectionButtonRight>=0&&InpProjectionButtonRight<=2000&&InpProjectionButtonTop>=0&&InpProjectionButtonTop<=2000&&
      InpHiddenMinBars>=1&&InpHiddenMaxBars>=InpHiddenMinBars&&InpHiddenMaxBars<=10000;
}
void ZWConfigure()
{
   ZWDefaults(g_options);g_options.deviation=InpLargeReversal;g_options.factor=InpSubwaveDivisor;
   g_options.depth=InpLargeDepth;g_options.child_depth=InpChildDepth;g_options.history=InpHistoryBars;
   g_options.max_depth=InpHierarchyDepth;g_options.max_nodes=InpHierarchyNodes;g_options.work_limit=InpWorkLimit;
   g_options.candidate_limit=InpCandidateLimit;g_options.recent_patterns=InpRecentPatterns;
   g_options.subwaves=InpNestedSubwaves;g_options.hierarchy=InpHierarchy;g_options.divergence=InpDivergence;
   g_options.triangles=InpTriangles;g_options.abc=InpABC;g_options.impulses=InpImpulses;g_options.diagonals=InpDiagonals;
   g_options.combinations=InpCombinations;g_options.truncation=InpTruncation;g_options.extensions=InpExtensions;
   g_options.show_developing=InpDeveloping;g_options.show_micro=InpMicroCounting;g_options.capture_micro_paths=true;g_options.show_hidden=InpHiddenDivergence;
   g_options.hidden_min_bars=InpHiddenMinBars;g_options.hidden_max_bars=InpHiddenMaxBars;
   g_options.hidden_extremes=InpHiddenSwingExtremes;g_options.hidden_same_side=InpHiddenSameSide;
   ZWTargetDefaults(g_targetOptions);g_targetOptions.fibonacci=InpFibonacci;g_targetOptions.degree=(int)InpFibonacciDegree;
   g_targetOptions.next_wave=InpFibonacciNext;g_targetOptions.developing=InpDeveloping;g_targetOptions.larry=InpLarryPull;
   g_targetOptions.categories[0]=InpUncommon;g_targetOptions.categories[1]=InpMostCommon;g_targetOptions.categories[2]=InpCommon;g_targetOptions.categories[3]=InpVeryCommon;
   g_targetOptions.rare=InpRare;g_targetOptions.shade=InpFibonacciShade;g_targetOptions.forward=InpFibonacciForward;
   g_targetOptions.projection=InpProjection;g_targetOptions.alternative=InpProjectionAlternative;
   g_targetOptions.levels=InpProjectionLevels;g_targetOptions.horizon=InpProjectionHorizon;
   g_draw.separate=InpSeparateLabels;g_draw.gap=InpLabelGap;g_draw.row=InpLabelRows;
}
color ZWInk(const int degree){return degree==0?InpLargeColor:degree==1?InpChildColor:InpMicroColor;}
string ZWDegreeName(const int degree){return degree==0?"Large":degree==1?"Child":"Micro";}
void ZWLoadProjection()
{
   g_projectionDegree=(int)InpFibonacciDegree;
   string inputKey=g_projectionKey+"_I";
   if(GlobalVariableCheck(g_projectionKey)&&GlobalVariableCheck(inputKey)&&GlobalVariableGet(inputKey)==(double)InpFibonacciDegree)
   {
      double saved=GlobalVariableGet(g_projectionKey);
      if(MathIsValidNumber(saved)&&saved>=0&&saved<=2&&saved==MathFloor(saved))g_projectionDegree=(int)saved;
   }
   g_targetOptions.degree=g_projectionDegree;
   GlobalVariableSet(g_projectionKey,g_projectionDegree);GlobalVariableSet(inputKey,(double)InpFibonacciDegree);
}
void ZWProjectionButton()
{
   if(!g_owner)return;string name=g_draw.prefix+"projection";
   if(!InpProjectionButton){ObjectDelete(0,name);return;}
   int chartWidth=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS),chartHeight=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0);
   int width=(int)MathMin(166,MathMax(100,chartWidth-24));
   int right=(int)MathMin(InpProjectionButtonRight,MathMax(0,chartWidth-width-4));
   int top=(int)MathMin(InpProjectionButtonTop,MathMax(0,chartHeight-32));
   if(ObjectFind(0,name)<0)ObjectCreate(0,name,OBJ_BUTTON,0,0,0);
   color background=(color)ChartGetInteger(0,CHART_COLOR_BACKGROUND);
   color foreground=(color)ChartGetInteger(0,CHART_COLOR_FOREGROUND);
   if(foreground==background){int rgb=(int)background;foreground=((rgb&255)+((rgb>>8)&255)+((rgb>>16)&255)>382)?clrBlack:clrWhite;}
   color surface=g_draw.Blend(foreground,.07),border=g_draw.Blend(foreground,.23);
   ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_RIGHT_UPPER);ObjectSetInteger(0,name,OBJPROP_XDISTANCE,width+right);ObjectSetInteger(0,name,OBJPROP_YDISTANCE,top);
   ObjectSetInteger(0,name,OBJPROP_XSIZE,width);ObjectSetInteger(0,name,OBJPROP_YSIZE,28);
   ObjectSetInteger(0,name,OBJPROP_COLOR,ZWInk(g_projectionDegree));ObjectSetInteger(0,name,OBJPROP_BGCOLOR,surface);ObjectSetInteger(0,name,OBJPROP_BORDER_COLOR,border);
   ObjectSetInteger(0,name,OBJPROP_FONTSIZE,9);ObjectSetString(0,name,OBJPROP_FONT,"Arial");
   ObjectSetInteger(0,name,OBJPROP_STATE,false);ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,name,OBJPROP_SELECTED,false);ObjectSetInteger(0,name,OBJPROP_BACK,false);
   ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);ObjectSetInteger(0,name,OBJPROP_ZORDER,20);
   ObjectSetString(0,name,OBJPROP_TEXT,"Proyeksi: ZW "+ZWDegreeName(g_projectionDegree)+" >");
   ObjectSetString(0,name,OBJPROP_TOOLTIP,"Klik: ZW Large -> ZW Child -> ZW Micro. Mengganti sumber Fibonacci dan skenario arah; pilihan disimpan pada chart ini.");
}
void ZWCycleProjection()
{
   if(!g_owner||!InpProjectionButton)return;
   g_projectionDegree=(g_projectionDegree+1)%3;g_targetOptions.degree=g_projectionDegree;
   GlobalVariableSet(g_projectionKey,g_projectionDegree);g_dirty=true;
   ZWProjectionButton();if(g_ready)ZWPaint();else ChartRedraw();
}
int ZWVisible()
{
   if(ArraySize(g_zw.streams)==0)return 0;int n=ArraySize(g_zw.streams[0].pivots);
   return n>InpVisibleLargePivots?g_zw.streams[0].pivots[n-InpVisibleLargePivots].b:0;
}
void ZWLabel(const ZWPivot &p,const int degree,const string caption,const string tip)
{
   string key=(string)degree+"_"+(string)p.t+"_"+DoubleToString(p.p,16)+"_"+(string)p.hi;
   string label=ZWNotation(caption,(int)InpBaseDegree+degree,InpDegreeNotation);
   g_draw.Text(p.t,p.p,label,ZWInk(degree),InpLabelSize,p.hi?1:-1,tip,key);
}
double ZWATR()
{
   int n=ArraySize(g_zw.rates);double sum=0;int count=0;
   for(int i=(int)MathMax(1,n-14);i<n;i++){sum+=MathMax(g_zw.rates[i].high-g_zw.rates[i].low,MathMax(MathAbs(g_zw.rates[i].high-g_zw.rates[i-1].close),MathAbs(g_zw.rates[i].low-g_zw.rates[i-1].close)));count++;}
   return MathMax(g_zw.mintick*10,count>0?sum/count:MathAbs(g_livePrice)*.001);
}
bool ZWShowPattern(const int i)
{
   if(g_patterns[i].degree==2&&!InpMicroStructures)return false;
   if(!g_proofs[i].designatedVerified||(g_patterns[i].resolvedWave>0&&!g_proofs[i].subdivisionVerified))return false;
   if(InpCompleteHierarchyOnly&&g_proofs[i].status!="valid")return false;
   if(InpSubdivisionOnly&&!g_proofs[i].subdivisionVerified)return false;
   return g_patterns[i].count>1&&g_patterns[i].points[0].b>=ZWVisible();
}
string ZWFamilyCaption(string family)
{
   StringReplace(family,"Impulse Truncated Fifth","Impulse · fifth terpotong");
   StringReplace(family,"Impulse Extension","Impulse · ekstensi");
   StringReplace(family,"Contracting","kontraksi");StringReplace(family,"Expanding","ekspansi");
   StringReplace(family,"Running","berjalan");StringReplace(family,"Regular","reguler");
   return family;
}
void ZWDrawPattern(const int index)
{
   ZWPattern p=g_patterns[index];ZWProof proof=g_proofs[index];color ink=ZWInk(p.degree);
   if(StringLen(proof.resolvedFamily)>0)p.family=proof.resolvedFamily;
   bool impulse=StringFind(p.family,"Impulse")==0,triangle=StringFind(p.family,"Triangle")==0;
   bool combo=StringFind(p.family,"Double")==0||StringFind(p.family,"Triple")==0;
   string kind=proof.subdivisionVerified?"S":"G";
   string tip=ZWFamilyCaption(p.family)+" | "+ZWDegreeName(p.degree)+" | "+kind+"\nHierarki: "+proof.status+"\n"+proof.reason+"\nG = geometri; S = subdivisi terbukti; H = hierarki penuh valid.\nHarga dan waktu titik adalah koordinat candle asli.";
   for(int j=1;j<p.count;j++)
   {
      if(!impulse||InpImpulseLines)g_draw.Line(p.points[j-1].t,p.points[j-1].p,p.points[j].t,p.points[j].p,ink,proof.subdivisionVerified?STYLE_SOLID:STYLE_DASH);
      string name=impulse||StringFind(p.family,"Diagonal")>=0?(string)j:triangle?StringSubstr("ABCDE",j-1,1):combo?(j==4?"X2":StringSubstr("WXYXZ",j-1,1)):StringSubstr("ABC",j-1,1);
      ZWLabel(p.points[j],p.degree,name,tip);
   }
   if(triangle||StringFind(p.family,"Diagonal")>=0)
   {
      int seconds=PeriodSeconds(_Period);datetime right=p.points[p.count-1].t+(datetime)(seconds*InpBoundaryForward);
      for(int k=1;k<=2;k++)
      {
         int e=k+2;double dt=(double)(p.points[e].t-p.points[k].t);
         if(dt>0){double price=p.points[e].p+(p.points[e].p-p.points[k].p)*(double)(right-p.points[e].t)/dt;g_draw.Line(p.points[k].t,p.points[k].p,right,price,ink,STYLE_DASH);}
      }
   }
   if(InpPatternTitles)
   {
      ZWPivot end=p.points[p.count-1];string caption=ZWFamilyCaption(p.family)+" · "+kind+(proof.status=="valid"?"/H":"")+" · "+ZWDegreeName(p.degree);
      g_draw.Text(end.t,end.p,caption,ink,InpLabelSize,end.hi?1:-1,tip);
   }
}
void ZWPaint()
{
   if(!g_owner||!g_ready)return;
   g_draw.Begin();g_draw.atr=ZWATR();ZWProjectionButton();
   if(InpProjectionButton)
   {
      string button=g_draw.prefix+"projection";int width=(int)ObjectGetInteger(0,button,OBJPROP_XSIZE),height=(int)ObjectGetInteger(0,button,OBJPROP_YSIZE);
      int x=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS)-(int)ObjectGetInteger(0,button,OBJPROP_XDISTANCE)+width/2;
      int y=(int)ObjectGetInteger(0,button,OBJPROP_YDISTANCE)+height/2;g_draw.ReserveBox(x,y,width+8,height+8);
   }
   int visible=ZWVisible(),n=ArraySize(g_zw.rates);if(n==0)return;
   int seconds=PeriodSeconds(_Period);if(seconds<1)seconds=60;
   if(!InpCompleteHierarchyOnly&&!InpSubdivisionOnly)g_targets.Draw(g_zw,g_draw,g_targetOptions,g_livePrice,g_formingTime,seconds);
   for(int d=0;d<2&&d<ArraySize(g_zw.streams);d++)if(d==0?InpLargeZigZag:InpChildZigZag)
      for(int i=1;i<ArraySize(g_zw.streams[d].pivots);i++)if(g_zw.streams[d].pivots[i-1].b>=visible)
         g_draw.Line(g_zw.streams[d].pivots[i-1].t,g_zw.streams[d].pivots[i-1].p,g_zw.streams[d].pivots[i].t,g_zw.streams[d].pivots[i].p,ZWInk(d));
   if(InpDivergence&&!InpCompleteHierarchyOnly&&!InpSubdivisionOnly)for(int i=0;i<ArraySize(g_zw.links);i++)
   {
      ZWDivLink link=g_zw.links[i];if(link.anchor.b<visible||(link.hidden?!InpHiddenDivergence:!InpRegularDivergence))continue;
      color ink=link.endpoint.hi?C'255,152,0':C'0,191,255';
      g_draw.Line(link.anchor.t,link.anchor.p,link.endpoint.t,link.endpoint.p,ink,STYLE_DOT);
      g_draw.Text(link.endpoint.t,link.endpoint.p,(link.hidden?"H":"")+(link.endpoint.hi?"Bear":"Bull")+" · "+ZWDegreeName(link.degree),ink,8,link.endpoint.hi?1:-1,"Divergence MACD; tidak mengubah bukti Elliott.");
   }
   if(!InpCompleteHierarchyOnly&&!InpSubdivisionOnly)for(int i=0;i<ArraySize(g_zw.counts);i++)
   {
      ZWCount c=g_zw.counts[i];if(c.pivot.b>=visible&&c.degree<3&&(c.degree!=2||InpMicroCounting))ZWLabel(c.pivot,c.degree,c.wave_name,"Counting "+ZWDegreeName(c.degree)+"\n? = berkembang; pivot memakai candle selesai.");
   }
   for(int i=0;i<ArraySize(g_patterns);i++)if(ZWShowPattern(i))
   {
      bool superseded=false;
      for(int j=0;j<ArraySize(g_patterns);j++)if(i!=j&&ZWShowPattern(j)&&g_patterns[i].degree==g_patterns[j].degree&&g_patterns[i].points[0].t==g_patterns[j].points[0].t&&g_patterns[i].points[g_patterns[i].count-1].t==g_patterns[j].points[g_patterns[j].count-1].t)
      {
         if((g_patterns[i].family=="Impulse"&&StringFind(g_patterns[j].family,"Extension")>=0)||(g_patterns[i].resolvedWave==0&&g_patterns[j].resolvedWave>0&&g_patterns[i].family==g_patterns[j].family)){superseded=true;break;}
      }
      if(!superseded)ZWDrawPattern(i);
   }
   g_draw.Flush();g_lastPaint=GetTickCount64();g_dirty=false;
}
void ZWAnalyze(const MqlRates &closed[])
{
   double tick=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);if(tick<=0)tick=_Point;
   if(!g_zw.Build(closed,g_options,tick))return;
   g_structures.Scan(g_zw,g_patterns);
   ZWPattern queued[];int quota=(int)MathMax(2,InpCandidateLimit/3),visible=ZWVisible();
   for(int degree=0;degree<3;degree++)
   {
      if(degree==2&&(!InpNestedSubwaves||!InpMicroStructures))continue;
      int used=0;
      for(int i=0;i<ArraySize(g_patterns)&&used<quota&&ArraySize(queued)<InpCandidateLimit;i++)
      {
         if(g_patterns[i].degree!=degree||g_patterns[i].points[0].b<visible)continue;
         int n=ArraySize(queued);ArrayResize(queued,n+1);queued[n]=g_patterns[i];used++;
      }
   }
   ArrayResize(g_patterns,ArraySize(queued));for(int i=0;i<ArraySize(queued);i++)g_patterns[i]=queued[i];
   int count=ArraySize(g_patterns);ArrayResize(g_proofs,count);
   int hardLimit=g_options.work_limit;
   for(int i=0;i<count;i++)
   {
      // Every candidate receives a share of the remaining proof work.
      int share=(hardLimit-g_zw.work_used)/(count-i);g_zw.opt.work_limit=(int)MathMin(hardLimit,g_zw.work_used+MathMax(0,share));
      g_proofs[i]=g_structures.Validate(g_zw,g_patterns[i]);
   }
   g_zw.opt.work_limit=hardLimit;
   for(int i=0;i<count;i++)if(ZWShowPattern(i))
   {
      ZWPattern p=g_patterns[i];
      if(p.resolvedWave>0)
      {
         string role=p.resolvedWave==4?"4":"B";
         for(int j=ArraySize(g_zw.counts)-1;j>=0;j--)if(g_zw.counts[j].degree==p.degree&&g_zw.counts[j].pivot.t==p.originalEndpoint.t)
         {
            string names[];string raw=g_zw.counts[j].wave_name;StringReplace(raw," / ","|");StringSplit(raw,'|',names);string retained="";
            for(int k=0;k<ArraySize(names);k++){string token=names[k];StringReplace(token,"?","");if(token!=role)retained+=(retained==""?"":" / ")+names[k];}
            g_zw.counts[j].wave_name=retained;
         }
      }
      if(StringFind(p.family,"Triangle")==0&&p.degree<=2&&!InpCompleteHierarchyOnly)
      {ZWPivot points[];ArrayResize(points,p.count);for(int j=0;j<p.count;j++)points[j]=p.points[j];g_zw.RecordPath(points,p.degree,false,false,p.family);}
   }
   g_ready=true;g_dirty=true;
}
bool ZWAcquire()
{
   bool exists=GlobalVariableCheck(g_lock)||GlobalVariableTemp(g_lock);
   g_owner=exists&&GlobalVariableSetOnCondition(g_lock,1,0);return g_owner;
}
int OnInit()
{
   if(!ZWValidInputs()){Print("HPX Zwave Pro: nilai input tidak valid.");return INIT_PARAMETERS_INCORRECT;}
   IndicatorSetString(INDICATOR_SHORTNAME,"HPX Zwave Pro");ZWConfigure();
   g_draw.prefix="HPXZW_"+(string)ChartID()+"_"+InpInstanceTag+"_";g_lock="HPXZW_LOCK_"+(string)ChartID()+"_"+InpInstanceTag;
   g_projectionKey="HPXZW_PRJ_"+(string)ChartID()+"_"+InpInstanceTag;
   if(!ZWAcquire())g_waitUntil=GetTickCount64()+5000;
   else {ZWLoadProjection();ZWProjectionButton();}
   EventSetMillisecondTimer(250);return INIT_SUCCEEDED;
}
void OnDeinit(const int reason)
{
   EventKillTimer();if(g_owner){g_draw.Clear();GlobalVariableSetOnCondition(g_lock,0,1);}g_owner=false;
}
int OnCalculate(const int rates_total,const int prev_calculated,const datetime &time[],const double &open[],const double &high[],const double &low[],const double &close[],const long &tick_volume[],const long &volume[],const int &spread[])
{
   if(!g_owner||rates_total<3)return rates_total;
   ArraySetAsSeries(time,false);ArraySetAsSeries(open,false);ArraySetAsSeries(high,false);ArraySetAsSeries(low,false);ArraySetAsSeries(close,false);
   g_livePrice=close[rates_total-1];g_formingTime=time[rates_total-1];
   if(!g_ready||prev_calculated==0||g_closedTime!=time[rates_total-2]||rates_total<g_lastTotal)
   {
      // Extra preceding candles seed MACD; Build keeps at most HistoryBars for analysis.
      int n=(int)MathMin(InpHistoryBars+(InpDivergence?300:0),rates_total-1),first=rates_total-1-n;MqlRates closed[];ArrayResize(closed,n);
      for(int i=0;i<n;i++){int j=first+i;closed[i].time=time[j];closed[i].open=open[j];closed[i].high=high[j];closed[i].low=low[j];closed[i].close=close[j];closed[i].tick_volume=0;closed[i].real_volume=0;closed[i].spread=0;}
      ZWAnalyze(closed);if(g_ready)g_closedTime=time[rates_total-2];g_lastTotal=rates_total;
   }
   g_dirty=true;if(GetTickCount64()-g_lastPaint>=200)ZWPaint();return rates_total;
}
void OnTimer()
{
   if(!g_owner&&g_waitUntil>0)
   {
      if(ZWAcquire()){g_waitUntil=0;ZWLoadProjection();ZWProjectionButton();ChartSetSymbolPeriod(0,_Symbol,_Period);}
      else if(GetTickCount64()>g_waitUntil){g_waitUntil=0;Print("HPX Zwave Pro: ID instance sudah dipakai. Gunakan ID lain.");}
   }
   if(g_dirty&&GetTickCount64()-g_lastPaint>=200)ZWPaint();
}
void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam)
{
   if(id==CHARTEVENT_OBJECT_CLICK&&sparam==g_draw.prefix+"projection"){ZWCycleProjection();return;}
   if(id==CHARTEVENT_CHART_CHANGE){ZWProjectionButton();g_dirty=true;if(GetTickCount64()-g_lastPaint>=200)ZWPaint();}
}
