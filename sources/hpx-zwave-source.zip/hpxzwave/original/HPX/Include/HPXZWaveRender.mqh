// HPX Zwave Pro for MT5. MPL-2.0. XoRonX | Mr Poleks.
#ifndef HPX_ZWAVE_RENDER_MQH
#define HPX_ZWAVE_RENDER_MQH
#include "HPXZWaveCore.mqh"

struct ZWVisualLine { datetime a,b; double p,q; color ink; ENUM_LINE_STYLE style; bool zone; };
struct ZWVisualText { datetime t; double p; string text,tip,key; color ink; int size,side; bool fixed; };
struct ZWTextBox { int x,y,w,h; };

// A scene reuses its native objects. A tick never deletes and recreates the chart.
class CZWRender
{
public:
   string prefix;
   ZWVisualLine lines[];
   ZWVisualText texts[];
   ZWTextBox boxes[];
   ZWTextBox obstacles[];
   int previousLines,previousTexts;
   bool separate;
   double gap,row,atr;
   CZWRender(){previousLines=0;previousTexts=0;separate=true;gap=.15;row=.35;atr=1;}
   void Begin(){ArrayResize(lines,0);ArrayResize(texts,0);ArrayResize(boxes,0);ArrayResize(obstacles,0);}
   void ReserveBox(const int x,const int y,const int width,const int height)
   {int n=ArraySize(obstacles);ArrayResize(obstacles,n+1);obstacles[n].x=x;obstacles[n].y=y;obstacles[n].w=width;obstacles[n].h=height;}
   color Blend(const color ink,const double opacity)
   {
      int a=(int)ink,b=(int)ChartGetInteger(0,CHART_COLOR_BACKGROUND);
      return (color)((int)MathRound((a&255)*opacity+(b&255)*(1-opacity)) |
         ((int)MathRound(((a>>8)&255)*opacity+((b>>8)&255)*(1-opacity))<<8) |
         ((int)MathRound(((a>>16)&255)*opacity+((b>>16)&255)*(1-opacity))<<16));
   }
   void Line(const datetime a,const double p,const datetime b,const double q,const color ink,const ENUM_LINE_STYLE style=STYLE_SOLID,const bool zone=false)
   {
      int n=ArraySize(lines);if(n>=500||a<=0||b<=0||!MathIsValidNumber(p)||!MathIsValidNumber(q))return;
      ArrayResize(lines,n+1);lines[n].a=a;lines[n].b=b;lines[n].p=p;lines[n].q=q;
      lines[n].ink=ink;lines[n].style=style;lines[n].zone=zone;
   }
   void Text(const datetime t,const double p,const string caption,const color ink,const int size=8,const int side=1,const string tooltip="",const string key="",const bool fixed=false)
   {
      if(caption==""||!MathIsValidNumber(p))return;
      int n=ArraySize(texts);
      if(key!="")for(int i=0;i<n;i++)if(texts[i].key==key)
      {
         // Join shared pivot letters once. Degree is part of the key.
         string raw=caption;StringReplace(raw,"?","");string old=texts[i].text;StringReplace(old,"?","");
         if(StringFind(" / "+old+" / "," / "+raw+" / ")<0)texts[i].text+=" / "+caption;
         if(StringFind(texts[i].tip,tooltip)<0)texts[i].tip+="\n"+tooltip;
         return;
      }
      if(n>=220)return;
      ArrayResize(texts,n+1);texts[n].t=t;texts[n].p=p;texts[n].text=caption;
      texts[n].ink=ink;texts[n].size=size;texts[n].side=side;texts[n].tip=tooltip;
      texts[n].key=key;texts[n].fixed=fixed;
   }
   void Style(const string name,const color ink)
   {
      ObjectSetInteger(0,name,OBJPROP_COLOR,ink);ObjectSetInteger(0,name,OBJPROP_WIDTH,1);
      ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,name,OBJPROP_SELECTED,false);
      ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);ObjectSetInteger(0,name,OBJPROP_ZORDER,0);
   }
   bool Intersects(const ZWTextBox &a,const ZWTextBox &b)
   {return a.x-a.w/2<b.x+b.w/2+3&&a.x+a.w/2>b.x-b.w/2-3&&a.y-a.h/2<b.y+b.h/2+2&&a.y+a.h/2>b.y-b.h/2-2;}
   void Flush()
   {
      int n=ArraySize(lines);
      for(int i=0;i<n;i++)
      {
         string name=prefix+"L"+(string)i;
         ENUM_OBJECT kind=lines[i].zone?OBJ_RECTANGLE:OBJ_TREND;
         if(ObjectFind(0,name)>=0&&(ENUM_OBJECT)ObjectGetInteger(0,name,OBJPROP_TYPE)!=kind)ObjectDelete(0,name);
         if(ObjectFind(0,name)<0)ObjectCreate(0,name,kind,0,lines[i].a,lines[i].p,lines[i].b,lines[i].q);
         ObjectMove(0,name,0,lines[i].a,lines[i].p);ObjectMove(0,name,1,lines[i].b,lines[i].q);
         Style(name,lines[i].ink);ObjectSetInteger(0,name,OBJPROP_STYLE,lines[i].style);
         if(lines[i].zone){ObjectSetInteger(0,name,OBJPROP_FILL,true);ObjectSetInteger(0,name,OBJPROP_BACK,true);}
         else {ObjectSetInteger(0,name,OBJPROP_RAY_LEFT,false);ObjectSetInteger(0,name,OBJPROP_RAY_RIGHT,false);ObjectSetInteger(0,name,OBJPROP_BACK,false);}
         ObjectSetString(0,name,OBJPROP_TOOLTIP,"\n");
      }
      for(int i=n;i<previousLines;i++)ObjectDelete(0,prefix+"L"+(string)i);
      previousLines=n;n=ArraySize(texts);ArrayResize(boxes,ArraySize(obstacles));for(int i=0;i<ArraySize(obstacles);i++)boxes[i]=obstacles[i];
      // Fixed level captions reserve their space before movable pivot labels.
      for(int pass=0;pass<2;pass++)for(int i=0;i<n;i++)
      {
         ZWVisualText v=texts[i];if((pass==0)!=v.fixed)continue;
         double yprice=v.p+(v.fixed?0:v.side*atr*gap);datetime textTime=v.t;int x=0,y=0;
         ZWTextBox box;box.x=box.y=0;box.w=(int)MathCeil(StringLen(v.text)*v.size*.76)+6;box.h=(int)MathCeil(v.size*1.5)+3;
         bool mapped=ChartTimePriceToXY(0,0,v.t,yprice,x,y);
         if(mapped)
         {
            box.x=x;box.y=y;
            // Level captions keep their exact price. Shift only their text's
            // time coordinate if the fixed chart control covers the caption.
            if(separate&&v.fixed)for(int j=0;j<ArraySize(obstacles);j++)if(Intersects(box,obstacles[j]))
            {
               int candidateX=obstacles[j].x-obstacles[j].w/2-box.w/2-6;
               int pane=0;datetime moved=0;double unused=0;
               if(candidateX>=box.w/2+3&&ChartXYToTimePrice(0,candidateX,y,pane,moved,unused)&&pane==0)
               {textTime=moved;x=candidateX;box.x=x;}
            }
            int px=0,py=0;ChartTimePriceToXY(0,0,v.t,v.p+atr*row,px,py);
            int step=(int)MathMax(box.h+2,MathMin(32,MathAbs(y-py)));
            int chartHeight=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0),originY=box.y;
            bool found=!separate||v.fixed;
            if(separate&&!v.fixed)for(int pass=0;pass<2&&!found;pass++)for(int attempt=0;attempt<48;attempt++)
            {
               int candidateY=originY+(pass==0?-v.side:v.side)*step*attempt;
               if(candidateY-box.h/2<3||candidateY+box.h/2>=chartHeight-3)continue;
               box.y=candidateY;
               bool clash=false;for(int j=0;j<ArraySize(boxes);j++)if(Intersects(box,boxes[j])){clash=true;break;}
               if(!clash){found=true;break;}
            }
            int pane=0;datetime unchanged=0;double adjusted=0;
            if(!v.fixed&&ChartXYToTimePrice(0,x,box.y,pane,unchanged,adjusted)&&pane==0)yprice=adjusted;
            else if(!v.fixed)box.y=originY;
            int count=ArraySize(boxes);ArrayResize(boxes,count+1);boxes[count]=box;
         }
         string name=prefix+"T"+(string)i;
         if(ObjectFind(0,name)<0)ObjectCreate(0,name,OBJ_TEXT,0,v.t,yprice);
         ObjectMove(0,name,0,textTime,yprice);Style(name,v.ink);
         ObjectSetInteger(0,name,OBJPROP_FONTSIZE,v.size);ObjectSetInteger(0,name,OBJPROP_ANCHOR,ANCHOR_CENTER);
         ObjectSetString(0,name,OBJPROP_FONT,"Arial");ObjectSetString(0,name,OBJPROP_TEXT,v.text);
         ObjectSetString(0,name,OBJPROP_TOOLTIP,v.tip);ObjectSetInteger(0,name,OBJPROP_BACK,false);
      }
      for(int i=n;i<previousTexts;i++)ObjectDelete(0,prefix+"T"+(string)i);previousTexts=n;
      ChartRedraw();
   }
   void Clear()
   {
      if(prefix=="")return;
      for(int i=ObjectsTotal(0)-1;i>=0;i--){string name=ObjectName(0,i);if(StringFind(name,prefix)==0)ObjectDelete(0,name);}
      previousLines=previousTexts=0;
   }
};

string ZWNotationToken(const string raw,const int level)
{
   string value=raw;bool developing=StringFind(value,"?")>=0;StringReplace(value,"?","");
   string nums[5]={"①","②","③","④","⑤"};string letters[5]={"Ⓐ","Ⓑ","Ⓒ","Ⓓ","Ⓔ"};
   string roman[5]={"I","II","III","IV","V"};string small[5]={"i","ii","iii","iv","v"};
   int i=(int)StringToInteger(value)-1;bool numeric=i>=0&&i<5;string out=value;
   int letter=StringFind("ABCDE",value);bool alpha=StringLen(value)==1&&letter>=0;
   if(level==0){if(numeric)out=roman[i];out="["+out+"]";}
   else if(level==1){if(numeric)out=roman[i];out="("+out+")";}
   else if(level==2){if(numeric)out=roman[i];}
   else if(level==3){if(numeric)out=nums[i];else if(alpha)out=letters[letter];else if(value=="W")out="Ⓦ";else if(value=="X")out="Ⓧ";else if(value=="Y")out="Ⓨ";else if(value=="Z")out="Ⓩ";else if(value=="X2")out="Ⓧ₂";}
   else if(level==4){out="("+value+")";}
   else if(level==6){if(numeric)out=small[i];else StringToLower(out);out="["+out+"]";}
   else if(level==7){if(numeric)out="("+small[i]+")";else {StringToLower(out);out="("+out+")";}}
   else if(level>=8){if(numeric)out=small[i];else StringToLower(out);}
   return out+(developing?"?":"");
}
string ZWNotation(const string raw,const int level,const bool enabled)
{
   if(!enabled)return raw;
   string split=raw;StringReplace(split," / ","|");string parts[];int n=StringSplit(split,'|',parts);string out="";
   for(int i=0;i<n;i++)out+=(i>0?" / ":"")+ZWNotationToken(parts[i],level);
   return out;
}
#endif
