// MPL-2.0. ZWave by XoRonX | Mr Poleks; native HPX adaptation.
#ifndef HPX_ZWAVE_TYPES_MQH
#define HPX_ZWAVE_TYPES_MQH
struct ZWPivot {int b; datetime t; double p; bool hi; int known;};
struct ZWStream {ZWPivot pivots[]; double reversal;};
struct ZWPattern {string family; ZWPivot points[6]; int count; int degree; double score; int resolvedWave; ZWPivot originalEndpoint;};
struct ZWProof {bool subdivisionVerified; bool observedValid; string status; string reason; int nodes; int maxDepthReached; bool designatedVerified; string resolvedFamily;};
struct ZWCount {ZWPivot pivot; int degree; string wave_name;};
struct ZWPath {ZWPivot points[6]; int count; int degree; bool motive; bool developing; string family;};
struct ZWDivLink {ZWPivot anchor; ZWPivot endpoint; int degree; bool hidden;};
struct ZWOptions
  {
   double deviation,factor;
   int depth,child_depth,history,max_depth,max_nodes,work_limit,candidate_limit,recent_patterns;
   bool subwaves,hierarchy,divergence,triangles,abc,impulses,diagonals,combinations,truncation,extensions;
   bool show_developing,show_micro,show_hidden,hidden_extremes,hidden_same_side;
   bool capture_micro_paths; // Internal projection anchors; does not enable Micro label display.
   int hidden_min_bars,hidden_max_bars;
  };
void ZWDefaults(ZWOptions &o)
  {
   ZeroMemory(o);
   o.deviation=9.0; o.factor=3.0; o.depth=10; o.child_depth=4; o.history=10000;
   o.max_depth=12; o.max_nodes=2000; o.work_limit=80000; o.candidate_limit=24; o.recent_patterns=2;
   o.subwaves=true; o.hierarchy=true; o.divergence=false;
   o.triangles=true; o.abc=true; o.impulses=true; o.diagonals=true;
   o.combinations=true; o.truncation=true; o.extensions=true;
   o.show_developing=true; o.show_micro=false; o.show_hidden=true; o.hidden_extremes=true;o.capture_micro_paths=false;
   o.hidden_same_side=false; o.hidden_min_bars=5; o.hidden_max_bars=500;
  }
#endif
