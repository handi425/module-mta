import converted.zwavecore.*;
import net.metaquotes.metatrader5.modules.api.*;
import java.util.*;
import java.lang.reflect.*;
/** Analytical fixtures for the supplied Zwave Core Pine algorithm. */
public final class ZwaveCoreEngineTest {
    private static int checks;
    private static void check(boolean yes,String why){
        checks++;
        if(!yes)throw new AssertionError(why);
    }
    private static void near(double expected,double actual,String why){
        check(Double.isFinite(actual)&&Math.abs(expected-actual)<1e-9,why+" expected="+expected+" actual="+actual);
    }
    private static Map<String,String> input(String... pairs){
        Map<String,String> m=new HashMap<String,String>();
        for(int i=0;i<pairs.length;i+=2)m.put(pairs[i],pairs[i+1]);
        return ZwaveCoreInputs.normalize(m);
    }
    private static long time(int index){
        return 1700000000L+index*60L;
    }
    private static ChartData.Bar bar(int index,double p){
        return new ChartData.Bar(time(index),p,p,p,p);
    }
    private static ChartData chart(List<ChartData.Bar> bars){
        return new ChartData(8,"fixture","TEST",1,bars,null,2,60,0,Collections.<Integer,List<ChartData.Bar>>emptyMap(),.01,"","",0xff000000);
    }
    private static List<ChartData.Bar> wave(int[] indices,double[] prices,int finalIndex,double finalPrice){
        List<ChartData.Bar> out=new ArrayList<ChartData.Bar>();
        for(int i=0;i<indices[0];i++)out.add(bar(i,prices[0]+5*(indices[0]-i)));
        for(int s=0;s<indices.length-1;s++)for(int i=indices[s];i<indices[s+1];i++)out.add(bar(i,prices[s]+(prices[s+1]-prices[s])*(i-indices[s])/(indices[s+1]-indices[s])));
        int last=indices[indices.length-1];
        for(int i=last;i<=finalIndex;i++)out.add(bar(i,prices[prices.length-1]+(finalPrice-prices[prices.length-1])*(i-last)/Math.max(1,finalIndex-last)));
        return out;
    }
    private static List<ChartData.Bar> impulse(){
        return wave(new int[]{
            2,8,14,20,26,32
        },
        new double[]{
            100,120,110,145,130,160
        },
        34,155);
    }
    private static String pivots(List<ZwaveCoreEngine.Pivot> stream){
        StringBuilder s=new StringBuilder();
        for(ZwaveCoreEngine.Pivot p:stream)s.append(p.b).append(':').append(p.p).append(':').append(p.hi).append(':').append(p.known).append(';');
        return s.toString();
    }
    private static String counts(List<ZwaveCoreEngine.Count> out){
        StringBuilder s=new StringBuilder();
        for(ZwaveCoreEngine.Count c:out)s.append(c.pivot.b).append(':').append(c.degree).append(':').append(c.waveName).append(';');
        return s.toString();
    }
    private static boolean has(ZwaveCoreEngine.Result r,int index,int degree,String name){
        for(ZwaveCoreEngine.Count c:r.counts)if(c.pivot.b==index&&c.degree==degree&&c.waveName.equals(name))return true;
        return false;
    }
    public static void main(String[] args)throws Exception{
        emptyAndIndicators();
        pivotTiesAndReversal();
        geometryRules();
        impulseProofAndPersistence();
        extensionOwnership();
        hiddenChainsAndRollback();
        fibonacciAndBudgets();
        committedHistoryGuard();
        System.out.println("ZwaveCoreEngineTest PASS: "+checks+" analytical assertions");
    }
    private static void committedHistoryGuard()throws Exception {
        Method guard=ZwaveCore.class.getDeclaredMethod("continuation",ChartData.class,ChartData.class);guard.setAccessible(true);
        List<ChartData.Bar> initial=Arrays.asList(bar(0,100),bar(1,101));ChartData before=chart(initial);
        check((Boolean)guard.invoke(null,before,chart(initial)),"equal committed history preserves fixed shadow anchor");
        check((Boolean)guard.invoke(null,before,chart(Arrays.asList(bar(0,100),bar(1,101),bar(2,102)))),"real closed-bar append preserves anchor");
        check(!(Boolean)guard.invoke(null,before,chart(Arrays.asList(bar(0,99),bar(1,101)))),"old OHLC correction invalidates fixed anchor and ATR seed");
        check(!(Boolean)guard.invoke(null,before,chart(Arrays.asList(bar(0,100),new ChartData.Bar(time(1),101,101,101,101,1,0)))),"old volume correction invalidates cached lineage");
        check(!(Boolean)guard.invoke(null,before,chart(Collections.singletonList(bar(0,100)))),"truncated history resets shadow state");
        check(!(Boolean)guard.invoke(null,before,chart(Arrays.asList(new ChartData.Bar(time(0)-60,100,100,100,100),bar(0,100),bar(1,101)))),"prepended broker history rebuilds seeded analysis");
        check(!(Boolean)guard.invoke(null,before,new ChartData(8,"fixture","OTHER",1,initial)),"comparison symbol switch resets anchor");
        check(!(Boolean)guard.invoke(null,before,new ChartData(8,"other","TEST",1,initial)),"broker server switch resets anchor");
        check(!(Boolean)guard.invoke(null,before,null),"missing reference cannot validate stale committed state");
        check(!(Boolean)guard.invoke(null,null,null),"two missing feeds are not a committed lineage");
        check(new ZwaveCore().historyBars(input())==100000,"read all available EMA seed history without shrinking to analysis window");
    }
    private static void emptyAndIndicators(){
        Map<String,String> v=input();
        ZwaveCoreEngine.Result e=ZwaveCoreEngine.analyze(chart(Collections.<ChartData.Bar>emptyList()),v,null);
        check(e.major.isEmpty()&&e.frame.drawings.isEmpty(),"empty history stays passive");
        List<ChartData.Bar> flat=new ArrayList<ChartData.Bar>();
        for(int i=0;i<30;i++)flat.add(new ChartData.Bar(time(i),100,101,99,100));
        ZwaveCoreEngine.Result f=ZwaveCoreEngine.analyze(chart(flat),v,null);
        check(f.major.isEmpty()&&f.minor.isEmpty()&&f.micro.isEmpty()&&f.counts.isEmpty(),"equal highs and lows do not fabricate pivots/waves");
        near(0,f.macd[29],"flat EMA difference");
        near(0,f.signal[29],"flat MACD signal");
        check(Double.isNaN(f.atr[12]),"ATR14 has no partial warmup");
        near(2,f.atr[13],"ATR14 true-range seed");
        List<ChartData.Bar> ramp=Arrays.asList(bar(0,100),bar(1,101),bar(2,102));
        ZwaveCoreEngine.Result r=ZwaveCoreEngine.analyze(chart(ramp),v,null);
        near(.07977207977208467,r.macd[1],"EMA12/26 seeded by first close");
        near(.22113456871291248,r.macd[2],"MACD ramp recurrence");
        near(.015954415954416936,r.signal[1],"EMA9 signal recurrence");
        near(.06381766381766773,r.histogram[1],"MACD histogram");
    }
    private static void pivotTiesAndReversal(){
        Map<String,String> v=input("depth","2","childDepth","2","deviation","10");
        double[] high={
            11,12,15,15,13,12,11
        };
        List<ChartData.Bar> bars=new ArrayList<ChartData.Bar>();
        for(int i=0;i<high.length;i++)bars.add(new ChartData.Bar(time(i),10,high[i],10,10));
        ZwaveCoreEngine.Result tie=ZwaveCoreEngine.analyze(chart(bars),v,null);
        check(tie.major.size()==1&&tie.major.get(0).b==2&&tie.major.get(0).known==4,"older highs strictly lower; newer equal highs may tie; depth2 still uses radius2");
        bars=new ArrayList<ChartData.Bar>();
        for(int i=0;i<5;i++)bars.add(new ChartData.Bar(time(i),10,i==2?15:12,i==2?5:9,10));
        ZwaveCoreEngine.Result dual=ZwaveCoreEngine.analyze(chart(bars),v,null);
        check(dual.major.size()==2&&dual.major.get(0).hi&&!dual.major.get(1).hi&&dual.major.get(0).b==dual.major.get(1).b,"high registers before low on the same outside candle, retaining original ordering");
        List<ChartData.Bar> replacement=wave(new int[]{
            2,8,14
        },
        new double[]{
            100,120,110
        },
        16,115);
        ZwaveCoreEngine.Result r=ZwaveCoreEngine.analyze(chart(replacement),input("deviation","10","depth","4","childDepth","4"),null);
        check(r.major.size()==2&&r.major.get(1).b==8,"subthreshold reversal does not append an opposite pivot");
        List<ChartData.Bar> threshold=wave(new int[]{
            2,8,14
        },
        new double[]{
            100,120,108
        },
        16,112);
        r=ZwaveCoreEngine.analyze(chart(threshold),input("deviation","10","depth","4","childDepth","4"),null);
        check(r.major.size()==3&&r.major.get(2).b==14,"exact10percent decline meets reversal threshold");
    }
    private static boolean geometry(double[] prices,int kind)throws Exception{
        Method m=ZwaveCoreEngine.class.getDeclaredMethod("geometry",double[].class,int.class,int.class,int.class,double.class);
        m.setAccessible(true);
        return (Boolean)m.invoke(null,prices,prices.length-1,kind,1,.001);
    }
    private static void geometryRules()throws Exception{
        check(geometry(new double[]{
            100,120,110,145,130,160
        },
        1),"valid five has nonoverlapping fourth and nonshortest third");
        check(!geometry(new double[]{
            100,130,120,140,135,170
        },
        1),"third cannot be shortest motive leg");
        check(!geometry(new double[]{
            100,120,99,145,130,160
        },
        1),"second cannot cross impulse origin");
        check(!geometry(new double[]{
            100,120,110,145,119,160
        },
        1),"fourth cannot overlap first-wave territory");
        check(!geometry(new double[]{
            100,120,110,145,130,144
        },
        1),"fifth must exceed third extreme");
        check(geometry(new double[]{
            100,120,110,130
        },
        4),"zigzag correction");
        check(geometry(new double[]{
            100,120,100,130
        },
        5),"regular flat correction");
        check(geometry(new double[]{
            100,120,90,130
        },
        6),"expanded flat correction");
        check(geometry(new double[]{
            100,120,90,110
        },
        7),"running flat correction");
        check(!geometry(new double[]{
            100,120,90,99
        },
        7),"running flat still finishes beyond its origin");
    }
    private static void impulseProofAndPersistence(){
        Map<String,String> v=input("deviation","30","factor","20","depth","4","childDepth","4","showLargeFib","false","showChildFib","false");
        List<ChartData.Bar> bars=impulse();
        ZwaveCoreEngine.Result r=ZwaveCoreEngine.analyze(chart(bars),v,null);
        check(r.major.size()==2&&r.major.get(0).b==2&&r.major.get(1).b==32,"large swing contains the real six-point child impulse");
        check(r.minor.size()==6,"child stream preserves all real impulse pivots");
        int[] indices={
            8,14,20,26,32
        };
        for(int i=0;i<indices.length;i++)check(has(r,indices[i],1,Integer.toString(i+1)),"finer proof emits wave"+(i+1)+" at its actual extreme");
        ZwaveCoreEngine.Options oscillator=ZwaveCoreEngine.Options.primary(v);
        oscillator.macdOverride=new double[bars.size()];
        oscillator.macdOverride[20]=10;
        oscillator.macdOverride[32]=5;
        ZwaveCoreEngine.Result divergence=ZwaveCoreEngine.analyze(chart(bars),v,null,oscillator);
        check(divergence.links.size()==1&&divergence.links.get(0).three.b==20&&divergence.links.get(0).five.b==32,"proved impulse compares raw incoming MACD extremes for real3-to5 divergence");
        check(counts(divergence.counts).equals(counts(r.counts)),"MACD divergence never changes Elliott geometry/counts");
        List<ChartData.Bar> overlap=new ArrayList<ChartData.Bar>(bars);
        for(int j=21;j<=32;j++){
            double p=j<=26?145+(119-145)*(j-20)/6.0:119+(160-119)*(j-26)/6.0;
            overlap.set(j,bar(j,p));
        }
        ZwaveCoreEngine.Result invalid=ZwaveCoreEngine.analyze(chart(overlap),v,null);
        check(!has(invalid,32,1,"5"),"unproved fourth-wave overlap cannot be converted into a five by successive pivot numbering");
        check(r.state.confirmedCounts.size()==4,"unsettled fifth stays out of persistent confirmed counts");
        for(ZwaveCoreEngine.Count c:r.state.confirmedCounts)check(!c.waveName.contains("?")&&c.pivot.b<32,"only proved and subsequently settled labels persist");
        ChartData live=new ChartData(8,"fixture","TEST",1,bars,new ChartData.Bar(time(35),155,200,150,180),2,60,0,Collections.<Integer,List<ChartData.Bar>>emptyMap(),.01,"","",0xff000000);
        ZwaveCoreEngine.Result unchanged=ZwaveCoreEngine.analyze(live,v,r.state);
        check(unchanged==r,"primary open ticks keep the last closed frame without recounting");
        List<ChartData.Bar> append=new ArrayList<ChartData.Bar>(bars);
        append.add(bar(35,154));
        ZwaveCoreEngine.Result next=ZwaveCoreEngine.analyze(chart(append),v,r.state);
        for(int i=0;i<4;i++)check(has(next,indices[i],1,Integer.toString(i+1)),"settled confirmed labels survive refresh");
        List<ChartData.Bar> revised=new ArrayList<ChartData.Bar>(append);
        revised.set(2,bar(2,102));
        ZwaveCoreEngine.Result fresh=ZwaveCoreEngine.analyze(chart(revised),v,null),reset=ZwaveCoreEngine.analyze(chart(revised),v,next.state);
        check(counts(fresh.counts).equals(counts(reset.counts))&&pivots(fresh.minor).equals(pivots(reset.minor)),"historical revision discards incompatible persisted state");
        List<ChartData.Bar> catchup=new ArrayList<ChartData.Bar>(bars);
        for(int j=35;j<65;j++)catchup.add(bar(j,145+10*Math.sin(j*.3)));
        ZwaveCoreEngine.Result stepped=r;
        for(int j=bars.size()+1;j<=catchup.size();j++)stepped=ZwaveCoreEngine.analyze(chart(catchup.subList(0,j)),v,stepped.state);
        ZwaveCoreEngine.Result batched=ZwaveCoreEngine.analyze(chart(catchup),v,r.state);
        check(counts(stepped.counts).equals(counts(batched.counts))&&counts(stepped.state.confirmedCounts).equals(counts(batched.state.confirmedCounts)),"coalesced multiple closed bars replay every count commit in chronological order");
        check(counts(r.counts).equals("8:1:1;14:1:2;20:1:3;26:1:4;32:1:5;"),"analytical fixture has only the actual five, with no index/modulo renumbering");
    }
    private static void extensionOwnership(){
        Map<String,String> v=input("deviation","30","factor","20","depth","4","childDepth","4");
        List<ChartData.Bar> bars=impulse();
        ZwaveCoreEngine.Result proved=ZwaveCoreEngine.analyze(chart(bars),v,null);
        int[] indices={34,38,44,50,56,58};
        double[] prices={155,140,200,180,260,250};
        List<ChartData.Bar> extension=new ArrayList<ChartData.Bar>(bars);
        for(int at=35;at<=58;at++){
            int leg=0;while(at>indices[leg+1])leg++;
            double price=prices[leg]+(prices[leg+1]-prices[leg])*(at-indices[leg])/(indices[leg+1]-indices[leg]);
            extension.add(bar(at,price));
        }
        ZwaveCoreEngine.Result longer=ZwaveCoreEngine.analyze(chart(extension),v,proved.state);
        check(has(longer,8,1,"1")&&has(longer,14,1,"2")&&has(longer,44,1,"3"),"same real origin/1/2 permits proved extended third relocation");
        check(!has(longer,20,1,"3")&&!has(longer,26,1,"4")&&!has(longer,32,1,"5"),"extended-third span suppresses former internal3/4/5 without moving outer1/2");
        check(has(longer,50,1,"4")&&has(longer,56,1,"5"),"new outer fourth/fifth remain outside proved extension span");
        List<ChartData.Bar> noProof=new ArrayList<ChartData.Bar>(bars);
        for(int at=35;at<=56;at++)noProof.add(bar(at,155+(260-155)*(at-34)/22.0));
        noProof.add(bar(57,255));noProof.add(bar(58,250));
        ZwaveCoreEngine.Result unproved=ZwaveCoreEngine.analyze(chart(noProof),v,proved.state);
        check(has(unproved,20,1,"3")&&!has(unproved,56,1,"3"),"a distant price extreme without a finer five cannot seize third-wave ownership");
        check(has(proved,20,1,"3")&&has(proved,32,1,"5"),"later extension analysis cannot mutate previously published counts");
    }
    private static void hiddenChainsAndRollback(){
        Map<String,String> v=input("depth","4","childDepth","4","hiddenMinBars","5","hiddenMaxBars","500");
        List<ChartData.Bar> bars=wave(new int[]{
            2,8,14,20,26,32,38
        },
        new double[]{
            100,130,110,140,120,150,130
        },
        40,135);
        double[] osc=new double[bars.size()];
        osc[8]=1;
        osc[14]=-1;
        osc[20]=2;
        osc[24]=osc[26]=-2;
        osc[32]=3;
        osc[36]=osc[38]=-3;
        ZwaveCoreEngine.Options o=ZwaveCoreEngine.Options.primary(v);
        o.macdOverride=osc;
        ZwaveCoreEngine.Result r=ZwaveCoreEngine.analyze(chart(bars),v,null,o);
        int bullish=0;
        for(ZwaveCoreEngine.HiddenDivLink link:r.hidden)if(!link.endpoint.hi){
            bullish++;
            check(link.anchor.b==14&&link.endpoint.b==38,"hidden chain extends original price anchor across higher lows");
            check(link.anchorOscBar==14&&link.endpointOscBar==38,"incoming oscillator extrema choose rightmost equal bar");
            near(-1,link.anchorMacd,"extended chain retains original MACD anchor");
        }
        double[] revisedOsc=osc.clone();
        revisedOsc[14]=-.5;
        ZwaveCoreEngine.Options revisedOptions=ZwaveCoreEngine.Options.primary(v);
        revisedOptions.macdOverride=revisedOsc;
        ZwaveCoreEngine.Result revised=ZwaveCoreEngine.analyze(chart(bars),v,r.state,revisedOptions);
        boolean revisedAnchor=false;
        for(ZwaveCoreEngine.HiddenDivLink link:revised.hidden)if(link.anchor.b==14&&link.anchorMacd==-.5)revisedAnchor=true;
        check(revised.state!=r.state&&revisedAnchor,"historical full-reference MACD revision invalidates aligned-state reuse");
        check(bullish==3,"large/child/micro detect independently on the raw oscillator");
        check(ZwaveCoreEngine.hiddenMatch(false,100,110,-1,-2,true),"bullish hidden divergence has higher price low and lower negative MACD");
        check(!ZwaveCoreEngine.hiddenMatch(false,100,110,1,-2,true),"zero filter requires both low MACDs below zero");
        check(!ZwaveCoreEngine.hiddenMatch(true,120,120,1,2,false),"equal price is not hidden divergence");
        Map<String,String> capped=input("depth","4","childDepth","4","hiddenMinBars","5","hiddenMaxBars","22");
        o=ZwaveCoreEngine.Options.primary(capped);
        o.macdOverride=osc;
        ZwaveCoreEngine.Result split=ZwaveCoreEngine.analyze(chart(bars),capped,null,o);
        int child=0;
        for(ZwaveCoreEngine.HiddenDivLink link:split.hidden)if(link.degree==1&&!link.endpoint.hi){
            child++;
            check(link.endpoint.b-link.anchor.b==12,"max distance measured from original anchor causes separate chains");
        }
        check(child==2,"chain expiration starts a new original anchor");
        List<ChartData.Bar> impulse=impulse();
        ChartData open=new ChartData(8,"fixture","TEST",1,impulse.subList(0,34),impulse.get(34),2,60,0,Collections.<Integer,List<ChartData.Bar>>emptyMap(),.01,"","",0xff000000);
        ZwaveCoreEngine.Options shadow=ZwaveCoreEngine.Options.shadow(v);
        ZwaveCoreEngine.Result live=ZwaveCoreEngine.analyze(open,v,null,shadow);
        String committed=counts(live.state.confirmedCounts);
        ChartData changed=new ChartData(8,"fixture","TEST",1,impulse.subList(0,34),new ChartData.Bar(time(34),155,161,150,156),2,60,0,Collections.<Integer,List<ChartData.Bar>>emptyMap(),.01,"","",0xff000000);
        ZwaveCoreEngine.Result rollback=ZwaveCoreEngine.analyze(changed,v,live.state,shadow);
        check(live.provisional&&rollback.provisional&&live.state==rollback.state,"forming shadow tick returns the same immutable closed state");
        check(committed.equals(counts(rollback.state.confirmedCounts)),"provisional counts never leak into committed state");
        check(!pivots(live.minor).equals(pivots(rollback.minor)),"revised forming high can revoke provisional pivot confirmation");
    }
    private static void fibonacciAndBudgets(){
        List<ChartData.Bar> bars=impulse();
        Map<String,String> v=input("deviation","30","factor","20","depth","4","childDepth","4","showChildFib","false","showHidden","false","fibRightExtension","7","fibTextShift","2");
        ZwaveCoreEngine.Result r=ZwaveCoreEngine.analyze(chart(bars),v,null);
        int lines=0,fibLabels=0;
        for(PlotFrame.Drawing drawing:r.frame.drawings){
            if(drawing.type==2){
                lines++;
                check(drawing.times[0]==time(2)&&drawing.times[1]==time(41),"finite Fibonacci endpoint uses last real candle plus7 bars");
            }
            if(drawing.text!=null&&drawing.text.endsWith("%")){
                fibLabels++;
                check(drawing.times[0]==time(43)&&drawing.anchor==4,"right Fibonacci text begins after fixed endpoint");
            }
        }
        Map<String,String> coincidentInput=new HashMap<String,String>(v);
        coincidentInput.put("showChildFib","true");
        ZwaveCoreEngine.Result coincident=ZwaveCoreEngine.analyze(chart(bars),coincidentInput,null);
        boolean merged=false;
        for(PlotFrame.Drawing drawing:coincident.frame.drawings)if("50.0% | 100.0%".equals(drawing.text)&&Math.abs(drawing.values[0]-130)<1e-9)merged=true;
        check(merged,"coincident large/child retracement ratios combine at the exact price instead of drifting");
        check(lines==9&&fibLabels==9,"exact nine original retracement ratios");
        PlotFrame.Drawing zero=null,one=null;
        for(PlotFrame.Drawing d:r.frame.drawings)if("0.0%".equals(d.text))zero=d;
        else if("100.0%".equals(d.text))one=d;
        near(160,zero.values[0],"zero retracement anchored at latest swing");
        near(100,one.values[0],"100percent retracement anchored at prior swing");
        List<ChartData.Bar> dense=new ArrayList<ChartData.Bar>();
        double p=100;
        for(int i=0;i<5000;i++){
            p=200+80*Math.sin(i*.003)+5*Math.sin(i*.5);
            dense.add(new ChartData.Bar(time(i),p,p,p,p));
        }
        ZwaveCoreEngine.Result limited=ZwaveCoreEngine.analyze(chart(dense),input("deviation","20","factor","20","depth","4","childDepth","4","workLimit","10000","showZigzag","true","showMicro","true","childFibLegs","5"),null);
        check(limited.work>=10000&&limited.work<=10001&&limited.status.contains("Search limit reached"),"candidate budget terminates dense unresolved searches explicitly");
        int lineCount=0,labelCount=0;
        for(PlotFrame.Drawing d:limited.frame.drawings)if(d.type==2)lineCount++;
        else if(d.type==101)labelCount++;
        ZwaveCoreEngine.Result window=ZwaveCoreEngine.analyze(chart(dense),input("historyBars","300"),null);
        check(window.base==4700,"configured history window retains exactly300 closed candles after admission");
        for(ZwaveCoreEngine.Pivot pivot:window.major)check(pivot.b>=window.base&&pivot.known<=window.lastBar,"pivot stream prunes expired candles without projected endpoints");
        for(ZwaveCoreEngine.Count count:window.state.confirmedCounts)check(count.pivot.b>=window.base,"expired confirmed counts are removed with their actual price bars");
        check(lineCount<=250&&labelCount<=250,"primary Elliott/Fibonacci keep budgets reserved before hidden drawings and shadow");
    }
}
