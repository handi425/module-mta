import converted.zwavecore.*;
import java.util.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.regex.*;
import net.metaquotes.metatrader5.modules.api.*;
/** Pure source-contract, broker alignment, frozen transform and live rollback regressions. */
public final class ZwaveCoreShadowTest {
    private static int checks;
    private static final long START=1700000000L;
    private static Path pine=Paths.get("mt5-modules/converted/zwavecore/original.pine");
    private static void check(boolean value,String message){
        checks++;
        if(!value)throw new AssertionError(message);
    }
    private static void near(double actual,double expected,String message){
        check(Math.abs(actual-expected)<1e-8*Math.max(1,Math.abs(expected)),message+" actual="+actual+" expected="+expected);
    }
    private static Map<String,String> values(String... pairs){
        Map<String,String> input=new LinkedHashMap<String,String>();
        for(int i=0;i<pairs.length;i+=2)input.put(pairs[i],pairs[i+1]);
        return ZwaveCoreInputs.normalize(input);
    }
    private static List<ChartData.Bar> linear(int count,double base,double step,double half){
        List<ChartData.Bar> bars=new ArrayList<ChartData.Bar>();
        for(int i=0;i<count;i++){
            double open=base+i*step;
            bars.add(new ChartData.Bar(START+i*60,open,open+half,open-half,open+step/2,10+i,0));
        }
        return bars;
    }
    private static List<ChartData.Bar> oscillating(int count,double scale,double base){
        List<ChartData.Bar> bars=new ArrayList<ChartData.Bar>();
        for(int i=0;i<count;i++){
            double open=base+scale*(Math.sin(i*.24)*9+Math.sin(i*.057)*11+i*.008),close=open+scale*Math.sin(i*.4);
            bars.add(new ChartData.Bar(START+i*60,open,Math.max(open,close)+scale*.8,Math.min(open,close)-scale*.8,close,i+1,0));
        }
        return bars;
    }
    private static ChartData chart(String symbol,List<ChartData.Bar> bars,ChartData.Bar forming){
        String base=symbol.startsWith("XAU")?"XAU":symbol.startsWith("XAG")?"XAG":symbol.startsWith("USDJPY")?"USD":"",profit=base.equals("USD")?"JPY":base.isEmpty()?"":"USD";
        return new ChartData(7,"Broker",symbol,1,bars,forming,2,60,START+10000,Collections.<Integer,List<ChartData.Bar>>emptyMap(),.01,base,profit,0xff101820);
    }
    private static ChartData primary(int n){
        return chart("XAUUSDm",linear(n,200,1,2),null);
    }
    private static ChartData reference(int n){
        return chart("XAGUSDm",linear(n,50,.5,1),null);
    }
    private static boolean has(String[] values,String wanted){
        return Arrays.asList(values).contains(wanted);
    }
    private static void inputs()throws Exception{
        ModuleDescriptor descriptor=ZwaveCoreInputs.DESCRIPTOR;
        check(descriptor.id.equals("xoronx.zwavecore")&&descriptor.apiVersion==6,"API6 descriptor identity");
        check(descriptor.inputs.size()==84,"74 source inputs plus ten native group headers");
        Map<String,InputDefinition> actual=new HashMap<String,InputDefinition>();
        int headers=0;
        for(InputDefinition input:descriptor.inputs){
            actual.put(input.key,input);
            if(input.key.startsWith("section"))headers++;
        }
        check(headers==10,"all source input groups present");
        String source=new String(Files.readAllBytes(pine),StandardCharsets.UTF_8);
        Matcher rows=Pattern.compile("(?m)^\\w+ (\\w+) = input\\.(\\w+)\\(([^,]+), \"([^\"]+)\"(.*)$").matcher(source);
        int count=0;
        Map<String,Integer> pineColors=new HashMap<String,Integer>();
        pineColors.put("color.aqua",0xff00bcd4);
        pineColors.put("color.silver",0xffb2b5be);
        pineColors.put("color.orange",0xffff9800);
        while(rows.find()){
            count++;
            String key=rows.group(1),kind=rows.group(2),initial=rows.group(3),tail=rows.group(5);
            InputDefinition input=actual.get(key);
            check(input!=null,"source input available: "+key);
            check(input.label.startsWith(rows.group(4)),"source label retained: "+key);
            if(kind.equals("int")||kind.equals("float")){
                near(Double.parseDouble(input.defaultValue),Double.parseDouble(initial),"source default "+key);
                Matcher min=Pattern.compile("minval = ([^,]+)").matcher(tail),max=Pattern.compile("maxval = ([^,]+)").matcher(tail);
                check(min.find()&&max.find(),"source numeric limits "+key);
                near(input.min,Double.parseDouble(min.group(1)),"minimum "+key);
                near(input.max,Double.parseDouble(max.group(1)),"maximum "+key);
            }
            else if(kind.equals("color")){
                int expected=initial.startsWith("#")?(int)(0xff000000L|Long.parseLong(initial.substring(1),16)):pineColors.get(initial);
                check(InputDefinition.parseColor(input.defaultValue)==expected,"Pine color default "+key);
            }
            else if(kind.equals("time")){
                check(input.type==InputDefinition.Type.TEXT&&input.defaultValue.equals("0"),"time represented as long Unix seconds");
            }
            else {
                String expected=initial.startsWith("\"")?initial.substring(1,initial.length()-1):initial;
                check(input.defaultValue.equals(expected),"source default "+key);
            }
            if(kind.equals("string")){
                Matcher options=Pattern.compile("options = \\[([^\\]]+)\\]").matcher(tail);
                check(options.find(),"source options "+key);
                List<String> wanted=new ArrayList<String>();
                Matcher choices=Pattern.compile("\"([^\"]+)\"").matcher(options.group(1));
                while(choices.find())wanted.add(choices.group(1));
                check(input.options.equals(wanted),"all source choices "+key);
            }
        }
        check(count==74,"all and only74 actual Pine inputs audited");
        check(ZwaveCoreInputs.anchorTime(values("shadowAnchorInput","2200000000"))==2200000000L,"manual anchor beyond2038 remains exact");
        for(String invalid:new String[]{
            "-1","1.5","NaN","2026-11-22"
        }
        ){
            boolean rejected=false;
            try{
                values("shadowAnchorInput",invalid);
            }
            catch(IllegalArgumentException expected){
                rejected=true;
            }
            check(rejected,"invalid Unix anchor rejected "+invalid);
        }
        boolean rejected=false;
        try{
            values("deviation","0.00001","factor","20");
        }
        catch(IllegalArgumentException expected){
            rejected=true;
        }
        check(rejected,"source micro-deviation invariant");
        rejected=false;
        try{
            values("hiddenMinBars","20","hiddenMaxBars","5");
        }
        catch(IllegalArgumentException expected){
            rejected=true;
        }
        check(rejected,"source hidden interval invariant");
        near(ZwaveCoreInputs.step("shadowAmplitude"),.05,"amplitude step metadata");
        near(ZwaveCoreInputs.step("shadowVerticalOffset"),.25,"offset step metadata");
    }
    private static void selection(){
        Map<String,String> v=values();
        String[] names=ShadowEngine.candidates("XAUUSDm",v);
        check(names[0].equals("XAGUSDm"),"automatic metal pair keeps broker suffix");
        check(has(names,"XAGUSD"),"plain metal fallback");
        check(ShadowEngine.candidates("pro.XAGUSD",v)[0].equals("pro.XAUUSD"),"automatic pair keeps broker prefix");
        check(ShadowEngine.candidates("US100.cash",v)[0].equals("US500.cash"),"index preset keeps cash decoration");
        check(has(ShadowEngine.candidates("US500",v),"NAS100"),"reverse index preset");
        names=ShadowEngine.candidates("USDJPYm",v);
        check(has(names,"6J1!m")&&has(names,"6J1!")&&has(names,"6J"),"USDJPY asks only recognizable actual futures names");
        check(!has(names,"USDJPY")&&!has(names,"JPYUSD"),"no fabricated proxy replaces currency futures");
        check(ShadowEngine.candidates("6Jm",v)[0].equals("USDJPYm"),"reversed currency-futures preset retains broker suffix");
        check(ShadowEngine.candidates("pro.6C1!",v)[0].equals("pro.USDCAD"),"reversed futures preset strips contract notation and retains broker prefix");
        check(ShadowEngine.candidates("EURUSD",v).length==0,"unknown automatic pair explicitly unavailable");
        check(ShadowEngine.select(primary(20),v,Arrays.asList("EURUSDm","XAGUSDm")).equals("XAGUSDm"),"selection requires actual broker inventory");
        check(ShadowEngine.select(primary(20),v,Arrays.asList("EURUSDm")).isEmpty(),"unavailable feed not invented");
        names=ShadowEngine.candidates("XAUUSDm",values("shadowPairMode","Manual"));
        check(names[0].equals("XAGUSDm"),"source TradingView default maps to broker counterpart");
        names=ShadowEngine.candidates("XAUUSDm",values("shadowPairMode","Manual","shadowManualSymbol","custom.silver"));
        check(names[0].equals("custom.silver"),"explicit manual broker name has first priority");
        ChartData usdJpy=chart("USDJPY",linear(20,120,.1,.5),null),future=chart("6J1!",linear(20,.01,.00001,.00002),null);
        check(ShadowEngine.inverse(usdJpy,future,v),"USDJPY futures preset inverted");
        check(!ShadowEngine.inverse(usdJpy,future,values("shadowDirection","Searah")),"same-direction override");
        check(ShadowEngine.inverse(primary(20),reference(20),values("shadowDirection","Terbalik")),"inverse override");
        ChartData a=new ChartData(7,"Broker","ABC",1,linear(20,100,1,2),null,2,60,0,Collections.<Integer,List<ChartData.Bar>>emptyMap(),.01,"USD","JPY",0),b=new ChartData(7,"Broker","DEF",1,linear(20,1,.1,.2),null,2,60,0,Collections.<Integer,List<ChartData.Bar>>emptyMap(),.01,"JPY","USD",0);
        check(ShadowEngine.inverse(a,b,values("shadowPairMode","Manual")),"manual reciprocal currency metadata inverted");
    }
    private static void brokerAffixMatrix(){
        String[][] cases={
            {"XAUUSD","XAGUSD"},
            {"XAUUSD.a","XAGUSD.a"},
            {"XAUUSD.pro","XAGUSD.pro"},
            {"r.XAUUSD","r.XAGUSD"},
            {"r.XAUUSD.a","r.XAGUSD.a"},
            {"r.XAUUSD.pro","r.XAGUSD.pro"}
        };
        Map<String,String> automatic=values();
        for(String[] pair:cases){
            // Explicit instrument metadata must work for decorated broker names too.
            ChartData primary=new ChartData(7,"Broker",pair[0],1,linear(40,200,1,2),null,
                2,60,START+10000,Collections.<Integer,List<ChartData.Bar>>emptyMap(),
                .01,"XAU","USD",0xff101820);
            String[] ordered=ShadowEngine.candidates(primary,automatic);
            String[] expected=pair[1].equals("XAGUSD")?new String[]{"XAGUSD"}:new String[]{pair[1],"XAGUSD"};
            check(Arrays.equals(ordered,expected),"exact counterpart precedes plain broker fallback: "+pair[0]);
            check(Arrays.equals(ShadowEngine.candidates(pair[0],automatic),expected),"name-only candidates retain the same broker affixes: "+pair[0]);
            List<String> inventory=Arrays.asList("EURUSD.other","XAGUSD",pair[1]);
            check(ShadowEngine.select(primary,automatic,inventory).equals(pair[1]),"ordered broker counterpart wins over earlier inventory fallback: "+pair[0]);
            check(ShadowEngine.select(primary,automatic,Collections.singletonList("XAGUSD")).equals("XAGUSD"),"plain counterpart used only when actually present: "+pair[0]);
            List<String> unrelated=Arrays.asList("EURUSD.other","XAGUSD.unrelated");
            check(ShadowEngine.select(primary,automatic,unrelated).isEmpty(),"absent broker affixes are not guessed or fabricated: "+pair[0]);
            Map<String,String> manual=values("shadowPairMode","Manual","shadowManualSymbol","custom.SILVER");
            check(ShadowEngine.candidates(primary,manual)[0].equals("custom.SILVER"),"explicit manual name precedes automatic counterpart: "+pair[0]);
            check(ShadowEngine.select(primary,manual,Arrays.asList(pair[1],"custom.SILVER")).equals("custom.SILVER"),"manual exact existing broker symbol selected: "+pair[0]);
            check(ShadowEngine.select(primary,manual,inventory).isEmpty(),"missing manual symbol does not silently select automatic feed: "+pair[0]);
            Map<String,String> manualPlain=values("shadowPairMode","Manual","shadowManualSymbol","XAGUSD");
            check(ShadowEngine.select(primary,manualPlain,inventory).equals("XAGUSD"),"explicit undecorated manual symbol remains authoritative: "+pair[0]);
            ShadowEngine.Result unavailable=ShadowEngine.analyze(primary,null,automatic,null);
            check(unavailable.frame.candles.isEmpty()&&unavailable.frame.drawings.isEmpty()&&!unavailable.status.isEmpty(),"unavailable feed reports status without fake OHLC or waves: "+pair[0]);
        }
    }
    private static void transforms(){
        ChartData p=primary(60),r=reference(60);
        Map<String,String> v=values("shadowWaveFeatures","false");
        ShadowEngine.Result result=ShadowEngine.analyze(p,r,v,null);
        check(result.anchorTime==START+14*60,"first common loaded bar with valid priorATR anchors automatically");
        near(result.transform.anchorAtr,4,"anchor uses prior primary ATR14");
        near(result.transform.scale,2,"ATR scale uses prior reference ATR14");
        near(result.transform.price(57),214,"reference anchor open maps exactly to chart anchor open");
        PlotFrame.Candles batch=result.frame.candles.get(0);
        check(batch.times[0]==result.anchorTime&&batch.times.length==46,"pre-anchor bars do not plot");
        near(batch.open[0],214,"transformed candle anchor open");
        check((batch.bodyColors[0]>>>24)==38&&(batch.wickColors[0]>>>24)==166&&(batch.borderColors[0]>>>24)==166,"separate source body85/wick35 transparency");
        ShadowEngine.Result shifted=ShadowEngine.analyze(p,r,values("shadowWaveFeatures","false","shadowAmplitude","2","shadowVerticalOffset","3"),result.state);
        near(shifted.transform.scale,result.transform.scale,"amplitude and offset retain anchor scale");
        near(shifted.transform.price(58),230,"affine amplitude and ATR offset");
        ShadowEngine.Result inverse=ShadowEngine.analyze(p,r,values("shadowWaveFeatures","false","shadowDirection","Terbalik"),null);
        PlotFrame.Candles mirrored=inverse.frame.candles.get(0);
        near(mirrored.high[0],inverse.transform.price(r.closedBars.get(14).low),"inversion swaps raw low to visual high");
        near(mirrored.low[0],inverse.transform.price(r.closedBars.get(14).high),"inversion swaps raw high to visual low");
        check(mirrored.high[0]>=Math.max(mirrored.open[0],mirrored.close[0])&&mirrored.low[0]<=Math.min(mirrored.open[0],mirrored.close[0]),"inverted OHLC invariants");
        check((mirrored.bodyColors[0]&0xffffff)==(ZwaveCoreInputs.c(values(),"shadowBearColor")&0xffffff),"candle color follows displayed direction");
        ShadowEngine.Result hollow=ShadowEngine.analyze(p,r,values("shadowWaveFeatures","false","shadowHollow","true"),null);
        check((hollow.frame.candles.get(0).bodyColors[0]>>>24)==0&&(hollow.frame.candles.get(0).borderColors[0]>>>24)==166,"hollow retains wick and outline");
        ShadowEngine.Result ratio=ShadowEngine.analyze(p,r,values("shadowWaveFeatures","false","shadowScaleMode","Rasio harga pada jangkar"),null);
        near(ratio.transform.scale,214.0/57,"price-ratio scaling fixed at anchor opens");
        long requested=START+20*60+1;
        ShadowEngine.Result manual=ShadowEngine.analyze(p,r,values("shadowWaveFeatures","false","shadowAnchorInput",String.valueOf(requested)),null);
        check(manual.anchorTime==START+21*60,"manual anchor takes actual first common bar on or after requested second");
        List<ChartData.Bar> manualGap=new ArrayList<ChartData.Bar>(r.closedBars);
        manualGap.remove(21);
        ShadowEngine.Result gapAnchor=ShadowEngine.analyze(p,chart("XAGUSDm",manualGap,null),values("shadowWaveFeatures","false","shadowAnchorInput",String.valueOf(requested)),null);
        check(gapAnchor.anchorTime==START+22*60,"manual anchor skips an unaligned bar rather than filling the gap");
        List<ChartData.Bar> shortRef=Collections.singletonList(r.closedBars.get(30));
        ShadowEngine.Result ratioFirst=ShadowEngine.analyze(p,chart("XAGUSDm",shortRef,null),values("shadowWaveFeatures","false","shadowScaleMode","Rasio harga pada jangkar"),null);
        check(ratioFirst.anchorTime==START+30*60,"ratio mode needs primary priorATR but not reference priorATR");
        ShadowEngine.Result appended=ShadowEngine.analyze(primary(80),reference(80),v,result.state);
        near(appended.transform.scale,result.transform.scale,"later volatility cannot renormalize fixed scale");
        check(appended.anchorTime==result.anchorTime,"new bars do not move automatic anchor");
        ChartData trimmedP=chart("XAUUSDm",p.closedBars.subList(20,60),null),trimmedR=chart("XAGUSDm",r.closedBars.subList(20,60),null);
        ShadowEngine.Result trimmed=ShadowEngine.analyze(trimmedP,trimmedR,v,result.state);
        check(trimmed.anchorTime==result.anchorTime,"sliding loaded-history window retains fixed anchor state");
        near(trimmed.transform.base,result.transform.base,"loaded-window shift does not move shadow vertically");
        ShadowEngine.Result limited=ShadowEngine.analyze(p,r,values("shadowWaveFeatures","false","shadowBars","10"),null);
        check(limited.frame.candles.get(0).times.length==10,"display window counts primary bars");
        List<ChartData.Bar> beforeAnchor=linear(15,200,1,2),beforeRef=linear(15,50,.5,1);
        ChartData openP=chart("XAUUSDm",beforeAnchor.subList(0,14),beforeAnchor.get(14)),openR=chart("XAGUSDm",beforeRef.subList(0,14),beforeRef.get(14));
        ShadowEngine.Result provisional=ShadowEngine.analyze(openP,openR,v,null);
        check(provisional.anchorTime==START+14*60,"first valid live anchor displayed provisionally");
        ShadowEngine.Result rolledBack=ShadowEngine.analyze(openP,chart("XAGUSDm",beforeRef.subList(0,14),null),v,provisional.state);
        check(rolledBack.anchorTime==0,"provisional anchor is not committed before primary bar close");
        ShadowEngine.Result committed=ShadowEngine.analyze(chart("XAUUSDm",beforeAnchor,null),chart("XAGUSDm",beforeRef,null),v,provisional.state);
        check(committed.anchorTime==START+14*60,"closing primary candle commits the actual anchor");
    }
    private static void gapsAndMissing(){
        ChartData p=primary(80);
        List<ChartData.Bar> refs=new ArrayList<ChartData.Bar>(reference(80).closedBars);
        long missing=refs.remove(50).time;
        ShadowEngine.Result result=ShadowEngine.analyze(p,chart("XAGUSDm",refs,null),values("shadowWaveFeatures","false"),null);
        for(long time:result.frame.candles.get(0).times)check(time!=missing,"no stale reference bar fills primary session gap");
        check(result.alignedBars==79,"exact timestamp alignment");
        refs.remove(refs.size()-1);
        result=ShadowEngine.analyze(p,chart("XAGUSDm",refs,null),values("shadowWaveFeatures","false"),null);
        check(!result.currentAligned&&result.status.contains("celah"),"current gap exposed as status without synthetic candle");
        result=ShadowEngine.analyze(p,null,values(),null);
        check(result.frame.candles.isEmpty()&&result.status.contains("broker"),"missing actual broker feed leaves explicit status");
        check(result.frame.drawings.isEmpty(),"missing reference produces no fabricated shadow waves");
        result=ShadowEngine.analyze(p,null,values("shadowShowPanel","true"),null);
        check(result.frame.panels.size()==1&&result.frame.panels.get(0).corner==2,"optional missing-reference panel fixed at bottom-left");
        result=ShadowEngine.analyze(p,reference(80),values("shadowShow","false"),null);
        check(result.frame.candles.isEmpty()&&result.status.contains("dinonaktifkan"),"shadow disable independent from primary");
        ChartData wrong=new ChartData(7,"Other","XAGUSDm",1,refs);
        result=ShadowEngine.analyze(p,wrong,values(),null);
        check(result.frame.candles.isEmpty()&&result.status.contains("server"),"cross-server comparison refused");
        result=ShadowEngine.analyze(p,reference(80),values("shadowAnchorInput",String.valueOf(START+10000)),null);
        check(result.frame.candles.isEmpty()&&result.status.contains("jangkar"),"future manual anchor waits without reanchoring");
    }
    private static void rawMacdAndRollback(){
        List<ChartData.Bar> raw=oscillating(240,1,60),primaryAll=oscillating(240,3,240),sparse=new ArrayList<ChartData.Bar>();
        for(int i=0;i<primaryAll.size();i++)if(i%7!=3)sparse.add(primaryAll.get(i));
        ChartData p=chart("XAUUSDm",sparse,null),r=chart("XAGUSDm",raw,null);
        ShadowEngine.Result a=ShadowEngine.analyze(p,r,values(),null);
        check(a.waves!=null,"shadow raw diagnostics available");
        double[] macd=ShadowEngine.macd(raw),recomputed=ShadowEngine.macd(a.alignedReference.allBars());
        boolean differs=false;
        for(int i=0;i<a.alignedReference.closedBars.size();i++){
            long time=a.alignedReference.closedBars.get(i).time;
            int rawAt=(int)((time-START)/60);
            near(a.waves.macd[i],macd[rawAt],"MACD sampled from complete raw reference history before gaps");
            if(Math.abs(a.waves.macd[i]-recomputed[i])>1e-6)differs=true;
        }
        check(differs,"alignment does not incorrectly restart/recompute EMA on sparse bars");
        ShadowEngine.Result mirrored=ShadowEngine.analyze(p,r,values("shadowDirection","Terbalik"),null);
        check(mirrored.waves.major.size()==a.waves.major.size(),"render inversion leaves raw ZigZag stream unchanged");
        for(int i=0;i<a.waves.major.size();i++){
            near(mirrored.waves.major.get(i).p,a.waves.major.get(i).p,"raw pivot invariant under render inversion");
            check(mirrored.waves.major.get(i).t==a.waves.major.get(i).t,"raw pivot time invariant");
        }
        boolean haveShadowLines=false;
        for(PlotFrame.Drawing d:a.frame.drawings){
            if(d.type==2){
                haveShadowLines=true;
                check(d.times[0]>=a.anchorTime,"shadow line start clipped at frozen anchor/window");
            }
            if(d.type==101)check(d.text.startsWith("S:"),"all shadow labels prefixed S:");
        }
        check(haveShadowLines,"shadow ZigZag drawings emitted");
        for(PlotFrame.Drawing d:a.frame.drawings)if(d.type==101&&!d.key.startsWith("S_fib_text"))check(d.times[0]<=p.closedBars.get(p.closedBars.size()-1).time,"wave/hidden labels keep actual pivot times");
        List<ChartData.Bar> livePrimary=oscillating(121,3,240),liveRef=oscillating(121,1,60);
        ChartData baseP=chart("XAUUSDm",livePrimary.subList(0,120),null),baseR=chart("XAGUSDm",liveRef.subList(0,120),null);
        ShadowEngine.Result base=ShadowEngine.analyze(baseP,baseR,values(),null);
        ChartData.Bar fp=livePrimary.get(120),fr=liveRef.get(120);
        ShadowEngine.Result first=ShadowEngine.analyze(chart("XAUUSDm",livePrimary.subList(0,120),fp),chart("XAGUSDm",liveRef.subList(0,120),fr),values(),base.state);
        check(first.waves.provisional,"reference forming candle analyzed on primary live update");
        ChartData.Bar revised=new ChartData.Bar(fr.time,fr.open,fr.high+20,fr.low-20,fr.close+10);
        ShadowEngine.Result second=ShadowEngine.analyze(chart("XAUUSDm",livePrimary.subList(0,120),fp),chart("XAGUSDm",liveRef.subList(0,120),revised),values(),first.state);
        ShadowEngine.Result fresh=ShadowEngine.analyze(chart("XAUUSDm",livePrimary.subList(0,120),fp),chart("XAGUSDm",liveRef.subList(0,120),revised),values(),base.state);
        check(second.waves.major.size()==fresh.waves.major.size()&&second.waves.minor.size()==fresh.waves.minor.size(),"next forming tick rolls back provisional stream");
        check(second.waves.state.confirmedCounts.size()==base.waves.state.confirmedCounts.size(),"forming updates never commit tentative counts");
        for(int i=0;i<second.waves.major.size();i++)check(ZwaveCoreEngine.same(second.waves.major.get(i),fresh.waves.major.get(i)),"forming rollback equals independent replay");
        ShadowEngine.Result closed=ShadowEngine.analyze(chart("XAUUSDm",livePrimary,null),chart("XAGUSDm",liveRef,null),values(),second.state);
        check(!closed.waves.provisional,"bar close commits shadow stream independently");
        ShadowEngine.Result repeated=ShadowEngine.analyze(chart("XAUUSDm",livePrimary,null),chart("XAGUSDm",liveRef,null),values(),closed.state);
        check(repeated.waves.major.size()==closed.waves.major.size(),"repeated closed refresh does not duplicate pivots");
    }
    public static void main(String[] args)throws Exception{
        if(args.length>0)pine=Paths.get(args[0]);
        inputs();
        selection();
        brokerAffixMatrix();
        transforms();
        gapsAndMissing();
        rawMacdAndRollback();
        System.out.println("Zwave Core shadow PASS: "+checks+" assertions");
    }
}
