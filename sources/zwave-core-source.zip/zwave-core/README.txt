Zwave Core 1.0.0 — XoRonX | Mr Poleks

Adaptasi Android dari script Pine v6 lengkap yang diberikan pengguna (2518 baris).
Confirmed ZigZag: adaptasi TradingView ZigZag library v9. Geometri/search Elliott
dan hidden MACD divergence mempertahankan aturan sumber ZWave yang disertakan.

Membutuhkan APK MetaTrader 5 Custom 6317 atau lebih baru / SDK API6, tanpa root.
Pasang/unduh melalui katalog GitHub module-mta, lalu tambahkan dari library.
74 pengaturan asli tersedia pada halaman parameter native indikator.
Tidak ada alert, notifikasi, entry mode, trading atau tombol proyeksi chart.

Fitur: confirmed large/child/micro ZigZag, Elliott counts dengan tanda ? untuk
hitungan berkembang, Fibonacci besar/child, hidden MACD divergence, shadow candle
korelasi dan analisis ZWave terpisah pada OHLC asli simbol pembanding.
Shadow memakai data broker MT5 pada timeframe yang sama. Nama TradingView seperti
OANDA:XAGUSD dipetakan hanya jika ekuivalen simbol broker benar-benar tersedia.
Simbol futures yang tidak tersedia tidak diganti CFD atau data buatan; gunakan
pasangan Manual yang tersedia di broker. Status tersedia pada pengaturan modul
dan panel status opsional. Analisis utama tetap berjalan bila referensi menunggu.

Seluruh gambar memakai Canvas, tanpa objek chart atau area pengaturan di bawah
chart. Anchor otomatis shadow tetap pada bar bersama awal yang memenuhi syarat
di riwayat termuat; anchor ini tidak bergeser mengikuti viewport. Fibonacci terbaru
memakai candle sumber terakhir sebagai dasar ekstensi, bukan sisi layar. Adaptasi
ini mengikuti permintaan agar garis/teks tidak floating saat chart digeser.
Anchor manual memakai Unix timestamp dalam detik (0 = otomatis). Panel status
opsional berada tetap di sudut chart, bukan pada koordinat harga.

Utama dianalisis dari candle tertutup. Shadow dapat memakai candle pembanding
yang masih berjalan pada update chart, dengan rollback hitungan provisional.
Hasil cache dipakai ulang hanya bila OHLCV/metadata/parameter identik. Kalkulasi
berjalan di worker dengan antrean terbatas. Batas history dan work tetap sesuai
input sumber; batas pencarian bukan konfirmasi pola.

Source Pine asli, adaptasi Java, SDK dan pengujian:
https://github.com/handi425/module-mta/blob/main/sources/zwave-core-source.zip
Mozilla Public License 2.0: https://www.mozilla.org/en-US/MPL/2.0/
Notices dan atribusi sumber dipertahankan; lihat LICENSE-MPL-2.0.txt.
Adaptasi ini tidak disponsori TradingView atau MetaQuotes.
