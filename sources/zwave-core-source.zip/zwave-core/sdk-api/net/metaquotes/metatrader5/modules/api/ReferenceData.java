package net.metaquotes.metatrader5.modules.api;

/** Immutable comparison-feed result; absent data never substitutes invented prices. */
public final class ReferenceData {
    public final ChartData chart;
    public final String symbol,status;
    public ReferenceData(ChartData chart,String symbol,String status){
        if(symbol==null||status==null)throw new IllegalArgumentException("Reference identity/status required");
        this.chart=chart;this.symbol=symbol;this.status=status;
    }
}
