package net.metaquotes.metatrader5.modules.api;
import android.content.Context;
public final class ModuleEnvironment {
    public final Context appContext;
    public final ClassLoader classLoader;
    public final String instanceId;
    public ModuleEnvironment(Context context, ClassLoader classLoader) {
        this(context,classLoader,"legacy");
    }
    public ModuleEnvironment(Context context, ClassLoader classLoader,String instanceId) {
        if (context == null || classLoader == null) throw new IllegalArgumentException("Host environment required");
        Context app = context.getApplicationContext();
        this.appContext = app == null ? context : app;
        this.classLoader = classLoader;
        this.instanceId=instanceId;
    }
    public void publish(int chartId,PlotFrame frame)throws Exception {
        Class.forName("net.metaquotes.metatrader5.stochdiv.ConvertedIndicatorRenderer",false,classLoader)
            .getMethod("render",ModuleEnvironment.class,int.class,PlotFrame.class).invoke(null,this,chartId,frame);
    }
    /** Request on the chart thread before beginning background calculation. */
    public DeferredPlot defer(ChartData snapshot)throws Exception {
        try{return (DeferredPlot)Class.forName("net.metaquotes.metatrader5.stochdiv.ModuleRuntime",false,classLoader)
            .getMethod("deferPlot",ModuleEnvironment.class,ChartData.class).invoke(null,this,snapshot);}
        catch(java.lang.reflect.InvocationTargetException wrapped){Throwable cause=wrapped.getCause();if(cause instanceof Exception)throw (Exception)cause;if(cause instanceof Error)throw (Error)cause;throw wrapped;}
    }
    public void clear(int chartId)throws Exception {
        Class.forName("net.metaquotes.metatrader5.stochdiv.ConvertedIndicatorRenderer",false,classLoader)
            .getMethod("clear",ModuleEnvironment.class,int.class).invoke(null,this,chartId);
    }
    /** API6: read a broker comparison feed for this active chart attachment. Call on MAIN. */
    public ReferenceData reference(ChartData owner,String[] candidateSymbols,int maximum)throws Exception {
        try{return (ReferenceData)Class.forName("net.metaquotes.metatrader5.stochdiv.ModuleRuntime",false,classLoader)
            .getMethod("referenceChart",ModuleEnvironment.class,ChartData.class,String[].class,int.class).invoke(null,this,owner,candidateSymbols,maximum);}
        catch(java.lang.reflect.InvocationTargetException wrapped){Throwable cause=wrapped.getCause();if(cause instanceof Exception)throw (Exception)cause;if(cause instanceof Error)throw (Error)cause;throw wrapped;}
    }
    @SuppressWarnings("unchecked") public java.util.List<ChartEvent> events(int chartId)throws Exception {
        return (java.util.List<ChartEvent>)Class.forName("net.metaquotes.metatrader5.stochdiv.ConvertedIndicatorRenderer",false,classLoader)
            .getMethod("events",String.class,int.class).invoke(null,instanceId,chartId);
    }
    public Context uiContext()throws Exception {
        return (Context)Class.forName("net.metaquotes.metatrader5.stochdiv.ConvertedIndicatorRenderer",false,classLoader)
            .getMethod("uiContext").invoke(null);
    }
}
