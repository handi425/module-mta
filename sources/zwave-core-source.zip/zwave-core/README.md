# Zwave Core

Port of the complete user-supplied Pine v6 `Zwave Core` by XoRonX | Mr Poleks,
under MPL-2.0. The 2518-line source is retained byte-for-byte as `original.pine`
(SHA-256 `4082bdb11308ef2d8994167a16d3b067ebd30d0dbe96034500749dd16d667b0f`).
Its confirmed ZigZag is adapted from TradingView's ZigZag library v9; the source
attributes the Elliott geometry and hidden MACD overlay to the supplied ZWave.

The separate module `xoronx.zwavecore`, version1.0.0, requires API6 / APK6317.
All74 functional inputs, defaults, ranges and choices are preserved with10 native
section rows. The Android parameter list has no notification controls or chart
projection button. Geometry uses Canvas and creates no chart objects.

The primary analysis consumes closed bars. Shadow analysis uses raw comparison
OHLC and full-reference EMA MACD before time alignment. It runs a separate state,
then applies the fixed affine transform only to drawing prices; inverse display
does not invert Elliott or MACD inputs. Forming reference bars are provisional
and do not mutate committed counts. Missing-session timestamps are never filled
with invented candles. Candle bodies, wicks and borders retain distinct opacity,
including hollow bodies. Indicator calculations run in a bounded background queue;
unchanged OHLCV, metadata and inputs reuse the same combined frame.

Comparison feeds come from the current MT5 broker, not TradingView exchanges.
Automatic pair names prefer the same broker prefix/suffix. Explicit exchange
prefixes are accepted only through an actual matching broker symbol. Missing
futures feeds remain unavailable; the code does not substitute dated contracts
or CFDs. Manual broker symbols can be selected through the normal parameters.
An unavailable comparison feed leaves primary analysis active and reports its
state in native indicator properties and the optional shadow panel.

To retain the requested stable time/price geometry, the automatic shadow anchor
uses the earliest eligible common loaded bar and remains fixed while that
identity/history is retained. It is not reset by panning/zooming. Latest Fibonacci
extension uses the last actual source candle instead of the visible right edge.
Manual anchor time uses Unix seconds as a text value;0 selects automatic.
Optional status panels stay at fixed chart corners. These viewport adaptations
are explicit changes from Pine; the Elliott/search and divergence rules remain.
Broker feed differences can produce different pivots from a TradingView feed.

Source notices and MPL2.0 text are included in `LICENSE-MPL-2.0.txt`. Public
corresponding source is `sources/zwave-core-source.zip` in `handi425/module-mta`;
it includes the converted source, original Pine, SDK6, tests and unsigned builders.
Host integration and signing keys remain in the private application repository.

Build using `mt5-modules/build-converted-module.ps1`, entry
`converted.zwavecore.ZwaveCore`, and `README.txt` as the package readme.
