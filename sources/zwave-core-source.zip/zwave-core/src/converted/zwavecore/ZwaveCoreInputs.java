// Derived from Zwave Core by XoRonX | Mr Poleks. MPL-2.0.
// Source: ../original.pine. Values cross the module boundary as strings.
package converted.zwavecore;

import java.util.Arrays;
import java.util.Map;
import net.metaquotes.metatrader5.modules.api.InputDefinition;
import net.metaquotes.metatrader5.modules.api.ModuleDescriptor;

public final class ZwaveCoreInputs {
    private ZwaveCoreInputs(){}
    public static final ModuleDescriptor DESCRIPTOR=new ModuleDescriptor(
        "xoronx.zwavecore","Zwave Core","1.0.0",6,Arrays.asList(
        section("sectionZigZag","ZigZag"),
        InputDefinition.decimal("deviation","Large ZigZag reversal (%)",2.5,0.00001,100),
        InputDefinition.integer("depth","Large pivot legs",10,2,200),
        InputDefinition.decimal("factor","Child / micro deviation divisor",3.0,1.01,20),
        InputDefinition.integer("childDepth","Child pivot legs",4,2,100),
        InputDefinition.integer("historyBars","Closed bars to analyse",5000,300,5000),
        section("sectionWaveDisplay","Wave display"),
        InputDefinition.bool("showZigzag","Draw child ZigZag",false),
        InputDefinition.bool("showMicro","Draw child-of-child wave labels",false),
        InputDefinition.bool("showDeveloping","Show developing counts with ?",true),
        InputDefinition.bool("showPanel","Structure status panel",false),
        InputDefinition.integer("visibleMajor","Large pivots displayed",24,2,100),
        section("sectionWaveText","Wave text"),
        InputDefinition.choice("waveFontSize","Large / child wave font size","Small","Tiny", "Small", "Normal", "Large", "Huge"),
        InputDefinition.choice("microFontSize","Child-of-child wave font size","Tiny","Tiny", "Small", "Normal", "Large", "Huge"),
        InputDefinition.decimal("lowerWaveGap","Extra spacing below waves (ATR)",0.05,0,1),
        InputDefinition.color("largeWaveTextColor","Large wave text color",0xffFF1493),
        InputDefinition.color("childWaveTextColor","Child wave text color",0xff00bcd4),
        InputDefinition.color("microWaveTextColor","Child-of-child wave text color",0xffb2b5be),
        section("sectionFibonacci","Fibonacci"),
        InputDefinition.bool("showLargeFib","Large ZigZag Fibonacci",true),
        InputDefinition.bool("showChildFib","Child ZigZag Fibonacci",true),
        InputDefinition.integer("childFibLegs","Recent child swings with Fibonacci",1,1,5),
        InputDefinition.color("largeFibColor","Large Fibonacci color",0xff708090),
        InputDefinition.color("childFibColor","Child Fibonacci color",0xff48D1CC),
        InputDefinition.integer("fibLineWidth","Fibonacci line width",1,1,5),
        InputDefinition.choice("fibLineStyle","Fibonacci line style","Dotted","Solid", "Dashed", "Dotted"),
        InputDefinition.integer("fibRightExtension","Fibonacci right extension (bars)",20,0,100),
        section("sectionFibonacciText","Fibonacci text"),
        InputDefinition.choice("largeFibFontSize","Large Fibonacci font size","Tiny","Tiny", "Small", "Normal", "Large", "Huge"),
        InputDefinition.choice("childFibFontSize","Child Fibonacci font size","Tiny","Tiny", "Small", "Normal", "Large", "Huge"),
        InputDefinition.color("largeFibTextColor","Large Fibonacci text color",0xff708090),
        InputDefinition.color("childFibTextColor","Child Fibonacci text color",0xff48D1CC),
        InputDefinition.choice("largeFibTextAlignment","Large Fibonacci text alignment","Right","Left", "Right"),
        InputDefinition.choice("childFibTextAlignment","Child Fibonacci text alignment","Right","Left", "Right"),
        InputDefinition.integer("fibTextShift","Fibonacci text shift right (bars)",1,0,20),
        section("sectionPerformance","Performance"),
        InputDefinition.integer("workLimit","Geometry search work limit",80000,10000,200000),
        section("sectionHiddenMacd","Hidden MACD divergence"),
        InputDefinition.bool("showHidden","Detect hidden divergence",true),
        InputDefinition.bool("hiddenLarge","Large ZigZag hidden divergence",true),
        InputDefinition.bool("hiddenChild","Child ZigZag hidden divergence",true),
        InputDefinition.bool("hiddenMicro","Micro ZigZag hidden divergence",true),
        InputDefinition.integer("hiddenMinBars","Min bars between same-side price pivots",5,1,4000),
        InputDefinition.integer("hiddenMaxBars","Max bars from original price anchor",500,1,4000),
        InputDefinition.integer("hiddenMaxSignals","Maximum hidden signals displayed",100,1,100),
        InputDefinition.bool("hiddenSameSideOfZero","Require lows below / highs above MACD zero",false),
        InputDefinition.bool("hiddenUseSwingExtremes","Compare MACD extremes inside incoming legs",true),
        InputDefinition.bool("hiddenShowLabels","Show HBull/HBear and Large/Child/Micro",true),
        InputDefinition.color("hiddenBullColor","Hidden bullish color",0xff00BFFF),
        InputDefinition.color("hiddenBearColor","Hidden bearish color",0xffff9800),
        section("sectionShadowCorrelation","Shadow korelasi"),
        InputDefinition.bool("shadowShow","Tampilkan shadow candle",true),
        InputDefinition.choice("shadowPairMode","Pilihan pasangan","Otomatis","Otomatis", "Manual"),
        InputDefinition.text("shadowManualSymbol","Simbol pembanding manual","OANDA:XAGUSD"),
        InputDefinition.choice("shadowDirection","Arah pembanding","Otomatis","Otomatis", "Searah", "Terbalik"),
        InputDefinition.choice("shadowScaleMode","Penyetaraan skala","ATR pada jangkar","ATR pada jangkar", "Rasio harga pada jangkar"),
        InputDefinition.text("shadowAnchorInput","Waktu jangkar manual (0 = otomatis) (Unix seconds)","0"),
        InputDefinition.decimal("shadowAmplitude","Amplitudo shadow",1.0,0.05,20),
        InputDefinition.decimal("shadowVerticalOffset","Geser vertikal (ATR jangkar)",0.0,-100,100),
        InputDefinition.integer("shadowBars","Maksimum bar shadow ditampilkan",1000,10,5000),
        InputDefinition.bool("shadowShowPanel","Panel status shadow",false),
        section("sectionShadowStyle","Tampilan shadow"),
        InputDefinition.color("shadowBullColor","Warna shadow naik",0xff2196F3),
        InputDefinition.color("shadowBearColor","Warna shadow turun",0xff9C27B0),
        InputDefinition.integer("shadowBodyTransparency","Transparansi badan",85,0,100),
        InputDefinition.integer("shadowWickTransparency","Transparansi wick dan batas",35,0,100),
        InputDefinition.bool("shadowHollow","Badan kosong (hollow)",false),
        section("sectionShadowWave","ZWave shadow"),
        InputDefinition.bool("shadowWaveFeatures","ZWave pada shadow (realtime)",true),
        InputDefinition.bool("shadowZigzag","ZigZag shadow",true),
        InputDefinition.bool("shadowWaveLabels","Label Elliott shadow S:",true),
        InputDefinition.bool("shadowMicro","Label micro shadow",false),
        InputDefinition.bool("shadowDeveloping","Hitungan berkembang shadow ?",true),
        InputDefinition.bool("shadowLargeFib","Fibonacci besar shadow",true),
        InputDefinition.bool("shadowChildFib","Fibonacci child shadow",true),
        InputDefinition.integer("shadowFibLegs","Swing child Fibonacci shadow",1,1,3),
        InputDefinition.bool("shadowHidden","Hidden MACD divergence shadow",true),
        InputDefinition.integer("shadowVisibleMajor","Pivot besar shadow ditampilkan",12,2,50),
        InputDefinition.integer("shadowHistoryBars","Bar pembanding dianalisis",1500,300,3000),
        InputDefinition.integer("shadowWorkLimit","Batas kerja pencarian shadow per tick",40000,10000,100000),
        InputDefinition.color("shadowLargeTextColor","Warna wave besar shadow",0xff7B1FA2),
        InputDefinition.color("shadowChildTextColor","Warna wave child shadow",0xff1565C0),
        InputDefinition.color("shadowMicroTextColor","Warna wave micro shadow",0xff00838F)));
    private static InputDefinition section(String key,String label){return InputDefinition.text(key,label,"════ "+label+" ════");}
    public static Map<String,String> normalize(Map<String,String> supplied){Map<String,String> values=DESCRIPTOR.normalizeInputs(supplied);validate(values);return values;}
    public static void validate(Map<String,String> v){
        if(d(v,"deviation")/(d(v,"factor")*d(v,"factor"))<0.00001)throw new IllegalArgumentException("Child/micro deviation must be at least 0.00001%. Increase large deviation or reduce the divisor.");
        if(i(v,"hiddenMaxBars")<i(v,"hiddenMinBars"))throw new IllegalArgumentException("Hidden divergence maximum bars must be at least the minimum bars.");
        anchorTime(v);
        if(s(v,"shadowManualSymbol").trim().isEmpty())throw new IllegalArgumentException("Manual reference symbol is empty");
    }
    /** Pine input.time milliseconds are represented as broker Unix seconds here. */
    public static long anchorTime(Map<String,String> v){
        try{long value=Long.parseLong(s(v,"shadowAnchorInput").trim());if(value<0)throw new NumberFormatException();return value;}
        catch(NumberFormatException invalid){throw new IllegalArgumentException("Shadow anchor must be nonnegative Unix seconds (0 = automatic)");}
    }
    /** Source step metadata; the native numeric editor accepts any in-range value. */
    public static double step(String key){
        if("lowerWaveGap".equals(key)||"shadowAmplitude".equals(key))return 0.05;
        if("shadowVerticalOffset".equals(key))return 0.25;
        if("workLimit".equals(key)||"shadowWorkLimit".equals(key))return 10000;
        return Double.NaN;
    }
    public static boolean b(Map<String,String> v,String key){return Boolean.parseBoolean(v.get(key));}
    public static int i(Map<String,String> v,String key){return Integer.parseInt(v.get(key));}
    public static double d(Map<String,String> v,String key){return Double.parseDouble(v.get(key));}
    public static int c(Map<String,String> v,String key){return InputDefinition.parseColor(v.get(key));}
    public static String s(Map<String,String> v,String key){return v.get(key);}
    public static int size(String value){return "Tiny".equals(value)?8:"Small".equals(value)?10:"Normal".equals(value)?12:"Large".equals(value)?14:18;}
    public static int font(String value){return size(value);}
    public static int style(String value){return "Dashed".equals(value)?1:"Dotted".equals(value)?2:3;}
    public static int transparency(int ink,int amount){return (ink&0x00ffffff)|((int)Math.round(255*(100-amount)/100.0)<<24);}
}
