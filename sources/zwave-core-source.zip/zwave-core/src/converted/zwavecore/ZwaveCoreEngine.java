// Zwave Core, (c) XoRonX | Mr Poleks. Mozilla Public License 2.0.
// Independent Java port of the supplied Pine source; no alerts or order actions.
package converted.zwavecore;
import java.util.*;
import net.metaquotes.metatrader5.modules.api.ChartData;
import net.metaquotes.metatrader5.modules.api.PlotFrame;
/** Pure confirmed ZigZag/Elliott/MACD engine. All computation belongs on a worker. */
public final class ZwaveCoreEngine {
    private ZwaveCoreEngine() {
    }
    public static final class Pivot {
        public final int b,known;
        public final long t;
        public final double p;
        public final boolean hi;
        public Pivot(int b,long t,double p,boolean hi,int known){
            this.b=b;
            this.t=t;
            this.p=p;
            this.hi=hi;
            this.known=known;
        }
    }
    public static final class Count {
        public final Pivot pivot;
        public final int degree;
        public final String waveName;
        public Count(Pivot pivot,int degree,String waveName){
            this.pivot=pivot;
            this.degree=degree;
            this.waveName=waveName;
        }
    }
    public static final class DivLink {
        public final Pivot three,five;
        public final int degree;
        DivLink(Pivot three,Pivot five,int degree){
            this.three=three;
            this.five=five;
            this.degree=degree;
        }
    }
    public static final class HiddenDivLink {
        public final Pivot anchor,endpoint;
        public final int degree,anchorOscBar,endpointOscBar;
        public final double anchorMacd;
        HiddenDivLink(Pivot anchor,Pivot endpoint,int degree,int anchorOscBar,int endpointOscBar,double anchorMacd){
            this.anchor=anchor;
            this.endpoint=endpoint;
            this.degree=degree;
            this.anchorOscBar=anchorOscBar;
            this.endpointOscBar=endpointOscBar;
            this.anchorMacd=anchorMacd;
        }
    }
    private static final class ImpulseAnchor {
        final Pivot origin,one,two,three;
        final int degree;
        final boolean developing;
        ImpulseAnchor(Pivot o,Pivot one,Pivot two,Pivot three,int degree,boolean developing){
            origin=o;
            this.one=one;
            this.two=two;
            this.three=three;
            this.degree=degree;
            this.developing=developing;
        }
    }
    private static final class ExtensionSpan {
        final Pivot two,three;
        final int degree;
        final boolean proved;
        ExtensionSpan(Pivot two,Pivot three,int degree,boolean proved){
            this.two=two;
            this.three=three;
            this.degree=degree;
            this.proved=proved;
        }
    }
    private static final class Candle {
        final int b;
        final long t;
        final double h,l,m;
        Candle(int b,ChartData.Bar bar,double macd){
            this.b=b;
            t=bar.time;
            h=bar.high;
            l=bar.low;
            m=macd;
        }
    }
    private static final class Pattern {
        final List<Pivot> points;
        final double fit;
        Pattern(List<Pivot> points,double fit){
            this.points=points;
            this.fit=fit;
        }
    }
    private static final class Path {
        final int[] at;
        final double fit;
        Path(int[] at,double fit){
            this.at=at;
            this.fit=fit;
        }
    }
    /** Immutable committed state. A provisional shadow tick never mutates it. */
    public static final class State {
        private final ChartData chart;
        private final Map<String,String> values;
        private final List<Candle> candles;
        private final List<Pivot> major,minor,micro;
        public final List<Count> confirmedCounts;
        private final List<ImpulseAnchor> anchors;
        private final List<ExtensionSpan> spans;
        private final Result settledResult;
        private final boolean overridden;
        private State(Engine e,Result result){
            overridden=e.overridden;
            chart=e.chart;
            values=Collections.unmodifiableMap(new LinkedHashMap<String,String>(e.v));
            candles=immutable(e.candles);
            major=immutable(e.major);
            minor=immutable(e.minor);
            micro=immutable(e.micro);
            confirmedCounts=immutable(e.confirmed);
            anchors=immutable(e.anchors);
            spans=immutable(e.spans);
            settledResult=result;
        }
    }
    public static final class Result {
        public final PlotFrame frame;
        public final State state;
        public final String status;
        public final List<Pivot> major,minor,micro;
        public final List<Count> counts;
        public final List<DivLink> links;
        public final List<HiddenDivLink> hidden;
        public final double[] macd,signal,histogram,atr;
        public final int work,searchLimit,base,lastBar;
        public final boolean provisional;
        private Result(Engine e,PlotFrame frame,State committed){
            this.frame=frame;
            status=e.status;
            major=immutable(e.major);
            minor=immutable(e.minor);
            micro=immutable(e.micro);
            counts=immutable(e.counts);
            links=immutable(e.links);
            hidden=immutable(e.hidden);
            macd=e.macd.clone();
            signal=e.signal.clone();
            histogram=e.histogram.clone();
            atr=e.atr.clone();
            work=e.work;
            searchLimit=e.limit;
            base=e.candles.isEmpty()?0:e.candles.get(0).b;
            lastBar=e.lastBar;
            provisional=e.provisional;
            state=committed==null?new State(e,this):committed;
        }
    }
    public static final class Options {
        final Map<String,String> values;
        final boolean includeForming,render;
        public double[] macdOverride;
        public double labelAtrOverride=Double.NaN;
        private Options(Map<String,String> v,boolean includeForming,boolean render){
            values=v;
            this.includeForming=includeForming;
            this.render=render;
        }
        public static Options primary(Map<String,String> v){
            return new Options(v,false,true);
        }
        /** Shadow diagnostics use raw reference prices; its caller renders affine/clipped geometry. */
        public static Options shadow(Map<String,String> v){
            Map<String,String> m=new LinkedHashMap<String,String>(v);
            String[][] pairs={
                {
                    "showZigzag","shadowZigzag"
                },
                {
                    "showMicro","shadowMicro"
                },
                {
                    "showDeveloping","shadowDeveloping"
                },
                {
                    "visibleMajor","shadowVisibleMajor"
                },
                {
                    "historyBars","shadowHistoryBars"
                },
                {
                    "showLargeFib","shadowLargeFib"
                },
                {
                    "showChildFib","shadowChildFib"
                },
                {
                    "childFibLegs","shadowFibLegs"
                },
                {
                    "showHidden","shadowHidden"
                },
                {
                    "workLimit","shadowWorkLimit"
                },
                {
                    "largeWaveTextColor","shadowLargeTextColor"
                },
                {
                    "childWaveTextColor","shadowChildTextColor"
                },
                {
                    "microWaveTextColor","shadowMicroTextColor"
                }
            };
            for(String[] pair:pairs)if(v.containsKey(pair[1]))m.put(pair[0],v.get(pair[1]));
            m.put("showPanel","false");
            return new Options(Collections.unmodifiableMap(m),true,false);
        }
    }
    public static Result analyze(ChartData chart,Map<String,String> normalizedValues,State previous){
        return analyze(chart,normalizedValues,previous,Options.primary(normalizedValues));
    }
    // Pine ordinary-var rollback: a live reference tick starts from the closed
    // committed state and returns that same state, even when its pivots differ.
    public static Result analyze(ChartData chart,Map<String,String> normalizedValues,State previous,Options options){
        if(chart==null||normalizedValues==null||options==null)throw new IllegalArgumentException("Zwave Core chart and normalized inputs required");
        double[] override=options.macdOverride==null?null:options.macdOverride.clone();
        if(override!=null&&override.length<chart.closedBars.size()+(options.includeForming&&chart.formingBar!=null?1:0))throw new IllegalArgumentException("Aligned MACD override is incomplete");
        Result settled;
        if(previous!=null&&previous.chart.closedBars.size()==chart.closedBars.size()&&sameLineage(previous,chart,options.values)&&sameOverride(previous,override))settled=previous.settledResult;
        else {
            Engine closed=new Engine(chart,options.values,previous,false,options.render,override,options.labelAtrOverride);
            settled=closed.run();
        }
        if(options.includeForming&&chart.formingBar!=null){
            Engine live=new Engine(chart,options.values,settled.state,true,options.render,override,options.labelAtrOverride);
            return live.run(settled.state);
        }
        return settled;
    }
    private static <T> List<T> immutable(List<T> values){
        return Collections.unmodifiableList(new ArrayList<T>(values));
    }
    public static boolean same(Pivot a,Pivot b){
        return a!=null&&b!=null&&a.b==b.b&&a.p==b.p&&a.hi==b.hi;
    }
    private static Pattern empty(){
        return new Pattern(Collections.<Pivot>emptyList(),-1);
    }
    static double fit(double ratio,double target){
        return ratio>0&&target>0?Math.exp(-Math.abs(Math.log(ratio/target))*2):0;
    }
    static double bestFit(double ratio,double... targets){
        double best=0;
        for(double target:targets)best=Math.max(best,fit(ratio,target));
        return best;
    }
    static boolean geometry(double[] x,int legs,int kind,int d,double eps){
        boolean ok=true;
        for(int j=1;j<=legs;j++)if((j%2==1?d:-d)*(x[j]-x[j-1])<=eps)ok=false;
        if(ok&&kind==1){
            if(legs>=2&&d*(x[2]-x[0])<=eps)ok=false;
            if(legs>=3&&d*(x[3]-x[1])<=eps)ok=false;
            if(legs>=4&&d*(x[4]-x[1])<=eps)ok=false;
            if(legs>=5){
                double one=Math.abs(x[1]-x[0]),three=Math.abs(x[3]-x[2]),five=Math.abs(x[5]-x[4]);
                if(d*(x[5]-x[3])<=eps||three+eps<Math.min(one,five))ok=false;
            }
        }
        else if(ok&&legs>=3){
            double origin=d*(x[2]-x[0]),finish=d*(x[3]-x[1]);
            ok=kind==4?origin>eps&&finish>eps:kind==5?origin>=-eps&&finish>eps:kind==6?origin< -eps&&finish>eps:kind==7&&origin< -eps&&finish< -eps&&d*(x[3]-x[0])>eps;
        }
        return ok;
    }
    static double score(double[] x,int legs,int kind){
        double a=Math.abs(x[1]-x[0]),sum=0;
        int terms=0;
        if(a>0&&kind==1){
            if(legs>=2){
                sum+=bestFit(Math.abs(x[2]-x[1])/a,.5,.618,.786,.886);
                terms++;
            }
            if(legs>=3){
                sum+=bestFit(Math.abs(x[3]-x[2])/a,1,1.618,2,2.618,3);
                terms++;
            }
            if(legs>=4){
                sum+=bestFit(Math.abs(x[4]-x[3])/Math.abs(x[3]-x[2]),.236,.382);
                terms++;
            }
            if(legs>=5){
                double five=Math.abs(x[5]-x[4]);
                sum+=Math.max(bestFit(five/Math.abs(x[4]-x[3]),1.236,1.618),bestFit(five/Math.abs(x[3]-x[2]),.5,.618,1));
                terms++;
            }
        }
        else if(a>0){
            if(legs>=2){
                double ratio=Math.abs(x[2]-x[1])/a;
                sum+=kind==4?bestFit(ratio,.382,.5,.618):bestFit(ratio,.9,1,1.13);
                terms++;
            }
            if(legs>=3){
                sum+=bestFit(Math.abs(x[3]-x[2])/a,.786,1,1.236,1.618);
                terms++;
            }
        }
        return terms>0?sum/terms:0;
    }
    private static final class RangeCache {
        final int base,n;
        final int[] logs,bad;
        final double[][] highs,lows,maxMacd,minMacd;
        RangeCache(List<Candle> bars){
            base=bars.get(0).b;
            n=bars.size();
            logs=new int[n+1];
            for(int i=2;i<=n;i++)logs[i]=logs[i/2]+1;
            int levels=logs[n]+1;
            highs=new double[levels][n];
            lows=new double[levels][n];
            maxMacd=new double[levels][n];
            minMacd=new double[levels][n];
            bad=new int[n+1];
            for(int i=0;i<n;i++){
                Candle c=bars.get(i);
                highs[0][i]=c.h;
                lows[0][i]=c.l;
                maxMacd[0][i]=minMacd[0][i]=c.m;
                bad[i+1]=bad[i]+(Double.isNaN(c.m)?1:0);
            }
            for(int k=1;k<levels;k++){
                int half=1<<(k-1),length=half*2;
                for(int i=0;i<=n-length;i++){
                    highs[k][i]=Math.max(highs[k-1][i],highs[k-1][i+half]);
                    lows[k][i]=Math.min(lows[k-1][i],lows[k-1][i+half]);
                    maxMacd[k][i]=Math.max(maxMacd[k-1][i],maxMacd[k-1][i+half]);
                    minMacd[k][i]=Math.min(minMacd[k-1][i],minMacd[k-1][i+half]);
                }
            }
        }
        double range(int from,int finish,int mode){
            int a=from-base,b=finish-base;
            if(a<0||b>=n||a>b)return Double.NaN;
            int k=logs[b-a+1],end=b-(1<<k)+1;
            double[][] data=mode==1?highs:mode== -1?lows:mode==2?maxMacd:minMacd;
            double out=mode>0?Math.max(data[k][a],data[k][end]):Math.min(data[k][a],data[k][end]);
            return Math.abs(mode)==2&&bad[b+1]!=bad[a]?Double.NaN:out;
        }
        boolean inside(Pivot a,Pivot b,double lo,double hi,double eps){
            boolean ok=a.b>=base&&b.b<base+n&&a.b<b.b;
            if(ok&&b.b>a.b+1){
                double l=range(a.b+1,b.b-1,-1),h=range(a.b+1,b.b-1,1);
                ok=finite(l)&&finite(h)&&l>=lo-eps&&h<=hi+eps;
            }
            return ok;
        }
        boolean adverse(Pivot a,Pivot b,int direction,double level,double eps){
            boolean ok=a.b>=base&&b.b<base+n&&a.b<b.b;
            if(ok&&b.b>a.b+1){
                double value=range(a.b+1,b.b-1,direction>0?-1:1);
                ok=finite(value)&&(direction>0?value>level+eps:value<level-eps);
            }
            return ok;
        }
    }
    private static final class Engine {
        final ChartData chart;
        final Map<String,String> v;
        final boolean provisional,render,overridden;
        final List<ChartData.Bar> all;
        final List<Candle> candles=new ArrayList<Candle>();
        final List<Pivot> major=new ArrayList<Pivot>(),minor=new ArrayList<Pivot>(),micro=new ArrayList<Pivot>();
        final List<Count> confirmed=new ArrayList<Count>(),counts=new ArrayList<Count>();
        final List<ImpulseAnchor> anchors=new ArrayList<ImpulseAnchor>();
        final List<ExtensionSpan> spans=new ArrayList<ExtensionSpan>();
        final List<DivLink> links=new ArrayList<DivLink>();
        final List<HiddenDivLink> hidden=new ArrayList<HiddenDivLink>();
        final double[] macd,signal,histogram,atr;
        final double tick,eps,labelAtrOverride;
        final int limit,history,lastBar;
        int work;
        RangeCache cache;
        String status="Child: awaiting a confirmed swing";
        final boolean showMicro,showDeveloping;
        Engine(ChartData chart,Map<String,String> values,State previous,boolean provisional,boolean render,double[] override,double labelAtrOverride){
            this.chart=chart;
            v=values;
            this.provisional=provisional;
            this.render=render;
            all=provisional?chart.allBars():chart.closedBars;
            lastBar=all.size()-1;
            this.labelAtrOverride=labelAtrOverride;
            overridden=override!=null;
            tick=finite(chart.tickSize)&&chart.tickSize>0?chart.tickSize:chart.point;
            eps=tick*.1;
            limit=i("workLimit");
            history=i("historyBars");
            showMicro=b("showMicro");
            showDeveloping=b("showDeveloping");
            if(d("deviation")/(d("factor")*d("factor"))<.00001)throw new IllegalArgumentException("Child/micro deviation must be at least 0.00001%. Increase large deviation or reduce the divisor.");
            if(i("hiddenMaxBars")<i("hiddenMinBars"))throw new IllegalArgumentException("Hidden divergence maximum bars must be at least the minimum bars.");
            macd=new double[all.size()];
            signal=new double[all.size()];
            histogram=new double[all.size()];
            atr=new double[all.size()];
            indicators();
            if(override!=null)for(int at=0;at<macd.length;at++){
                macd[at]=override[at];
                signal[at]=at==0?macd[at]:.2*macd[at]+.8*signal[at-1];
                histogram[at]=macd[at]-signal[at];
            }
            // Pine admits bar_index >= last_bar_index-historyBars, then shifts
            // after admission. Replaying the initial extra bar preserves the
            // very first pivot's older/newer tie comparisons at the window edge.
            int from=Math.max(0,(chart.formingBar==null?chart.closedBars.size()-1:chart.closedBars.size())-history);
            boolean carry=previous!=null&&sameLineage(previous,chart,values)&&sameMacd(previous,macd);
            if(carry){
                candles.addAll(previous.candles);
                major.addAll(previous.major);
                minor.addAll(previous.minor);
                micro.addAll(previous.micro);
                confirmed.addAll(previous.confirmedCounts);
                anchors.addAll(previous.anchors);
                spans.addAll(previous.spans);
                from=previous.chart.closedBars.size();
            }
            for(int at=from;at<all.size();at++){
                candles.add(new Candle(at,all.get(at),macd[at]));
                if(candles.size()>history)candles.remove(0);
                update(major,d("deviation"),i("depth"));
                update(minor,d("deviation")/d("factor"),i("childDepth"));
                update(micro,d("deviation")/(d("factor")*d("factor")),2);
                if(carry&&!provisional&&at<all.size()-1)refreshCounts();
            }
        }
        boolean b(String key){
            return Boolean.parseBoolean(v.get(key));
        }
        int i(String key){
            return Integer.parseInt(v.get(key));
        }
        double d(String key){
            return Double.parseDouble(v.get(key));
        }
        int color(String key){
            return net.metaquotes.metatrader5.modules.api.InputDefinition.parseColor(v.get(key));
        }
        void indicators(){
            double fast=Double.NaN,slow=Double.NaN,sig=Double.NaN,rma=Double.NaN,seed=0;
            for(int k=0;k<all.size();k++){
                ChartData.Bar bar=all.get(k);
                fast=k==0?bar.close:2.0/13*bar.close+(1-2.0/13)*fast;
                slow=k==0?bar.close:2.0/27*bar.close+(1-2.0/27)*slow;
                macd[k]=fast-slow;
                sig=k==0?macd[k]:.2*macd[k]+.8*sig;
                signal[k]=sig;
                histogram[k]=macd[k]-sig;
                double tr=k==0?bar.high-bar.low:Math.max(bar.high-bar.low,Math.max(Math.abs(bar.high-all.get(k-1).close),Math.abs(bar.low-all.get(k-1).close)));
                if(k<14){
                    seed+=tr;
                    if(k==13)rma=seed/14;
                }
                else rma=(rma*13+tr)/14;
                atr[k]=rma;
            }
        }
        Pivot findPivot(int radius,boolean hi){
            int n=candles.size();
            if(n<radius*2+1)return null;
            int center=n-1-radius;
            Candle c=candles.get(center);
            double price=hi?c.h:c.l;
            for(int j=center+1;j<n;j++){
                Candle x=candles.get(j);
                if(hi?x.h>price:x.l<price)return null;
            }
            for(int j=center-radius;j<center;j++){
                Candle x=candles.get(j);
                if(hi?x.h>=price:x.l<=price)return null;
            }
            return new Pivot(c.b,c.t,price,hi,candles.get(n-1).b);
        }
        boolean register(List<Pivot> stream,Pivot p,double dev){
            if(p==null)return false;
            int n=stream.size();
            if(n==0){
                stream.add(p);
                return true;
            }
            Pivot last=stream.get(n-1);
            if(last.hi==p.hi){
                if(last.hi?p.p>last.p:p.p<last.p){
                    stream.set(n-1,p);
                    return true;
                }
            }
            else if(last.p!=0){
                double move=100*(p.p-last.p)/Math.abs(last.p);
                if(!last.hi&&move>=dev||last.hi&&move<= -dev){
                    stream.add(p);
                    return true;
                }
            }
            return false;
        }
        void update(List<Pivot> stream,double dev,int legs){
            int radius=Math.max(2,(int)Math.floor(legs/2.0));
            register(stream,findPivot(radius,true),dev);
            register(stream,findPivot(radius,false),dev);
            int oldest=candles.get(0).b;
            while(!stream.isEmpty()&&stream.get(0).b<oldest)stream.remove(0);
        }
        boolean known(Pivot p){
            if(p==null||candles.isEmpty())return false;
            int idx=p.b-candles.get(0).b;
            if(idx<0||idx>=candles.size())return false;
            Candle c=candles.get(idx);
            return p.known>p.b&&p.known<=candles.get(candles.size()-1).b&&c.t==p.t&&p.p==(p.hi?c.h:c.l);
        }
        boolean settled(Pivot p,int degree){
            List<Pivot> stream=degree==0?major:degree==1?minor:micro;
            if(known(p))for(int j=stream.size()-1;j>=0;j--){
                Pivot next=stream.get(j);
                if(next.b<=p.b)break;
                if(next.hi!=p.hi)return true;
            }
            return false;
        }
        void prepareCounts(){
            for(int j=confirmed.size()-1;j>=0;j--){
                Count c=confirmed.get(j);
                if(!known(c.pivot))confirmed.remove(j);
                else counts.add(new Count(c.pivot,c.degree,c.waveName));
            }
            for(int j=anchors.size()-1;j>=0;j--){
                ImpulseAnchor a=anchors.get(j);
                if(a.developing||!known(a.origin)||!known(a.three))anchors.remove(j);
            }
            for(int j=spans.size()-1;j>=0;j--){
                ExtensionSpan s=spans.get(j);
                if(!s.proved||!known(s.two)||!known(s.three))spans.remove(j);
            }
        }
        void rememberCounts(){
            confirmed.clear();
            for(Count c:counts)if(!c.waveName.contains("?")&&settled(c.pivot,c.degree))confirmed.add(new Count(c.pivot,c.degree,c.waveName));
        }
        void keep(List<Path> pool,Path candidate){
            if(pool.size()<24)pool.add(candidate);
            else{
                int worst=0;
                for(int j=1;j<pool.size();j++)if(pool.get(j).fit<pool.get(worst).fit)worst=j;
                if(candidate.fit>pool.get(worst).fit)pool.set(worst,candidate);
            }
        }
        // f_search: exactly 24 retained paths; strict first-best tie selection.
        // Every candidate edge spends work before validation. A spent budget
        // leaves the structure unresolved rather than inventing a count.
        Pattern search(List<Pivot> points,int legs,int kind){
            int n=points.size();
            if(n<legs+1||n>256||legs<2||legs>5||work>=limit)return empty();
            Pivot origin=points.get(0);
            int direction=origin.hi?-1:1,end=n-1;
            Pivot finish=points.get(end);
            for(int j=1;j<=end;j++)if(points.get(j).b<=points.get(j-1).b)return empty();
            if(finish.hi!=(legs%2==1?direction==1:direction== -1))return empty();
            List<Path> pool=new ArrayList<Path>();
            pool.add(new Path(new int[6],0));
            int done=0;
            for(int stage=1;stage<=legs;stage++){
                List<Path> next=new ArrayList<Path>();
                for(Path previous:pool){
                    int a=previous.at[stage-1],move=stage%2==1?direction:-direction,first=stage==legs?end:a+1,last=stage==legs?end:end-(legs-stage);
                    if(first<=last)for(int pos=first;pos<=last;pos++){
                        if(++work>limit)break;
                        Pivot pa=points.get(a),pb=points.get(pos);
                        if(pb.hi!=(move==1)||move*(pb.p-pa.p)<=eps)continue;
                        boolean motiveRole=kind==1?stage%2==1:kind==4?stage!=2:stage==3;
                        if(motiveRole&&!cache.inside(pa,pb,Math.min(pa.p,pb.p),Math.max(pa.p,pb.p),eps))continue;
                        int[] at=previous.at.clone();
                        at[stage]=pos;
                        double[] prices=new double[stage+1];
                        for(int k=0;k<=stage;k++)prices[k]=points.get(at[k]).p;
                        if(!geometry(prices,stage,kind,direction,eps))continue;
                        if(kind==1&&stage==2&&!cache.adverse(pa,pb,direction,prices[0],eps))continue;
                        if(kind==1&&stage==4&&!cache.adverse(pa,pb,direction,prices[1],eps))continue;
                        keep(next,new Path(at,score(prices,stage,kind)));
                    }
                    if(work>limit)break;
                }
                if(next.isEmpty()||work>limit)break;
                pool=next;
                done=stage;
            }
            if(done!=legs)return empty();
            int best=0;
            for(int j=1;j<pool.size();j++)if(pool.get(j).fit>pool.get(best).fit)best=j;
            List<Pivot> selected=new ArrayList<Pivot>();
            for(int j=0;j<=legs;j++)selected.add(points.get(pool.get(best).at[j]));
            return new Pattern(selected,pool.get(best).fit);
        }
        boolean append(List<Pivot> points,Pivot p){
            int n=points.size();
            if(n==0){
                points.add(p);
                return true;
            }
            Pivot last=points.get(n-1);
            if(p.b<=last.b)return false;
            if(p.hi==last.hi){
                if(n>1&&(p.hi?p.p>last.p:p.p<last.p))points.set(n-1,p);
            }
            else if(n>=256)return false;
            else points.add(p);
            return true;
        }
        List<Pivot> collect(List<Pivot> stream,Pivot start,Pivot finish,boolean fixed){
            List<Pivot> points=new ArrayList<Pivot>();
            boolean ok=known(start)&&(!fixed||known(finish)&&finish.b>start.b);
            if(ok){
                points.add(start);
                for(Pivot p:stream){
                    if(p.b<=start.b||fixed&&p.b>=finish.b)continue;
                    if(!known(p)||!append(points,p)){
                        ok=false;
                        break;
                    }
                }
                if(ok&&fixed){
                    int n=points.size();
                    if(n>1&&points.get(n-1).hi==finish.hi)points.set(n-1,finish);
                    else ok=append(points,finish);
                }
            }
            if(!ok||points.size()<2)points.clear();
            return points;
        }
        Pattern correction(List<Pivot> points,int legs){
            Pattern best=empty();
            for(int kind=4;kind<=7;kind++){
                Pattern candidate=search(points,legs,kind);
                if(candidate.fit>best.fit)best=candidate;
            }
            return best;
        }
        Pattern proof(List<Pivot> finer,Pivot start,Pivot finish,boolean motive){
            if(start.hi==finish.hi)return empty();
            List<Pivot> points=collect(finer,start,finish,true);
            return motive?search(points,5,1):correction(points,3);
        }
        boolean divergence(List<Pivot> p){
            if(p.size()!=6)return false;
            Pivot two=p.get(2),three=p.get(3),four=p.get(4),five=p.get(5);
            boolean up=!p.get(0).hi;
            double m3=cache.range(two.b,three.b,up?2:-2),m5=cache.range(four.b,five.b,up?2:-2);
            return four.b>three.b&&three.hi==five.hi&&finite(m3)&&finite(m5)&&(up?five.p>three.p&&m5<m3:five.p<three.p&&m5>m3);
        }
        void addCount(List<Count> out,Pivot p,int degree,String name){
            boolean exists=false,developing=name.contains("?");
            for(int j=out.size()-1;j>=0;j--){
                Count c=out.get(j);
                if(c.degree==degree&&same(c.pivot,p)){
                    boolean old=c.waveName.contains("?");
                    if(!developing&&old)out.remove(j);
                    else if(!old||c.waveName.equals(name))exists=true;
                }
            }
            if(!exists)out.add(new Count(p,degree,name));
        }
        boolean counted(List<Count> out,Pivot p,int degree){
            for(Count c:out)if(c.degree==degree&&same(c.pivot,p)&&!c.waveName.contains("?"))return true;
            return false;
        }
        boolean extendedThree(List<Pivot> points){
            if(points.size()<4)return false;
            double one=Math.abs(points.get(1).p-points.get(0).p),three=Math.abs(points.get(3).p-points.get(2).p);
            return one>eps&&three>=2.618*one;
        }
        void removeThree(List<Count> out,Pivot p,int degree){
            for(int j=out.size()-1;j>=0;j--){
                Count c=out.get(j);
                if(c.degree==degree&&same(c.pivot,p)&&(c.waveName.equals("3")||c.waveName.equals("3?")))out.remove(j);
            }
        }
        boolean conflicting(List<Count> out,Pivot p,int degree,String name){
            for(Count c:out)if(c.degree==degree&&same(c.pivot,p)&&!c.waveName.contains("?")&&!c.waveName.equals(name))return true;
            return false;
        }
        // Only a matching real origin/1/2 owns an extended third. Finer proof
        // may move it; unrelated settled counts cannot be relabelled.
        int recordThree(List<Pivot> points,int degree,boolean developing,boolean provedThird){
            int accepted=1;
            if(points.size()<4)return accepted;
            Pivot origin=points.get(0),one=points.get(1),two=points.get(2),three=points.get(3);
            boolean extended=extendedThree(points),conflict=conflicting(counts,one,degree,"1")||conflicting(counts,two,degree,"2");
            int found=-1;
            for(int j=0;j<anchors.size();j++){
                ImpulseAnchor a=anchors.get(j);
                if(a.degree==degree&&same(a.origin,origin)&&same(a.one,one)&&same(a.two,two)){
                    found=j;
                    break;
                }
            }
            if(conflict)accepted=0;
            else if(found>=0){
                ImpulseAnchor prior=anchors.get(found);
                if(!same(prior.three,three)){
                    boolean further=three.b>prior.three.b&&(three.hi?three.p>prior.three.p:three.p<prior.three.p),provedExtension=extended&&(!developing||provedThird);
                    if(further&&extended&&developing&&!prior.developing&&degree==1&&!provedThird)provedExtension=proof(micro,two,three,true).fit>=0;
                    if(further&&(prior.developing||provedExtension)){
                        removeThree(counts,prior.three,degree);
                        removeThree(confirmed,prior.three,degree);
                        accepted=prior.developing?1:2;
                    }
                    else accepted=0;
                }
                else if(extended&&!prior.developing&&developing)accepted=2;
                if(accepted>0)anchors.set(found,new ImpulseAnchor(origin,one,two,three,degree,developing&&prior.developing));
            }
            else anchors.add(new ImpulseAnchor(origin,one,two,three,degree,developing));
            if(accepted>0&&extended){
                int spanIndex=-1;
                for(int j=0;j<spans.size();j++){
                    ExtensionSpan span=spans.get(j);
                    if(span.degree==degree&&same(span.two,two)){
                        spanIndex=j;
                        break;
                    }
                }
                ExtensionSpan span=new ExtensionSpan(two,three,degree,!developing||accepted==2);
                if(spanIndex>=0)spans.set(spanIndex,span);
                else spans.add(span);
            }
            return accepted;
        }
        boolean internalExtension(Pivot p,int degree,String name){
            for(ExtensionSpan span:spans){
                boolean outerThree=degree==span.degree&&same(p,span.three)&&(name.equals("3")||name.equals("3?"));
                if(p.b>span.two.b&&p.b<=span.three.b&&degree>=span.degree&&!outerThree)return true;
            }
            return false;
        }
        void filterExtensions(){
            for(int j=counts.size()-1;j>=0;j--){
                Count c=counts.get(j);
                if(internalExtension(c.pivot,c.degree,c.waveName))counts.remove(j);
            }
            for(int j=links.size()-1;j>=0;j--){
                DivLink link=links.get(j);
                for(ExtensionSpan span:spans)if(link.degree>=span.degree&&link.three.b>span.two.b&&link.five.b<=span.three.b){
                    links.remove(j);
                    break;
                }
            }
        }
        void emit(List<Pivot> points,int degree,boolean motive,boolean developing,boolean preserve){
            emit(points,degree,motive,developing,preserve,false);
        }
        void emit(List<Pivot> points,int degree,boolean motive,boolean developing,boolean preserve,boolean provedThird){
            int n=points.size();
            if(n<=1)return;
            int accepted=motive?recordThree(points,degree,developing,provedThird):1;
            if(accepted>0&&motive&&!developing&&divergence(points)){
                Pivot three=points.get(3),five=points.get(5);
                boolean exists=false;
                for(DivLink l:links)if(l.degree==degree&&same(l.three,three)&&same(l.five,five)){
                    exists=true;
                    break;
                }
                if(!exists)links.add(new DivLink(three,five,degree));
            }
            for(int j=1;j<n;j++){
                Pivot p=points.get(j);
                boolean extensionThree=motive&&j==3&&extendedThree(points);
                if(accepted==0||developing&&!showDeveloping&&!(j==3&&accepted==2)||preserve&&!extensionThree&&counted(counts,p,degree))continue;
                String name=motive?Integer.toString(j):j==1?"A":j==2?"B":"C";
                name+=developing&&!(j==3&&accepted==2)?"?":"";
                if(extensionThree&&!counted(counts,p,degree))addCount(counts,p,degree,name);
                else if(extensionThree){
                    if(!name.contains("?"))for(int k=counts.size()-1;k>=0;k--){
                        Count c=counts.get(k);
                        if(c.degree==degree&&same(c.pivot,p)&&c.waveName.contains("?"))counts.remove(k);
                    }
                    boolean exists=false;
                    for(Count c:counts)if(c.degree==degree&&same(c.pivot,p)&&(c.waveName.equals("3")||c.waveName.equals(name))){
                        exists=true;
                        break;
                    }
                    if(!exists)counts.add(new Count(p,degree,name));
                }
                else addCount(counts,p,degree,name);
            }
        }
        void nested(List<Pivot> points){
            if(!showMicro||points.size()<2)return;
            for(int leg=1;leg<points.size();leg++){
                if(leg==3&&extendedThree(points))continue;
                Pivot start=points.get(leg-1),finish=points.get(leg);
                Pattern five=proof(micro,start,finish,true);
                if(five.fit>=0)emit(five.points,2,true,false,false);
                else{
                    Pattern abc=proof(micro,start,finish,false);
                    if(abc.fit>=0)emit(abc.points,2,false,false,false);
                }
            }
        }
        Pattern firstComplete(List<Pivot> points,boolean motive){
            int legs=motive?5:3;
            if(points.size()>=legs+1)for(int finish=legs;finish<points.size();finish++){
                if(points.get(finish).hi==points.get(0).hi)continue;
                List<Pivot> prefix=new ArrayList<Pivot>(points.subList(0,finish+1));
                Pattern candidate=motive?search(prefix,5,1):correction(prefix,3);
                if(candidate.fit>=0)return candidate;
                if(work>limit)break;
            }
            return empty();
        }
        Pattern partial(List<Pivot> points,boolean motive){
            int n=points.size(),legs=Math.min(motive?4:2,n-1);
            while(legs>=2){
                Pattern candidate=motive?search(points,legs,1):correction(points,legs);
                if(candidate.fit>=0)return candidate;
                legs--;
            }
            if(n==2){
                Pivot a=points.get(0),b=points.get(1);
                int direction=a.hi?-1:1;
                if(a.hi!=b.hi&&direction*(b.p-a.p)>eps&&(!motive||cache.inside(a,b,Math.min(a.p,b.p),Math.max(a.p,b.p),eps)))return new Pattern(new ArrayList<Pivot>(points),0);
            }
            return empty();
        }
        Pattern lockedExtension(List<Pivot> points,int degree){
            if(degree!=1||points.size()<4||anchors.isEmpty()||work>=limit)return empty();
            Pivot origin=points.get(0),last=points.get(points.size()-1);
            for(int j=anchors.size()-1;j>=Math.max(0,anchors.size()-128);j--){
                ImpulseAnchor anchor=anchors.get(j);
                if(anchor.degree!=degree||!same(anchor.origin,origin))continue;
                Pivot three=anchor.three;
                for(int k=1;k<points.size();k++){
                    Pivot p=points.get(k);
                    if(p.b>anchor.three.b&&p.hi==three.hi&&(three.hi?p.p>three.p:p.p<three.p))three=p;
                }
                if(same(three,anchor.three))continue;
                List<Pivot> candidate=new ArrayList<Pivot>(Arrays.asList(origin,anchor.one,anchor.two,three));
                double[] prices={
                    origin.p,anchor.one.p,anchor.two.p,three.p,last.p
                };
                int direction=origin.hi?-1:1;
                if(!extendedThree(candidate)||!geometry(prices,3,1,direction,eps)||!cache.inside(anchor.two,three,Math.min(anchor.two.p,three.p),Math.max(anchor.two.p,three.p),eps))continue;
                Pattern proof=proof(micro,anchor.two,three,true);
                if(proof.fit<0){
                    if(work>=limit)break;
                    continue;
                }
                if(last.b>three.b&&last.hi!=three.hi&&geometry(prices,4,1,direction,eps)&&cache.adverse(three,last,direction,anchor.one.p,eps))candidate.add(last);
                return new Pattern(candidate,proof.fit);
            }
            return empty();
        }
        Pattern firstRealEndpoint(Pivot start,int last,boolean motive){
            for(Pivot endpoint:minor){
                if(endpoint.b<=start.b||endpoint.b>last||endpoint.hi==start.hi)continue;
                Pattern candidate=proof(minor,start,endpoint,motive);
                if(candidate.fit>=0)return candidate;
                if(work>limit)break;
            }
            return empty();
        }
        boolean sequential(Pivot start,Pivot finish,boolean fixed){
            boolean havePair=false;
            Pivot anchor=start;
            List<Pattern> selected=new ArrayList<Pattern>();
            List<Boolean> motives=new ArrayList<Boolean>();
            int last=fixed?finish.b:candles.get(candles.size()-1).b;
            for(int cycle=0;cycle<=3;cycle++){
                Pattern five=firstRealEndpoint(anchor,last,true);
                if(five.fit<0)break;
                Pivot afterFive=five.points.get(5);
                Pattern abc=firstRealEndpoint(afterFive,last,false);
                if(abc.fit<0&&!havePair)break;
                selected.add(five);
                motives.add(true);
                if(abc.fit<0)break;
                selected.add(abc);
                motives.add(false);
                havePair=true;
                anchor=abc.points.get(3);
                if(fixed&&anchor.b>=finish.b)break;
            }
            if(havePair&&!selected.isEmpty())for(int j=0;j<selected.size();j++){
                Pattern p=selected.get(j);
                emit(p.points,1,motives.get(j),false,false);
                nested(p.points);
            }
            return havePair;
        }
        void continueCount(List<Pivot> finer,Pivot start,Pivot finish,boolean fixed,int degree){
            Pivot anchor=start;
            boolean motive=true;
            int last=fixed?finish.b:candles.get(candles.size()-1).b;
            for(Count c:counts)if(c.degree==degree&&c.pivot.b>anchor.b&&c.pivot.b<=last&&(c.waveName.equals("5")||c.waveName.equals("C"))&&!internalExtension(c.pivot,c.degree,c.waveName)){
                anchor=c.pivot;
                motive=c.waveName.equals("C");
            }
            if(fixed&&anchor.b>=finish.b)return;
            for(int cycle=0;cycle<=11;cycle++){
                List<Pivot> points=collect(finer,anchor,finish,fixed);
                if(points.size()<2)break;
                Pattern extended=motive?lockedExtension(points,degree):empty();
                if(extended.fit>=0){
                    emit(extended.points,degree,true,true,true,true);
                    break;
                }
                Pattern full=firstComplete(points,motive);
                if(full.fit>=0){
                    emit(full.points,degree,motive,false,true);
                    Pivot next=full.points.get(full.points.size()-1);
                    if(next.b<=anchor.b)break;
                    anchor=next;
                    motive=!motive;
                    if(fixed&&anchor.b>=finish.b)break;
                }
                else{
                    Pattern partial=partial(points,motive);
                    if(partial.fit>=0&&showDeveloping&&(!fixed||!settled(finish,degree-1)))emit(partial.points,degree,motive,true,true);
                    break;
                }
            }
        }
        void analysis(){
            int m=major.size();
            if(m==0)return;
            int first=Math.max(1,m-12);
            List<Pattern> fiveCache=new ArrayList<Pattern>();
            for(int j=0;j<m;j++)fiveCache.add(empty());
            for(int j=first;j<=m-1;j++){
                Pivot start=major.get(j-1),finish=major.get(j);
                Pattern five=proof(minor,start,finish,true);
                fiveCache.set(j,five);
                Pattern abc=proof(minor,start,finish,false);
                Pattern extended=five.fit>=0&&extendedThree(five.points)?five:lockedExtension(collect(minor,start,finish,true),1);
                boolean sequential=extended.fit<0&&sequential(start,finish,true);
                if(extended.fit>=0){
                    emit(extended.points,1,true,extended.points.size()<6,false,true);
                    nested(extended.points);
                }
                else if(five.fit>=0){
                    if(!sequential){
                        emit(five.points,1,true,false,false);
                        nested(five.points);
                    }
                }
                else if(abc.fit>=0&&!sequential){
                    emit(abc.points,1,false,false,false);
                    nested(abc.points);
                }
            }
            for(int j=first;j<=m-4;j++){
                if(fiveCache.get(j).fit<0)continue;
                Pattern abc=correction(new ArrayList<Pivot>(major.subList(j,j+4)),3);
                if(abc.fit<0)continue;
                emit(abc.points,0,false,false,false);
                if(j+4<m)addCount(counts,major.get(j+4),0,"D");
            }
            Pivot origin=major.get(m-1);
            List<Pivot> active=collect(minor,origin,null,false);
            Pattern five=search(active,5,1);
            Pattern extended=five.fit>=0&&extendedThree(five.points)?five:lockedExtension(active,1);
            boolean sequential=extended.fit<0&&sequential(origin,null,false);
            if(extended.fit>=0){
                emit(extended.points,1,true,extended.points.size()<6,false,true);
                nested(extended.points);
            }
            else if(!sequential){
                if(five.fit>=0){
                    emit(five.points,1,true,false,false);
                    nested(five.points);
                }
                else{
                    Pattern abc=correction(active,3);
                    if(abc.fit>=0){
                        emit(abc.points,1,false,false,false);
                        nested(abc.points);
                    }
                    if(showDeveloping&&active.size()>=3){
                        Pattern partial=partial(active,true);
                        if(partial.fit>=0){
                            emit(partial.points,1,true,true,false);
                            nested(partial.points);
                        }
                    }
                }
            }
            for(int j=first;j<=m-1;j++)continueCount(minor,major.get(j-1),major.get(j),true,1);
            continueCount(minor,origin,null,false,1);
            int mn=minor.size(),childFirst=Math.max(1,mn-48),visibleStart=major.get(Math.max(0,m-13)).b;
            if(showMicro&&childFirst<=mn-1)for(int j=childFirst;j<=mn-1;j++)if(minor.get(j-1).b>=visibleStart)continueCount(micro,minor.get(j-1),minor.get(j),true,2);
            if(showMicro&&mn>0&&minor.get(mn-1).b>=visibleStart)continueCount(micro,minor.get(mn-1),null,false,2);
        }
        void hiddenDegree(List<Pivot> stream,int degree){
            int n=stream.size();
            int[] bars=new int[n];
            Arrays.fill(bars,-1);
            double[] values=new double[n];
            Arrays.fill(values,Double.NaN);
            boolean extremes=b("hiddenUseSwingExtremes");
            for(int j=0;j<n;j++){
                Pivot p=stream.get(j);
                int left=p.b;
                boolean valid=p.b>=cache.base&&p.b<cache.base+cache.n;
                if(extremes){
                    if(j==0)valid=false;
                    else{
                        left=stream.get(j-1).b;
                        valid=valid&&left>=cache.base&&left<=p.b;
                    }
                }
                if(valid){
                    double value=cache.range(left,p.b,p.hi?2:-2);
                    values[j]=value;
                    if(finite(value))for(int pos=p.b;pos>=left;pos--)if(candles.get(pos-cache.base).m==value){
                        bars[j]=pos;
                        break;
                    }
                }
            }
            HiddenDivLink highChain=null,lowChain=null;
            for(int j=2;j<n;j++){
                Pivot previous=stream.get(j-2),current=stream.get(j);
                int oldOsc=bars[j-2],newOsc=bars[j];
                double oldValue=values[j-2],newValue=values[j];
                boolean valid=previous.hi==current.hi&&previous.b>=cache.base&&oldOsc>=0&&newOsc>=0&&newOsc>oldOsc&&current.known>current.b&&current.known<cache.base+cache.n,extended=false;
                HiddenDivLink chain=current.hi?highChain:lowChain;
                if(valid&&chain!=null){
                    boolean direction=current.hi?current.p<previous.p:current.p>previous.p;
                    int distance=current.b-chain.anchor.b;
                    if(chain.endpoint.b==previous.b&&direction&&distance>=i("hiddenMinBars")&&distance<=i("hiddenMaxBars")&&newOsc>chain.anchorOscBar&&hiddenMatch(current.hi,chain.anchor.p,current.p,chain.anchorMacd,newValue,b("hiddenSameSideOfZero"))){
                        HiddenDivLink replacement=new HiddenDivLink(chain.anchor,current,degree,chain.anchorOscBar,newOsc,chain.anchorMacd);
                        int at=hidden.indexOf(chain);
                        if(at>=0)hidden.set(at,replacement);
                        chain=replacement;
                        extended=true;
                    }
                }
                if(!extended){
                    chain=null;
                    int distance=current.b-previous.b;
                    if(valid&&distance>=i("hiddenMinBars")&&distance<=i("hiddenMaxBars")&&hiddenMatch(current.hi,previous.p,current.p,oldValue,newValue,b("hiddenSameSideOfZero"))){
                        chain=new HiddenDivLink(previous,current,degree,oldOsc,newOsc,oldValue);
                        hidden.add(chain);
                    }
                }
                if(current.hi)highChain=chain;
                else lowChain=chain;
            }
        }
        Result run(){
            return run(null);
        }
        // Also used for each newly closed bar in a coalesced host update, so
        // batched delivery has the same count commits as individual closes.
        void refreshCounts(){
            work=0;
            counts.clear();
            links.clear();
            hidden.clear();
            cache=new RangeCache(candles);
            prepareCounts();
            analysis();
            rememberCounts();
            filterExtensions();
        }
        Result run(State committed){
            if(candles.isEmpty())return new Result(this,new PlotFrame(),committed);
            refreshCounts();
            if(b("showHidden")){
                if(b("hiddenLarge"))hiddenDegree(major,0);
                if(b("hiddenChild"))hiddenDegree(minor,1);
                if(b("hiddenMicro"))hiddenDegree(micro,2);
            }
            PlotFrame frame=render?draw():new PlotFrame();
            return new Result(this,frame,committed);
        }
        PlotFrame draw(){
            Draw out=new Draw();
            int m=major.size(),mn=minor.size(),visibleFrom=m>0?major.get(Math.max(0,m-i("visibleMajor"))).b:lastBar;
            if(b("showZigzag")&&m>=2)for(int j=Math.max(1,m-i("visibleMajor")+1);j<m;j++)out.line(major.get(j-1),major.get(j),0xff1e90ff,2,3);
            if(b("showZigzag")&&mn>=2)for(int j=Math.max(1,mn-200);j<mn;j++)if(minor.get(j-1).b>=visibleFrom)out.line(minor.get(j-1),minor.get(j),0xff00ced1,1,2);
            List<Count> merged=new ArrayList<Count>();
            for(Count c:counts){
                if(c.pivot.b<visibleFrom||c.degree==2&&!showMicro)continue;
                int found=-1;
                for(int j=0;j<merged.size();j++){
                    Count prior=merged.get(j);
                    if(prior.degree==c.degree&&same(prior.pivot,c.pivot)){
                        found=j;
                        break;
                    }
                }
                if(found<0)merged.add(c);
                else{
                    Count prior=merged.get(found);
                    if(!(" / "+prior.waveName+" / ").contains(" / "+c.waveName+" / "))merged.set(found,new Count(prior.pivot,prior.degree,prior.waveName+" / "+c.waveName));
                }
            }
            double labelAtr=finite(labelAtrOverride)?labelAtrOverride:atr.length>0&&finite(atr[atr.length-1])?atr[atr.length-1]:tick*12;
            for(int j=Math.max(0,merged.size()-180);j<merged.size();j++){
                Count c=merged.get(j);
                int ink=color(c.degree==0?"largeWaveTextColor":c.degree==1?"childWaveTextColor":"microWaveTextColor");
                double offset=Math.max(tick,labelAtr/12)*(c.degree==0?4:c.degree==1?2:.6),price=c.pivot.hi?c.pivot.p+offset:c.pivot.p-offset-labelAtr*d("lowerWaveGap");
                out.label(c.pivot.t,price,c.waveName,ink,font(v.get(c.degree==2?"microFontSize":"waveFontSize")),c.pivot.hi?3:2);
            }
            for(int j=Math.max(0,links.size()-64);j<links.size();j++){
                DivLink link=links.get(j);
                if(link.three.b>=visibleFrom&&(link.degree!=2||showMicro))out.line(link.three,link.five,link.three.hi?0xffff6347:0xff32cd32,2,3);
            }
            if(b("showLargeFib")&&m>=2)out.fibonacci(major.get(m-2),major.get(m-1),color("largeFibColor"),color("largeFibTextColor"),v.get("largeFibFontSize"),v.get("largeFibTextAlignment"),true);
            if(b("showChildFib")&&mn>=2){
                int found=0,j=mn-1;
                while(j>=1&&found<i("childFibLegs")){
                    Pivot a=minor.get(j-1),end=minor.get(j);
                    if(a.b<visibleFrom)break;
                    if(out.fibonacci(a,end,color("childFibColor"),color("childFibTextColor"),v.get("childFibFontSize"),v.get("childFibTextAlignment"),found==0))found++;
                    j--;
                }
            }
            if(mn>=2){
                status="Latest child: structure unresolved";
                for(Count c:merged)if(c.degree==1&&same(c.pivot,minor.get(mn-1)))status="Latest child: "+c.waveName;
            }
            if(work>=limit)status="Search limit reached | some structures unresolved | "+status;
            List<HiddenDivLink> sorted=new ArrayList<HiddenDivLink>(hidden);
            Collections.sort(sorted,new Comparator<HiddenDivLink>(){
                public int compare(HiddenDivLink a,HiddenDivLink b){
                    long ka=((long)(a.endpoint.known-cache.base)*(cache.n+1)+a.endpointOscBar-cache.base)*3+a.degree,kb=((long)(b.endpoint.known-cache.base)*(cache.n+1)+b.endpointOscBar-cache.base)*3+b.degree;return Long.compare(kb,ka);
                }
            }
            );
            for(int j=0;j<Math.min(sorted.size(),i("hiddenMaxSignals"));j++){
                HiddenDivLink link=sorted.get(j);
                if(link.anchor.b<visibleFrom||link.endpoint.t<=link.anchor.t)continue;
                if(out.lines>=250)break;
                boolean bull=!link.endpoint.hi;
                int ink=color(bull?"hiddenBullColor":"hiddenBearColor");
                out.segment(link.anchor.t,link.anchor.p,link.endpoint.t,link.endpoint.p,ink,1,1);
                if(b("hiddenShowLabels")&&out.labels.size()<250){
                    String degree=link.degree==0?"Large":link.degree==1?"Child":"Micro",caption=(bull?"HBull":"HBear")+" ["+degree+"]";
                    double offset=Math.max(tick,labelAtr*(link.degree==0?.65:link.degree==1?.5:.35));
                    out.label(link.endpoint.t,link.endpoint.p+(bull?-offset:offset),caption,ink,8,bull?2:1);
                }
            }
            return out.finish();
        }
        private final class Draw {
            final PlotFrame frame=new PlotFrame();
            final List<Label> labels=new ArrayList<Label>();
            final List<FibSlot> slots=new ArrayList<FibSlot>();
            int lines;
            void segment(long a,double p,long b,double q,int ink,int width,int style){
                frame.line("zwcore_line_"+(lines++),0,a,p,b,q,ink,width,style);
            }
            void line(Pivot a,Pivot b,int ink,int width,int style){
                if(b.t>a.t&&lines<180)segment(a.t,a.p,b.t,b.p,ink,width,style);
            }
            Label label(long time,double price,String caption,int ink,int size,int anchor){
                Label l=new Label(time,price,caption,ink,size,anchor);
                labels.add(l);
                return l;
            }
            // Intentional host mapping: viewport-dependent Pine right/left
            // indices become the latest closed/first loaded real candle. Future
            // positions use a finite number of broker-period intervals, never
            // the pane edge; the two original Fibonacci prices stay unchanged.
            boolean fibonacci(Pivot a,Pivot b,int ink,int textInk,String size,String alignment,boolean latest){
                boolean ok=b.t>a.t&&a.hi!=b.hi&&Math.abs(a.p-b.p)>=tick*.5;
                if(!ok)return false;
                boolean left="Left".equals(alignment);
                int lineEnd=latest?Math.max(b.b,lastBar)+i("fibRightExtension"):b.b;
                int anchor=left?Math.max(a.b,0)+i("fibTextShift"):lineEnd+Math.max(1,i("fibTextShift"));
                boolean visible=anchor>=0&&anchor<=lastBar+i("fibRightExtension")+i("fibTextShift")&&anchor<=lineEnd+Math.max(1,i("fibTextShift"));
                double[] levels={
                    0,.236,.382,.5,.618,.707,.786,.886,1
                };
                for(double ratio:levels){
                    double price=b.p+(a.p-b.p)*ratio;
                    if(lines<220)segment(timeAt(a.b),price,timeAt(lineEnd),price,ink,i("fibLineWidth"),"Solid".equals(v.get("fibLineStyle"))?3:"Dashed".equals(v.get("fibLineStyle"))?1:2);
                    if(visible&&labels.size()<220){
                        FibSlot coincident=null;
                        for(FibSlot slot:slots)if(slot.anchor==anchor&&slot.left==left&&Math.abs(slot.price-price)<=tick*.5){
                            coincident=slot;
                            break;
                        }
                        String text=String.format(Locale.ROOT,"%.1f%%",ratio*100);
                        if(coincident!=null){
                            String prior=coincident.label.text;
                            if(!(" | "+prior+" | ").contains(" | "+text+" | "))coincident.label.text=prior+" | "+text;
                        }
                        else{
                            Label l=label(timeAt(anchor),price,text,textInk,font(size),left?3:4);
                            if(slots.size()<72)slots.add(new FibSlot(anchor,left,price,l));
                        }
                    }
                }
                return true;
            }
            PlotFrame finish(){
                for(int j=0;j<labels.size();j++){
                    Label l=labels.get(j);
                    frame.anchoredText("zwcore_label_"+j,0,l.time,l.price,l.text,l.ink,l.size,l.anchor,false);
                }
                return frame;
            }
        }
        long timeAt(int index){
            if(index>=0&&index<all.size())return all.get(index).time;
            long step=Math.max(1,chart.periodSeconds),last=all.get(all.size()-1).time,extra=(long)index-all.size()+1;
            if(extra<0||extra>(Long.MAX_VALUE-last)/step)throw new IllegalArgumentException("Zwave Core finite Fibonacci time exceeds range");
            return last+extra*step;
        }
    }
    private static final class Label {
        final long time;
        final double price;
        String text;
        final int ink,size,anchor;
        Label(long time,double price,String text,int ink,int size,int anchor){
            this.time=time;
            this.price=price;
            this.text=text;
            this.ink=ink;
            this.size=size;
            this.anchor=anchor;
        }
    }
    private static final class FibSlot {
        final int anchor;
        final boolean left;
        final double price;
        final Label label;
        FibSlot(int anchor,boolean left,double price,Label label){
            this.anchor=anchor;
            this.left=left;
            this.price=price;
            this.label=label;
        }
    }
    public static int font(String size){
        return "Tiny".equals(size)?8:"Small".equals(size)?10:"Normal".equals(size)?12:"Large".equals(size)?14:18;
    }
    public static boolean hiddenMatch(boolean high,double oldPrice,double newPrice,double oldMacd,double newMacd,boolean zeroFilter){
        boolean valid=finite(oldPrice)&&finite(newPrice)&&finite(oldMacd)&&finite(newMacd),side=!zeroFilter||(high?oldMacd>0&&newMacd>0:oldMacd<0&&newMacd<0);
        return valid&&side&&(high?newPrice<oldPrice&&newMacd>oldMacd:newPrice>oldPrice&&newMacd<oldMacd);
    }
    private static boolean sameOverride(State previous,double[] override){
        return override==null?!previous.overridden:previous.overridden&&sameMacd(previous,override);
    }
    private static boolean sameMacd(State previous,double[] values){
        for(Candle c:previous.candles)if(c.b>=values.length||Double.doubleToLongBits(c.m)!=Double.doubleToLongBits(values[c.b]))return false;
        return true;
    }
    private static boolean sameLineage(State previous,ChartData chart,Map<String,String> values){
        ChartData a=previous.chart;
        if(!previous.values.equals(values)||a.chartId!=chart.chartId||a.period!=chart.period||a.periodSeconds!=chart.periodSeconds||!a.server.equals(chart.server)||!a.symbol.equals(chart.symbol)||Double.doubleToLongBits(a.tickSize)!=Double.doubleToLongBits(chart.tickSize)||Double.doubleToLongBits(a.point)!=Double.doubleToLongBits(chart.point)||a.closedBars.size()>chart.closedBars.size())return false;
        for(int j=0;j<a.closedBars.size();j++)if(!sameBar(a.closedBars.get(j),chart.closedBars.get(j)))return false;
        return true;
    }
    private static boolean sameBar(ChartData.Bar a,ChartData.Bar b){
        return a==b||a.time==b.time&&a.open==b.open&&a.high==b.high&&a.low==b.low&&a.close==b.close&&a.tickVolume==b.tickVolume&&a.realVolume==b.realVolume;
    }
    private static boolean finite(double value){
        return !Double.isNaN(value)&&!Double.isInfinite(value);
    }
}
