// Zwave Core shadow correlation, © XoRonX | Mr Poleks. MPL-2.0.
// Pure broker-OHLC conversion of original.pine; no synthetic comparison feed.
package converted.zwavecore;
import java.util.*;
import net.metaquotes.metatrader5.modules.api.ChartData;
import net.metaquotes.metatrader5.modules.api.PlotFrame;
/** Time alignment precedes analysis; the affine transform is applied only to drawings. */
public final class ShadowEngine {
    private ShadowEngine(){
    }
    private static final String[] ROOTS={
        "NAS100CASH","NAS100USD","US100CASH","US100USD","SP500CASH","SPX500USD","SPX500","US500CASH","US500USD","NAS100","SP500","US100","US500","USTEC","SPXUSD","XAUUSD","XAGUSD","USDJPY","AUDUSD","NZDUSD","USDCAD","USDCHF","NDX","SPX","SNP"
    };
    private static final String[] CURRENCIES={
        "USD","EUR","GBP","JPY","CHF","CAD","AUD","NZD","XAU","XAG","CNH","CNY","SGD","HKD","NOK","SEK","ZAR","MXN"
    };
    private static String upper(String value){
        return value==null?"":value.toUpperCase(Locale.ROOT);
    }
    private static String plain(String value){
        int colon=value.lastIndexOf(':');
        return (colon<0?value:value.substring(colon+1)).trim();
    }
    private static String root(String symbol,String base,String profit){
        String metadata=upper(base)+upper(profit);
        for(String name:ROOTS)if(name.equals(metadata))return name;
        String name=upper(plain(symbol));
        for(String item:ROOTS)if(name.contains(item))return item;
        for(String future:new String[]{
            "6J","6A","6N","6C","6S"
        }
        )if(name.startsWith(future)||name.contains("."+future)||name.contains("_"+future))return future;
        return "";
    }
    private static String counterpart(String root){
        if(root.equals("XAUUSD"))return "XAGUSD";
        if(root.equals("XAGUSD"))return "XAUUSD";
        if(root.startsWith("NAS100")||root.startsWith("US100")||root.equals("USTEC")||root.equals("NDX"))return "US500";
        if(root.startsWith("US500")||root.startsWith("SP500")||root.startsWith("SPX")||root.equals("SNP"))return "NAS100";
        String[][] pairs={
            {
                "USDJPY","6J"
            },
            {
                "AUDUSD","6A"
            },
            {
                "NZDUSD","6N"
            },
            {
                "USDCAD","6C"
            },
            {
                "USDCHF","6S"
            }
        };
        for(String[] pair:pairs){
            if(root.equals(pair[0]))return pair[1]+"1!";
            if(root.equals(pair[1]))return pair[0];
        }
        return "";
    }
    private static boolean presetInverse(String root){
        return root.equals("USDJPY")||root.equals("USDCAD")||root.equals("USDCHF")||root.equals("6J")||root.equals("6C")||root.equals("6S");
    }
    private static String decorate(String chart,String chartRoot,String target){
        String name=plain(chart),caps=upper(name);
        int at=caps.indexOf(chartRoot);
        if(at<0)return target;
        int end=at+chartRoot.length();
        // A continuous/dated futures contract is not a broker suffix to copy to spot.
        if(chartRoot.startsWith("6")){
            String tail=caps.substring(end);
            if(tail.startsWith("1!"))end+=2;
            else{
                java.util.regex.Matcher match=java.util.regex.Pattern.compile("^[FGHJKMNQUVXZ][0-9]{1,4}").matcher(tail);
                if(match.find())end+=match.end();
            }
        }
        return name.substring(0,at)+target+name.substring(end);
    }
    public static String[] candidates(String primarySymbol,Map<String,String> v){
        return candidates(primarySymbol,"","",v);
    }
    public static String[] candidates(ChartData primary,Map<String,String> v){
        return candidates(primary.symbol,primary.currencyBase,primary.currencyProfit,v);
    }
    private static String[] candidates(String primary,String base,String profit,Map<String,String> v){
        LinkedHashSet<String> out=new LinkedHashSet<String>();
        String from=root(primary,base,profit);
        if("Manual".equals(v.get("shadowPairMode"))){
            String manual=v.get("shadowManualSymbol").trim(),target=plain(manual),targetRoot=root(target,"","");
            if(manual.indexOf(':')<0)out.add(manual);
            if(!targetRoot.isEmpty()&&target.equalsIgnoreCase(targetRoot)&&!from.isEmpty())out.add(decorate(primary,from,target));
            out.add(target);
            if(manual.indexOf(':')>=0)out.add(manual);
        }
        else{
            String target=counterpart(from);
            if(target.isEmpty())return new String[0];
            out.add(decorate(primary,from,target));
            out.add(target);
            if(target.endsWith("1!")){
                String brokerRoot=target.substring(0,target.length()-2);
                out.add(decorate(primary,from,brokerRoot));
                out.add(brokerRoot);
            }
            if(target.equals("NAS100")){
                out.add(decorate(primary,from,"US100"));
                out.add("US100");
            }
            if(target.equals("US500")){
                for(String alias:new String[]{
                    "SP500","SPX500"
                }
                ){
                    out.add(decorate(primary,from,alias));
                    out.add(alias);
                }
            }
        }
        out.remove("");
        return out.toArray(new String[out.size()]);
    }
    /** Resolves only names actually present in the supplied broker inventory. */
    public static String select(ChartData primary,Map<String,String> v,List<String> available){
        for(String wanted:candidates(primary,v))for(String actual:available)if(wanted.equalsIgnoreCase(actual))return actual;
        return "";
    }
    private static String[] currencies(ChartData chart){
        String base=upper(chart.currencyBase),profit=upper(chart.currencyProfit);
        if(!base.isEmpty()&&!profit.isEmpty())return new String[]{
            base,profit
        };
        String name=upper(plain(chart.symbol));
        for(String a:CURRENCIES)for(String b:CURRENCIES)if(!a.equals(b)&&name.contains(a+b))return new String[]{
            a,b
        };
        return new String[]{
            "",""
        };
    }
    public static boolean inverse(ChartData primary,ChartData reference,Map<String,String> v){
        if("Terbalik".equals(v.get("shadowDirection")))return true;
        if("Searah".equals(v.get("shadowDirection")))return false;
        String from=root(primary.symbol,primary.currencyBase,primary.currencyProfit);
        if(!"Manual".equals(v.get("shadowPairMode"))&&!counterpart(from).isEmpty())return presetInverse(from);
        String[] a=currencies(primary),b=currencies(reference);
        return !a[0].isEmpty()&&!a[0].equals(a[1])&&a[0].equals(b[1])&&a[1].equals(b[0]);
    }
    public static final class Transform {
        public final long anchorTime;
        public final double chartOpen,referenceOpen,anchorAtr,scale,base,slope;
        private Transform(Anchor anchor,boolean inverse,double amplitude,double offset){
            anchorTime=anchor.time;
            chartOpen=anchor.chartOpen;
            referenceOpen=anchor.refOpen;
            anchorAtr=anchor.atr;
            scale=anchor.scale;
            base=chartOpen+offset*anchorAtr;
            slope=(inverse?-1:1)*scale*amplitude;
        }
        public double price(double raw){
            return base+(raw-referenceOpen)*slope;
        }
    }
    private static final class Anchor {
        final long time;
        final double chartOpen,refOpen,atr,scale;
        Anchor(long time,double chartOpen,double refOpen,double atr,double scale){
            this.time=time;
            this.chartOpen=chartOpen;
            this.refOpen=refOpen;
            this.atr=atr;
            this.scale=scale;
        }
    }
    public static final class State {
        private final String identity;
        private final Anchor anchor;
        private final ZwaveCoreEngine.State waves;
        private State(String identity,Anchor anchor,ZwaveCoreEngine.State waves){
            this.identity=identity;
            this.anchor=anchor;
            this.waves=waves;
        }
    }
    public static final class Result {
        public final PlotFrame frame;
        public final State state;
        public final String status,symbol;
        public final Transform transform;
        public final long anchorTime,lastSyncTime;
        public final int alignedBars;
        public final boolean inverse,currentAligned;
        public final ZwaveCoreEngine.Result waves;
        public final ChartData alignedReference;
        public final double[] rawReferenceMacd;
        private Result(PlotFrame frame,State state,String status,String symbol,Transform transform,long lastSync,int count,boolean inverse,boolean currentAligned,ZwaveCoreEngine.Result waves,ChartData aligned,double[] macd){
            this.frame=frame;
            this.state=state;
            this.status=status;
            this.symbol=symbol;
            this.transform=transform;
            anchorTime=transform==null?0:transform.anchorTime;
            lastSyncTime=lastSync;
            alignedBars=count;
            this.inverse=inverse;
            this.currentAligned=currentAligned;
            this.waves=waves;
            alignedReference=aligned;
            rawReferenceMacd=macd.clone();
        }
    }
    /** Wilder ATR(14), seeded with the first fourteen true ranges, without filling gaps. */
    public static double[] atr(List<ChartData.Bar> bars){
        double[] out=new double[bars.size()];
        Arrays.fill(out,Double.NaN);
        double seed=0,value=Double.NaN;
        for(int i=0;i<bars.size();i++){
            ChartData.Bar b=bars.get(i);
            double tr=i==0?b.high-b.low:Math.max(b.high-b.low,Math.max(Math.abs(b.high-bars.get(i-1).close),Math.abs(b.low-bars.get(i-1).close)));
            if(i<14){
                seed+=tr;
                if(i==13)value=seed/14;
            }
            else value=(value*13+tr)/14;
            out[i]=value;
        }
        return out;
    }
    /** EMA12 - EMA26 on the complete reference sequence, before same-time alignment. */
    public static double[] macd(List<ChartData.Bar> bars){
        double[] out=new double[bars.size()];
        double fast=0,slow=0;
        for(int i=0;i<bars.size();i++){
            double close=bars.get(i).close;
            fast=i==0?close:2.0/13*close+(1-2.0/13)*fast;
            slow=i==0?close:2.0/27*close+(1-2.0/27)*slow;
            out[i]=fast-slow;
        }
        return out;
    }
    private static boolean positive(double value){
        return Double.isFinite(value)&&value>0;
    }
    private static String identity(ChartData primary,ChartData reference,Map<String,String> v){
        return primary.chartId+"\0"+primary.server+"\0"+primary.symbol+"\0"+primary.period+"\0"+reference.server+"\0"+reference.symbol+"\0"+ZwaveCoreInputs.anchorTime(v)+"\0"+v.get("shadowScaleMode");
    }
    private static Result empty(ChartData primary,ChartData reference,Map<String,String> v,State previous,String status){
        PlotFrame f=new PlotFrame();
        String symbol=reference==null?String.join(" / ",candidates(primary,v)):reference.symbol;
        panel(f,primary,v,symbol,status,null,null,false,0);
        return new Result(f,previous,status,symbol,null,0,0,false,false,null,null,new double[0]);
    }
    public static Result analyze(ChartData primary,ChartData reference,Map<String,String> v,State previous){
        if(primary==null||v==null)throw new IllegalArgumentException("Primary chart and normalized Zwave Core inputs required");
        ZwaveCoreInputs.validate(v);
        if(!ZwaveCoreInputs.b(v,"shadowShow"))return empty(primary,reference,v,null,"Shadow dinonaktifkan");
        if(candidates(primary,v).length==0)return empty(primary,reference,v,null,"Otomatis tidak tersedia; pilih Manual dan simbol broker pembanding");
        if(reference==null)return empty(primary,null,v,previous,"Data pembanding broker belum tersedia; gelombang utama tetap aktif");
        if(reference.period!=primary.period||!reference.server.equals(primary.server))return empty(primary,reference,v,null,"Simbol pembanding harus berasal dari server dan timeframe broker yang sama");
        List<ChartData.Bar> chart=primary.allBars(),raw=reference.allBars();
        if(chart.isEmpty()||raw.isEmpty())return empty(primary,reference,v,previous,"Data pembanding kosong; periksa simbol dan sesi broker");
        double[] chartAtr=atr(chart),referenceAtr=atr(raw),referenceMacd=macd(raw);
        List<ChartData.Bar> aligned=new ArrayList<ChartData.Bar>();
        List<Integer> chartAt=new ArrayList<Integer>(),refAt=new ArrayList<Integer>();
        int c=0,r=0;
        while(c<chart.size()&&r<raw.size()){
            long a=chart.get(c).time,b=raw.get(r).time;
            if(a<b)c++;
            else if(a>b)r++;
            else{
                aligned.add(raw.get(r));
                chartAt.add(c++);
                refAt.add(r++);
            }
        }
        if(aligned.isEmpty())return empty(primary,reference,v,previous,"Tidak ada bar dengan waktu yang sama; celah sesi tidak diisi");
        String id=identity(primary,reference,v);
        boolean carry=previous!=null&&id.equals(previous.identity);
        Anchor anchor=carry?previous.anchor:null;
        long requested=ZwaveCoreInputs.anchorTime(v);
        boolean atrMode="ATR pada jangkar".equals(v.get("shadowScaleMode"));
        int anchorChart=-1;
        if(anchor==null)for(int i=0;i<aligned.size();i++){
            int ci=chartAt.get(i),ri=refAt.get(i);
            ChartData.Bar a=chart.get(ci),b=raw.get(ri);
            if(a.time<requested||ci<1||atrMode&&ri<1)continue;
            double pa=chartAtr[ci-1],pb=ri>0?referenceAtr[ri-1]:Double.NaN;
            boolean ready=positive(pa)&&(atrMode?positive(pb):a.open!=0&&b.open!=0);
            double scale=atrMode?pa/pb:Math.abs(a.open/b.open);
            if(ready&&positive(scale)){
                anchor=new Anchor(a.time,a.open,b.open,pa,scale);
                anchorChart=ci;
                break;
            }
        }
        boolean mirror=inverse(primary,reference,v),current=aligned.get(aligned.size()-1).time==chart.get(chart.size()-1).time;
        long lastSync=aligned.get(aligned.size()-1).time;
        if(anchor==null)return empty(primary,reference,v,new State(id,null,carry?previous.waves:null),"Menunggu bar bersama pada/setelah jangkar dan ATR(14) sebelumnya yang valid");
        Transform transform=new Transform(anchor,mirror,ZwaveCoreInputs.d(v,"shadowAmplitude"),ZwaveCoreInputs.d(v,"shadowVerticalOffset"));
        PlotFrame frame=new PlotFrame();
        int displayFrom=Math.max(0,chart.size()-ZwaveCoreInputs.i(v,"shadowBars"));
        List<ChartData.Bar> display=new ArrayList<ChartData.Bar>();
        for(int i=0;i<aligned.size();i++)if(chartAt.get(i)>=displayFrom&&aligned.get(i).time>=anchor.time)display.add(aligned.get(i));
        if(!display.isEmpty())candles(frame,display,transform,v);
        // Pine admits only same-time bars within the primary chart's analysis window.
        int history=ZwaveCoreInputs.i(v,"shadowHistoryBars"),first=0;
        while(first<aligned.size()&&chartAt.get(first)<chart.size()-1-history)first++;
        first=Math.max(first,aligned.size()-history);
        List<ChartData.Bar> input=new ArrayList<ChartData.Bar>(aligned.subList(first,aligned.size()));
        int[] indices=new int[input.size()];
        double[] alignedMacd=new double[input.size()];
        for(int i=0;i<input.size();i++){
            indices[i]=chartAt.get(first+i);
            alignedMacd[i]=referenceMacd[refAt.get(first+i)];
        }
        ChartData.Bar forming=null;
        if(!input.isEmpty()&&primary.formingBar!=null&&input.get(input.size()-1).time==primary.formingBar.time)forming=input.remove(input.size()-1);
        ChartData analysis=new ChartData(primary.chartId,reference.server,reference.symbol,primary.period,input,forming,reference.digits,primary.periodSeconds,primary.quoteTime,Collections.<Integer,List<ChartData.Bar>>emptyMap(),reference.tickSize,reference.currencyBase,reference.currencyProfit,primary.backgroundColor);
        ZwaveCoreEngine.Result waves=null;
        ZwaveCoreEngine.State waveState=carry?previous.waves:null;
        int lastReference=raw.size()-1;
        while(lastReference>0&&raw.get(lastReference).time>chart.get(chart.size()-1).time)lastReference--;
        double labelAtr=referenceAtr[lastReference];
        if(ZwaveCoreInputs.b(v,"shadowWaveFeatures")&&!analysis.allBars().isEmpty()){
            ZwaveCoreEngine.Options options=ZwaveCoreEngine.Options.shadow(v);
            options.macdOverride=alignedMacd;
            options.labelAtrOverride=labelAtr;
            waves=ZwaveCoreEngine.analyze(analysis,v,waveState,options);
            waveState=waves.state;
            new Drawing(frame,primary,analysis,indices,transform,waves,labelAtr,v).render();
        }
        // A first anchor on the forming primary candle is provisional, like Pine var rollback.
        Anchor committed=anchorChart>=primary.closedBars.size()&&primary.formingBar!=null?null:anchor;
        State next=new State(id,committed,waveState);
        String status=current?"LIVE | tick chart utama | candle aktif dapat berubah":"Tidak ada bar sinkron saat ini | celah tidak diisi";
        if(waves!=null&&waves.work>=waves.searchLimit)status+=" | batas pencarian shadow tercapai";
        panel(frame,primary,v,reference.symbol,status,transform,waves,mirror,lastSync);
        return new Result(frame,next,status,reference.symbol,transform,lastSync,aligned.size(),mirror,current,waves,analysis,alignedMacd);
    }
    private static void candles(PlotFrame frame,List<ChartData.Bar> bars,Transform t,Map<String,String> v){
        int n=bars.size();
        long[] times=new long[n];
        double[] open=new double[n],high=new double[n],low=new double[n],close=new double[n];
        int[] body=new int[n],wick=new int[n],border=new int[n];
        for(int i=0;i<n;i++){
            ChartData.Bar b=bars.get(i);
            times[i]=b.time;
            open[i]=t.price(b.open);
            close[i]=t.price(b.close);
            high[i]=t.price(t.slope>=0?b.high:b.low);
            low[i]=t.price(t.slope>=0?b.low:b.high);
            int ink=ZwaveCoreInputs.c(v,close[i]>=open[i]?"shadowBullColor":"shadowBearColor");
            body[i]=ZwaveCoreInputs.transparency(ink,ZwaveCoreInputs.b(v,"shadowHollow")?100:ZwaveCoreInputs.i(v,"shadowBodyTransparency"));
            wick[i]=border[i]=ZwaveCoreInputs.transparency(ink,ZwaveCoreInputs.i(v,"shadowWickTransparency"));
        }
        frame.styledCandleSeries("shadow_candles",0,times,open,high,low,close,body,wick,border);
    }
    private static void panel(PlotFrame frame,ChartData primary,Map<String,String> v,String symbol,String status,Transform t,ZwaveCoreEngine.Result waves,boolean inverse,long lastSync){
        if(!ZwaveCoreInputs.b(v,"shadowShowPanel"))return;
        int foreground=((primary.backgroundColor>>16&255)*299+(primary.backgroundColor>>8&255)*587+(primary.backgroundColor&255)*114)>128000?0xff101820:0xffeeeeee;
        String anchor=t==null?"Menunggu jangkar bersama":"Jangkar "+t.anchorTime+(ZwaveCoreInputs.anchorTime(v)>0?" | manual":" | bar bersama pertama termuat")+" | skala tetap";
        String structure=!ZwaveCoreInputs.b(v,"shadowWaveFeatures")?"ZWave shadow dinonaktifkan":waves==null?"ZWave shadow menunggu data":"ZWave shadow: "+waves.major.size()+" large / "+waves.minor.size()+" child | S: = pembanding";
        frame.panel("shadow_status",2,new String[]{
            "Shadow korelasi | "+v.get("shadowPairMode"),symbol+" | TF "+primary.period,(inverse?"Terbalik":"Searah")+" | "+v.get("shadowScaleMode"),anchor,status+" | sinkron "+lastSync,structure
        },
        new int[]{
            0xff2196f3,foreground,foreground,foreground,t==null?0xffff9800:foreground,foreground
        },
        10);
    }
    private static final class Drawing {
        final PlotFrame frame;
        final ChartData primary,reference;
        final List<ChartData.Bar> chart;
        final int[] indices;
        final Transform transform;
        final ZwaveCoreEngine.Result result;
        final double tick,atr;
        final Map<String,String> v;
        final long window;
        final int windowChart;
        int lines,labels,keys;
        Drawing(PlotFrame frame,ChartData primary,ChartData reference,int[] indices,Transform transform,ZwaveCoreEngine.Result result,double atr,Map<String,String> v){
            this.frame=frame;
            this.primary=primary;
            this.reference=reference;
            chart=primary.allBars();
            this.indices=indices;
            this.transform=transform;
            this.result=result;
            tick=positive(reference.tickSize)?reference.tickSize:reference.point;
            this.atr=positive(atr)?atr:tick*12;
            this.v=v;
            List<ChartData.Bar> bars=reference.allBars();
            int at=0,minimum=chart.size()-ZwaveCoreInputs.i(v,"shadowBars");
            while(at<bars.size()-1&&(bars.get(at).time<transform.anchorTime||indices[at]<minimum))at++;
            window=Math.max(transform.anchorTime,bars.get(at).time);
            windowChart=indices[at];
        }
        String key(String type){
            return "S_"+type+"_"+(keys++);
        }
        int color(int degree){
            return ZwaveCoreInputs.c(v,degree==0?"shadowLargeTextColor":degree==1?"shadowChildTextColor":"shadowMicroTextColor");
        }
        boolean visible(ZwaveCoreEngine.Pivot p){
            return p.b>=0&&p.b<indices.length&&p.t>=transform.anchorTime&&indices[p.b]>=chart.size()-ZwaveCoreInputs.i(v,"shadowBars");
        }
        void segment(long from,double p1,long to,double p2,int ink,int width,int style,int budget){
            long clipped=Math.max(from,window);
            if(to>clipped&&to>from&&lines<budget){
                double p=p1+(p2-p1)*(clipped-from)/(double)(to-from);
                frame.line(key("line"),0,clipped,transform.price(p),to,transform.price(p2),ink,width,style);
                lines++;
            }
        }
        void line(ZwaveCoreEngine.Pivot a,ZwaveCoreEngine.Pivot b,int ink,int width,int style){
            if(b.t>a.t&&visible(b)&&lines<180)segment(a.t,a.p,b.t,b.p,ink,width,style,180);
        }
        boolean committed(ZwaveCoreEngine.Count count){
            for(ZwaveCoreEngine.Count old:result.state.confirmedCounts)if(old.degree==count.degree&&ZwaveCoreEngine.same(old.pivot,count.pivot)&&(" / "+old.waveName+" / ").contains(" / "+count.waveName+" / "))return true;
            return false;
        }
        void text(long time,double raw,String caption,int ink,int size,int anchor){
            frame.anchoredText(key("text"),0,time,transform.price(raw),caption,ink,size,anchor,false);
            labels++;
        }
        long time(int at){
            if(at<chart.size())return chart.get(Math.max(0,at)).time;
            long seconds=primary.periodSeconds>0?primary.periodSeconds:60;
            return chart.get(chart.size()-1).time+(at-chart.size()+1)*seconds;
        }
        boolean fibonacci(ZwaveCoreEngine.Pivot a,ZwaveCoreEngine.Pivot b,int ink,boolean latest){
            if(b.t<=a.t||a.hi==b.hi||Math.abs(a.p-b.p)<tick*.5||!visible(b)||a.b<0||a.b>=indices.length||b.b<0||b.b>=indices.length)return false;
            int start=Math.max(indices[a.b],windowChart),end=latest?Math.max(indices[b.b],chart.size()-1)+ZwaveCoreInputs.i(v,"fibRightExtension"):indices[b.b],label=end+Math.max(1,ZwaveCoreInputs.i(v,"fibTextShift"));
            for(double ratio:new double[]{
                0,.236,.382,.5,.618,.707,.786,.886,1
            }
            ){
                double price=transform.price(b.p+(a.p-b.p)*ratio);
                if(lines<220){
                    frame.line(key("fib"),0,time(start),price,time(end),price,ZwaveCoreInputs.transparency(ink,35),ZwaveCoreInputs.i(v,"fibLineWidth"),ZwaveCoreInputs.style(v.get("fibLineStyle")));
                    lines++;
                }
                if(labels<220){
                    frame.anchoredText(key("fib_text"),0,time(label),price,String.format(Locale.ROOT,"S:%.1f%%",ratio*100),ink,8,4,false);
                    labels++;
                }
            }
            return true;
        }
        void render(){
            List<ZwaveCoreEngine.Pivot> major=result.major,minor=result.minor;
            int m=major.size(),n=minor.size(),visibleFrom=m>0?major.get(Math.max(0,m-ZwaveCoreInputs.i(v,"shadowVisibleMajor"))).b:result.lastBar;
            if(ZwaveCoreInputs.b(v,"shadowZigzag")){
                for(int i=Math.max(1,m-ZwaveCoreInputs.i(v,"shadowVisibleMajor")+1);i<m;i++)line(major.get(i-1),major.get(i),color(0),2,1);
                for(int i=1;i<n;i++)if(minor.get(i).b>=visibleFrom)line(minor.get(i-1),minor.get(i),color(1),1,2);
            }
            LinkedHashMap<String,ZwaveCoreEngine.Count> merged=new LinkedHashMap<String,ZwaveCoreEngine.Count>();
            for(ZwaveCoreEngine.Count c:result.counts){
                if(c.pivot.b<visibleFrom||c.degree==2&&!ZwaveCoreInputs.b(v,"shadowMicro")||!visible(c.pivot))continue;
                String id=c.degree+"_"+c.pivot.b+"_"+Double.doubleToLongBits(c.pivot.p)+"_"+c.pivot.hi;
                ZwaveCoreEngine.Count previous=merged.get(id);
                if(previous==null)merged.put(id,c);
                else if(!(" / "+previous.waveName+" / ").contains(" / "+c.waveName+" / "))merged.put(id,new ZwaveCoreEngine.Count(c.pivot,c.degree,previous.waveName+" / "+c.waveName));
            }
            if(ZwaveCoreInputs.b(v,"shadowWaveLabels")){
                List<ZwaveCoreEngine.Count> counts=new ArrayList<ZwaveCoreEngine.Count>(merged.values());
                for(int i=Math.max(0,counts.size()-180);i<counts.size()&&labels<180;i++){
                    ZwaveCoreEngine.Count c=counts.get(i);
                    double offset=Math.max(tick,atr/12)*(c.degree==0?4:c.degree==1?2:.6),raw=c.pivot.hi?c.pivot.p+offset:c.pivot.p-offset-atr*ZwaveCoreInputs.d(v,"lowerWaveGap");
                    String caption="S:"+c.waveName+(result.provisional&&!committed(c)&&!c.waveName.contains("?")?"?":"");
                    boolean visualHigh=transform.slope>=0?c.pivot.hi:!c.pivot.hi;
                    text(c.pivot.t,raw,caption,color(c.degree),ZwaveCoreInputs.size(v.get(c.degree==2?"microFontSize":"waveFontSize")),visualHigh?3:2);
                }
            }
            for(int i=Math.max(0,result.links.size()-50);i<result.links.size();i++){
                ZwaveCoreEngine.DivLink link=result.links.get(i);
                if(link.three.b>=visibleFrom&&(link.degree!=2||ZwaveCoreInputs.b(v,"shadowMicro")))line(link.three,link.five,color(link.three.hi?0:1),2,3);
            }
            if(ZwaveCoreInputs.b(v,"shadowLargeFib")&&m>=2)fibonacci(major.get(m-2),major.get(m-1),color(0),true);
            if(ZwaveCoreInputs.b(v,"shadowChildFib")){
                int found=0;
                for(int i=n-1;i>=1&&found<ZwaveCoreInputs.i(v,"shadowFibLegs");i--){
                    ZwaveCoreEngine.Pivot a=minor.get(i-1),b=minor.get(i);
                    if(a.b<visibleFrom)break;
                    if(fibonacci(a,b,color(1),found==0))found++;
                }
            }
            if(ZwaveCoreInputs.b(v,"shadowHidden"))hidden();
        }
        long sortKey(ZwaveCoreEngine.HiddenDivLink link){
            return ((long)(link.endpoint.known-result.base)*(result.lastBar-result.base+2)+link.endpointOscBar-result.base)*3+link.degree;
        }
        void hidden(){
            List<ZwaveCoreEngine.HiddenDivLink> hidden=new ArrayList<ZwaveCoreEngine.HiddenDivLink>(result.hidden);
            Collections.sort(hidden,new Comparator<ZwaveCoreEngine.HiddenDivLink>(){
                public int compare(ZwaveCoreEngine.HiddenDivLink a,ZwaveCoreEngine.HiddenDivLink b){
                    return Long.compare(sortKey(b),sortKey(a));
                }
            }
            );
            for(int i=0;i<Math.min(hidden.size(),ZwaveCoreInputs.i(v,"hiddenMaxSignals"));i++){
                ZwaveCoreEngine.HiddenDivLink link=hidden.get(i);
                if(!visible(link.endpoint)||link.endpoint.t<=link.anchor.t)continue;
                if(lines>=250)break;
                boolean bull=!link.endpoint.hi;
                int ink=color(bull?1:0);
                segment(link.anchor.t,link.anchor.p,link.endpoint.t,link.endpoint.p,ink,1,1,250);
                if(ZwaveCoreInputs.b(v,"hiddenShowLabels")&&labels<250){
                    String degree=link.degree==0?"Large":link.degree==1?"Child":"Micro";
                    boolean live=result.provisional&&link.endpoint.known>=result.lastBar;
                    String caption="S:"+(bull?"HBull":"HBear")+(live?"?":"")+" ["+degree+"]";
                    double offset=Math.max(tick,atr*(link.degree==0?.65:link.degree==1?.5:.35));
                    boolean drawBullish=transform.slope>=0?bull:!bull;
                    text(link.endpoint.t,link.endpoint.p+(bull?-offset:offset),caption,ink,8,drawBullish?2:1);
                }
            }
        }
    }
}
