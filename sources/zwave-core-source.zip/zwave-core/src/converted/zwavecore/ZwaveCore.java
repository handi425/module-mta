// Zwave Core, © XoRonX | Mr Poleks. Mozilla Public License 2.0.
// Android integration: immutable broker snapshots, background calculation and Canvas.
package converted.zwavecore;

import java.util.*;
import java.util.concurrent.*;
import net.metaquotes.metatrader5.modules.api.*;

/** The chart thread only captures data; analysis and exact cache checks run off MAIN. */
public final class ZwaveCore implements HistoryIndicatorPlugin {
    private static final ThreadPoolExecutor EXECUTOR=new ThreadPoolExecutor(1,1,30,TimeUnit.SECONDS,new ArrayBlockingQueue<Runnable>(32),new ThreadFactory(){public Thread newThread(Runnable action){Thread thread=new Thread(action,"Zwave-Core");thread.setDaemon(true);return thread;}},new ThreadPoolExecutor.AbortPolicy());
    static {EXECUTOR.allowCoreThreadTimeOut(true);}
    private final Object monitor=new Object();
    private final long[] counters=new long[8];
    private long revision;
    private boolean queued;
    private Job latest;
    private Cache cache;
    private Map<String,String> details=Collections.emptyMap();
    private final Runnable run=new Runnable(){public void run(){drain();}};
    public ModuleDescriptor describe(){return ZwaveCoreInputs.DESCRIPTOR;}
    public int[] historyPeriods(Map<String,String> values){ZwaveCoreInputs.normalize(values);return new int[0];}
    public int historyBars(Map<String,String> values){ZwaveCoreInputs.normalize(values);return 100000;}
    public void onChartUpdate(ModuleEnvironment env,ChartData chart,Map<String,String> inputs)throws Exception {
        DeferredPlot plot=env.defer(chart);
        boolean shadow=Boolean.parseBoolean(inputs.get("shadowShow"));
        ReferenceData reference=env.reference(chart,shadow?ShadowEngine.candidates(chart,inputs):new String[0],100000);
        Job rejected=null;
        synchronized(monitor){counters[0]++;if(latest!=null)counters[3]++;latest=new Job(chart,reference,inputs,plot,revision);if(!queued){queued=true;try{EXECUTOR.execute(run);}catch(RejectedExecutionException busy){rejected=latest;latest=null;queued=false;}}}
        if(rejected!=null)retry(rejected);
    }
    public void onDetach(ModuleEnvironment env,int chart)throws Exception {synchronized(monitor){revision++;latest=null;cache=null;details=Collections.emptyMap();}env.clear(chart);}
    public long[] performanceStats(){synchronized(monitor){return counters.clone();}}
    public Map<String,String> statusDetails(){synchronized(monitor){return new LinkedHashMap<String,String>(details);}}
    private void retry(Job job){if(valid(job))job.plot.fail(new HistoryNotReadyException("Antrean Zwave Core penuh; mencoba kembali"));}
    private boolean valid(Job job){boolean okay;synchronized(monitor){okay=revision==job.revision;}if(okay)okay=job.plot.isCurrent();if(!okay)synchronized(monitor){counters[4]++;}return okay;}
    private void drain(){
        Job job;synchronized(monitor){job=latest;latest=null;}
        try{if(job!=null&&valid(job))calculate(job);}catch(Throwable failure){if(job!=null&&valid(job))job.plot.fail(failure);}
        finally{Job rejected=null;synchronized(monitor){if(latest==null)queued=false;else try{EXECUTOR.execute(run);}catch(RejectedExecutionException busy){rejected=latest;latest=null;queued=false;}}if(rejected!=null)retry(rejected);}
    }
    private void calculate(Job job){
        Map<String,String> values=ZwaveCoreInputs.normalize(job.values);Cache old;synchronized(monitor){old=cache;}
        if(old!=null&&old.values.equals(values)&&same(old.chart,job.chart)&&same(old.reference.chart,job.reference.chart)&&old.reference.status.equals(job.reference.status)&&old.reference.symbol.equals(job.reference.symbol)){
            synchronized(monitor){counters[2]++;}if(valid(job))job.plot.publish(old.frame);return;
        }
        long started=System.nanoTime();synchronized(monitor){counters[1]++;}
        ZwaveCoreEngine.Result primary;
        ShadowEngine.Result shadow;
        try{
            primary=ZwaveCoreEngine.analyze(job.chart,values,old==null?null:old.primary);
            shadow=ShadowEngine.analyze(job.chart,job.reference.chart,values,old!=null&&continuation(old.chart,job.chart)&&continuation(old.reference.chart,job.reference.chart)?old.shadow:null);
        }finally{long micros=(System.nanoTime()-started)/1000L;synchronized(monitor){counters[5]=micros;counters[6]+=micros;counters[7]=Math.max(counters[7],micros);}}
        PlotFrame combined=new PlotFrame();append(combined,primary.frame);append(combined,shadow.frame);
        boolean enabled=ZwaveCoreInputs.b(values,"shadowShow");
        combined.status("Aktif"+(enabled?" · "+(job.reference.chart==null?job.reference.status:job.reference.symbol):""));
        Map<String,String> current=new LinkedHashMap<String,String>();
        current.put("referenceSymbol",job.reference.symbol);current.put("referenceStatus",job.reference.status);current.put("shadowStatus",shadow.status);current.put("anchorTime",Long.toString(shadow.anchorTime));current.put("lastSyncTime",Long.toString(shadow.lastSyncTime));current.put("alignedBars",Integer.toString(shadow.alignedBars));current.put("shadowCandleBars",Integer.toString(shadow.frame.candles.isEmpty()?0:shadow.frame.candles.get(0).times.length));current.put("primaryMajor",Integer.toString(primary.major.size()));current.put("primaryMinor",Integer.toString(primary.minor.size()));current.put("primaryCounts",Integer.toString(primary.counts.size()));current.put("primaryHidden",Integer.toString(primary.hidden.size()));current.put("primaryWork",Integer.toString(primary.work));current.put("shadowMajor",Integer.toString(shadow.waves==null?0:shadow.waves.major.size()));current.put("shadowCounts",Integer.toString(shadow.waves==null?0:shadow.waves.counts.size()));current.put("drawings",Integer.toString(combined.drawings.size()));
        if(!valid(job))return;
        synchronized(monitor){if(revision!=job.revision)return;cache=new Cache(job.chart,job.reference,values,combined,primary.state,shadow.state);details=Collections.unmodifiableMap(current);}
        job.plot.publish(combined);
    }
    private static void append(PlotFrame target,PlotFrame source){target.drawings.addAll(source.drawings);target.candles.addAll(source.candles);target.panels.addAll(source.panels);}
    private static boolean same(ChartData a,ChartData b){
        if(a==b)return true;if(a==null||b==null||a.chartId!=b.chartId||a.period!=b.period||a.periodSeconds!=b.periodSeconds||a.digits!=b.digits||a.backgroundColor!=b.backgroundColor||a.tickSize!=b.tickSize||!a.server.equals(b.server)||!a.symbol.equals(b.symbol)||!a.currencyBase.equals(b.currencyBase)||!a.currencyProfit.equals(b.currencyProfit)||a.closedBars.size()!=b.closedBars.size()||!same(a.formingBar,b.formingBar))return false;
        for(int i=0;i<a.closedBars.size();i++)if(!same(a.closedBars.get(i),b.closedBars.get(i)))return false;return true;
    }
    private static boolean same(ChartData.Bar a,ChartData.Bar b){return a==b||a!=null&&b!=null&&a.time==b.time&&a.open==b.open&&a.high==b.high&&a.low==b.low&&a.close==b.close&&a.tickVolume==b.tickVolume&&a.realVolume==b.realVolume;}
    /** Keep anchors only across an exact append of the committed broker history. */
    static boolean continuation(ChartData a,ChartData b){
        if(a==b)return a!=null;if(a==null||b==null||a.chartId!=b.chartId||a.period!=b.period||a.periodSeconds!=b.periodSeconds||a.tickSize!=b.tickSize||!a.server.equals(b.server)||!a.symbol.equals(b.symbol)||!a.currencyBase.equals(b.currencyBase)||!a.currencyProfit.equals(b.currencyProfit)||a.closedBars.size()>b.closedBars.size())return false;
        for(int i=0;i<a.closedBars.size();i++)if(!same(a.closedBars.get(i),b.closedBars.get(i)))return false;return true;
    }
    private static final class Job {
        final ChartData chart;final ReferenceData reference;final Map<String,String> values;final DeferredPlot plot;final long revision;
        Job(ChartData chart,ReferenceData reference,Map<String,String> values,DeferredPlot plot,long revision){this.chart=chart;this.reference=reference;this.values=values;this.plot=plot;this.revision=revision;}
    }
    private static final class Cache {
        final ChartData chart;final ReferenceData reference;final Map<String,String> values;final PlotFrame frame;final ZwaveCoreEngine.State primary;final ShadowEngine.State shadow;
        Cache(ChartData chart,ReferenceData reference,Map<String,String> values,PlotFrame frame,ZwaveCoreEngine.State primary,ShadowEngine.State shadow){this.chart=chart;this.reference=reference;this.values=values;this.frame=frame;this.primary=primary;this.shadow=shadow;}
    }
}
