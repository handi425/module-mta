param(
    [string]$JdkHome='C:\Program Files\Microsoft\jdk-21.0.8.9-hotspot',
    [string]$AndroidJar=(Join-Path $env:LOCALAPPDATA 'Android\Sdk\platforms\android-36\android.jar')
)
$ErrorActionPreference='Stop'
$sdk=& (Join-Path $PSScriptRoot 'build-sdk.ps1') -JdkHome $JdkHome -AndroidJar $AndroidJar
if($LASTEXITCODE-ne 0){throw 'SDK source build failed'}
$sdk=[string]($sdk | Select-Object -Last 1)
$classes=Join-Path $PSScriptRoot ('build\tests-'+[Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $classes | Out-Null
$sources=@(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'src') -Recurse -Filter '*.java' | ForEach-Object FullName)
foreach($name in @('SmcInputsTest','SmcCoreTest','SmcMtfTest')){
    $test=Join-Path $PSScriptRoot ('tests\'+$name+'.java')
    if(-not(Test-Path -LiteralPath $test -PathType Leaf)){throw ('Missing SMC test: '+$name)}
    $sources+=$test
}
& (Join-Path $JdkHome 'bin\javac.exe') --release 8 '-Xlint:-options' -encoding UTF-8 -cp "$sdk;$AndroidJar" -d $classes @sources
if($LASTEXITCODE-ne 0){throw 'SMC test compilation failed'}
foreach($name in @('SmcInputsTest','SmcCoreTest','SmcMtfTest')){
    & (Join-Path $JdkHome 'bin\java.exe') -cp "$classes;$sdk;$AndroidJar" $name
    if($LASTEXITCODE-ne 0){throw ('SMC test failed: '+$name)}
}
