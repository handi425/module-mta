param(
    [string]$JdkHome='C:\Program Files\Microsoft\jdk-21.0.8.9-hotspot',
    [string]$AndroidJar=(Join-Path $env:LOCALAPPDATA 'Android\Sdk\platforms\android-36\android.jar'),
    [switch]$Dex,
    [string]$D8=(Join-Path $env:LOCALAPPDATA 'Android\Sdk\build-tools\36.1.0\d8.bat')
)
$ErrorActionPreference='Stop'
$sdk=& (Join-Path $PSScriptRoot 'build-sdk.ps1') -JdkHome $JdkHome -AndroidJar $AndroidJar
if($LASTEXITCODE-ne 0){throw 'SDK source build failed'}
$sdk=[string]($sdk | Select-Object -Last 1)
$build=Join-Path $PSScriptRoot 'build'
$classes=Join-Path $build ('module-'+[Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $classes | Out-Null
$sources=@(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'src') -Recurse -Filter '*.java' | ForEach-Object FullName)
if($sources.Count-lt 4){throw 'SMC Java source is incomplete'}
& (Join-Path $JdkHome 'bin\javac.exe') --release 8 '-Xlint:-options' -encoding UTF-8 -cp "$sdk;$AndroidJar" -d $classes @sources
if($LASTEXITCODE-ne 0){throw 'SMC source compilation failed'}
$module=Join-Path $build 'luxalgo-smc-classes.jar'
& (Join-Path $JdkHome 'bin\jar.exe') --create --file $module -C $classes .
if($LASTEXITCODE-ne 0){throw 'SMC JAR packaging failed'}
if($Dex){
    if(-not(Test-Path -LiteralPath $D8 -PathType Leaf)){throw 'Android SDK D8 is missing'}
    $dexDirectory=Join-Path $build ('dex-'+[Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Force -Path $dexDirectory | Out-Null
    $previousJavaHome=$env:JAVA_HOME
    try{
        $env:JAVA_HOME=$JdkHome
        & $D8 --release --min-api 26 --lib $AndroidJar --classpath $sdk --output $dexDirectory $module
        if($LASTEXITCODE-ne 0){throw 'SMC DEX build failed'}
    }finally{$env:JAVA_HOME=$previousJavaHome}
    Write-Output (Join-Path $dexDirectory 'classes.dex')
}
Write-Output $module
