import converted.smc.SmcMtf;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.metaquotes.metatrader5.modules.api.ChartData;
import net.metaquotes.metatrader5.modules.api.HistoryNotReadyException;
import net.metaquotes.metatrader5.modules.api.PlotFrame;

public final class SmcMtfTest {
    private static int assertions;
    private static final long T=1700000000L;
    public static void main(String[] args){
        choices();bullish();bearish();translucentGaps();threshold();forwardRemoval();higherFvg();lowerFvg();monthlyLowerFvg();levels();timeframeAnchors();missing();
        System.out.println("PASS: "+assertions+" SMC MTF assertions");
    }
    private static void choices(){
        String[] values=SmcMtf.timeframeChoices();eq(22,values.length,"Current plus all21 native timeframes");
        eq("Current",values[0],"current timeframe");eq("MN1",values[21],"monthly timeframe");
        values[0]="changed";eq("Current",SmcMtf.timeframeChoices()[0],"choices cloned");
        Map<String,String> in=inputs();in.put("showDailyLevelsInput","true");in.put("showWeeklyLevelsInput","true");in.put("showMonthlyLevelsInput","true");in.put("fairValueGapsTimeframeInput","H4");
        int[] periods=SmcMtf.historyPeriods(in);eq(4,periods.length,"all enabled history leases");eq(16388,periods[0],"H4 lease");eq(16408,periods[1],"D1 lease");eq(32769,periods[2],"W1 lease");eq(49153,periods[3],"MN1 lease");
        for(String value:SmcMtf.timeframeChoices()){Map<String,String> test=inputs();test.put("fairValueGapsTimeframeInput",value);eq(value.equals("Current")?0:1,SmcMtf.historyPeriods(test).length,"supported timeframe "+value);}
        in.put("fairValueGapsTimeframeInput","7");reject(new Runnable(){public void run(){SmcMtf.historyPeriods(in);}},"unsupported timeframe rejected");
    }
    private static List<ChartData.Bar> bullBars(){return new ArrayList<ChartData.Bar>(Arrays.asList(bar(0,10,11,9,10),bar(60,10,14,10,14),bar(120,13,15,13,14)));}
    private static void bullish(){
        Map<String,String> in=inputs();List<ChartData.Bar> bars=bullBars();PlotFrame f=frame(chart(1,bars,null,new HashMap<Integer,List<ChartData.Bar>>()),in);
        eq(4,f.drawings.size(),"two FVG boxes each fill and border");PlotFrame.Drawing top=drawing(f,"smc_fvg_0_top");
        eq(1005,top.type,"exact-alpha rectangle primitive");check(top.filled,"filled top half");eq(T+60,top.times[0],"gap begins at prior bar");eq(T+180,top.times[1],"one current-chart-bar extension");near(13,top.values[0],"bull top");near(12,top.values[1],"bull middle");eq(0x2600ff68,top.color,"fill capped near15percentopacity");
        eq(0x4d00ff68,drawing(f,"smc_fvg_0_top_border").color,"source30percent outline opacity remains unchanged");
        near(11,drawing(f,"smc_fvg_0_bottom").values[1],"bull bottom");check(!drawing(f,"smc_fvg_0_top_border").filled,"border preserved");
        bars.add(bar(180,12,14,11,12));eq(4,frame(chart(1,bars,null,new HashMap<Integer,List<ChartData.Bar>>()),in).drawings.size(),"touching bottom does not mitigate");
        bars.set(3,bar(180,12,14,10.9,12));eq(0,frame(chart(1,bars,null,new HashMap<Integer,List<ChartData.Bar>>()),in).drawings.size(),"strict low below gap bottom mitigates");
        in.put("fairValueGapsExtendInput","0");f=frame(chart(1,bullBars(),null,new HashMap<Integer,List<ChartData.Bar>>()),in);eq(T+120,drawing(f,"smc_fvg_0_top").times[1],"zero extension");
        in.put("styleInput","Monochrome");eq(0x26b2b5be,drawing(frame(chart(1,bullBars(),null,new HashMap<Integer,List<ChartData.Bar>>()),in),"smc_fvg_0_top").color,"monochrome bull fill alpha");
    }
    private static void bearish(){
        List<ChartData.Bar> bars=new ArrayList<ChartData.Bar>(Arrays.asList(bar(0,15,16,14,15),bar(60,15,15,10,10),bar(120,11,12,9,10)));
        Map<String,String> in=inputs();PlotFrame f=frame(chart(1,bars,null,new HashMap<Integer,List<ChartData.Bar>>()),in);
        eq(4,f.drawings.size(),"bear gap drawn");near(12,drawing(f,"smc_fvg_0_top").values[0],"original inverted bear top");near(14,drawing(f,"smc_fvg_0_bottom").values[1],"original inverted bear bottom");
        bars.add(bar(180,11,12,10,11));eq(4,frame(chart(1,bars,null,new HashMap<Integer,List<ChartData.Bar>>()),in).drawings.size(),"bear top equality retained");
        bars.set(3,bar(180,11,12.1,10,11));eq(0,frame(chart(1,bars,null,new HashMap<Integer,List<ChartData.Bar>>()),in).drawings.size(),"bear high over currentHigh mitigates before upper gap boundary");
    }
    private static void translucentGaps(){
        List<ChartData.Bar> bearish=Arrays.asList(bar(0,15,16,14,15),bar(60,15,15,10,10),bar(120,11,12,9,10));
        int[] colors={0xff123456,0x4d123456,0x0c123456,0x00123456};
        for(boolean bull:new boolean[]{true,false})for(int color:colors){
            Map<String,String> in=inputs();in.put(bull?"fairValueGapsBullColorInput":"fairValueGapsBearColorInput",String.format(java.util.Locale.ROOT,"#%08X",color));
            PlotFrame f=frame(chart(1,bull?bullBars():bearish,null,new HashMap<Integer,List<ChartData.Bar>>()),in);
            int expected=(color&0x00ffffff)|(Math.min(color>>>24,38)<<24);
            for(String half:Arrays.asList("top","bottom")){
                PlotFrame.Drawing fill=drawing(f,"smc_fvg_0_"+half),border=drawing(f,"smc_fvg_0_"+half+"_border");
                eq(expected,fill.color,"both FVG directions/halves cap only fill alpha, preserve RGB and lower/zero alpha");
                eq(color,border.color,"FVG outline alpha and RGB are untouched");
                check(fill.filled&&!border.filled&&Arrays.equals(fill.times,border.times)&&Arrays.equals(fill.values,border.values),"fill-only transparency leaves FVG rectangle boundary unchanged");
                eq(T+180,fill.times[1],"visual update preserves original FVG future extension");
            }
        }
        Map<String,String> mono=inputs();mono.put("styleInput","Monochrome");
        PlotFrame f=frame(chart(1,bullBars(),null,new HashMap<Integer,List<ChartData.Bar>>()),mono);
        eq(0x26b2b5be,drawing(f,"smc_fvg_0_top").color,"monochrome bullish FVG fill");
        eq(0x4db2b5be,drawing(f,"smc_fvg_0_top_border").color,"monochrome bullish FVG border");
        f=frame(chart(1,bearish,null,new HashMap<Integer,List<ChartData.Bar>>()),mono);
        eq(0x265d606b,drawing(f,"smc_fvg_0_top").color,"monochrome bearish FVG fill");
        eq(0x4d5d606b,drawing(f,"smc_fvg_0_top_border").color,"monochrome bearish FVG border");
    }
    private static void threshold(){
        Map<String,String> in=inputs();in.put("fairValueGapsThresholdInput","true");
        eq(0,frame(chart(1,bullBars(),null,new HashMap<Integer,List<ChartData.Bar>>()),in).drawings.size(),"auto threshold includes current delta and strict comparison");
        List<ChartData.Bar> bars=bullBars();bars.set(2,bar(120,13,25,13,25));bars.add(bar(180,24,28,20,26));
        PlotFrame f=frame(chart(1,bars,null,new HashMap<Integer,List<ChartData.Bar>>()),in);eq(4,f.drawings.size(),"larger cumulative delta passes threshold");near(20,drawing(f,"smc_fvg_0_top").values[0],"threshold accepted later gap");
    }
    private static void forwardRemoval(){
        List<ChartData.Bar> bars=bullBars();bars.set(2,bar(120,13,25,13,25));bars.add(bar(180,24,28,20,26));bars.add(bar(240,25,30,1,25));
        PlotFrame f=frame(chart(1,bars,null,new HashMap<Integer,List<ChartData.Bar>>()),inputs());eq(4,f.drawings.size(),"source forward removal skips shifted next gap");near(13,drawing(f,"smc_fvg_0_top").values[0],"older shifted gap survives this bar");
    }
    private static void higherFvg(){
        Map<String,String> in=inputs();in.put("fairValueGapsTimeframeInput","M5");
        List<ChartData.Bar> bars=new ArrayList<ChartData.Bar>();for(int i=0;i<10;i++)bars.add(bar(i*60,10,14,9,12));bars.add(bar(600,13,15,13,14));
        List<ChartData.Bar> htf=Arrays.asList(bar(0,10,11,9,10),bar(300,10,14,10,14),bar(600,13,16,13,15));Map<Integer,List<ChartData.Bar>> histories=new HashMap<Integer,List<ChartData.Bar>>();histories.put(5,htf);
        PlotFrame f=frame(chart(1,bars,null,histories),in);eq(4,f.drawings.size(),"HTF gap appears on first constituent historical bar");eq(T+300,drawing(f,"smc_fvg_0_top").times[0],"HTF previous bar anchor");eq(T+660,drawing(f,"smc_fvg_0_top").times[1],"HTF gap extension uses chart interval");
        List<ChartData.Bar> closed=new ArrayList<ChartData.Bar>(bars.subList(0,10));f=frame(chart(1,closed,bars.get(10),histories),in);eq(4,f.drawings.size(),"native HTF forming snapshot may form realtime gap");
        histories.put(5,Arrays.asList(htf.get(0),htf.get(1),bar(600,13,16,10.5,15)));eq(0,frame(chart(1,closed,bars.get(10),histories),in).drawings.size(),"updated HTF forming low removes provisional gap");
    }
    private static void lowerFvg(){
        Map<String,String> in=inputs();in.put("fairValueGapsTimeframeInput","M1");
        List<ChartData.Bar> lower=Arrays.asList(bar(0,10,11,9,10),bar(60,10,11,9,10),bar(120,10,11,9,10),bar(180,10,14,10,14),bar(240,13,15,13,14),bar(300,9,10,8,9));
        List<ChartData.Bar> bars=Arrays.asList(bar(0,10,11,9,10),bar(120,10,14,9,14),bar(240,13,15,8,9));Map<Integer,List<ChartData.Bar>> histories=new HashMap<Integer,List<ChartData.Bar>>();histories.put(1,lower);
        PlotFrame historical=frame(chart(2,bars,null,histories),in);eq(4,historical.drawings.size(),"historical LTF request selects first intrabar");eq(T+180,drawing(historical,"smc_fvg_0_top").times[0],"selected LTF previous intrabar anchor");
        PlotFrame realtime=frame(chart(2,bars.subList(0,2),bars.get(2),histories),in);eq(0,realtime.drawings.size(),"realtime LTF request selects latest available intrabar");
    }
    private static void monthlyLowerFvg(){
        long january=1672531200L,day=86400L;
        List<ChartData.Bar> lower=new ArrayList<ChartData.Bar>();for(int i=0;i<90;i++)lower.add(new ChartData.Bar(january+i*day,10,11,9,10));
        lower.set(88,new ChartData.Bar(january+88*day,10,14,10,14));lower.set(89,new ChartData.Bar(january+89*day,13,15,13,14));
        List<ChartData.Bar> bars=Arrays.asList(new ChartData.Bar(january,10,11,9,10),new ChartData.Bar(january+31*day,10,11,9,10),new ChartData.Bar(january+59*day,10,15,9,14));
        Map<Integer,List<ChartData.Bar>> histories=new HashMap<Integer,List<ChartData.Bar>>();histories.put(16408,lower);Map<String,String> in=inputs();in.put("fairValueGapsTimeframeInput","D1");
        PlotFrame realtime=frame(chart(49153,bars.subList(0,2),bars.get(2),histories),in);eq(4,realtime.drawings.size(),"31st-day LTF intrabar remains available in forming monthly chart");eq(january+88*day,drawing(realtime,"smc_fvg_0_top").times[0],"latest daily intrabar chosen beyond fixed30-day limit");
        eq(0,frame(chart(49153,bars,null,histories),in).drawings.size(),"historical monthly bar still selects first daily intrabar");
    }
    private static void levels(){
        long d=T;List<ChartData.Bar> chartBars=Arrays.asList(new ChartData.Bar(d,10,11,9,10),new ChartData.Bar(d+3600,10,15,8,12),new ChartData.Bar(d+82800,12,14,7,13),new ChartData.Bar(d+86400,13,14,12,13));
        List<ChartData.Bar> daily=Arrays.asList(new ChartData.Bar(d-86400,8,9,6,8),new ChartData.Bar(d,10,15,7,13),new ChartData.Bar(d+86400,13,14,12,13));
        Map<Integer,List<ChartData.Bar>> histories=new HashMap<Integer,List<ChartData.Bar>>();histories.put(16408,daily);Map<String,String> in=inputs();in.put("showFairValueGapsInput","false");in.put("showDailyLevelsInput","true");
        PlotFrame f=frame(chart(16385,chartBars.subList(0,3),chartBars.get(3),histories),in);eq(4,f.drawings.size(),"D1 high/low and labels");near(15,drawing(f,"smc_pDh").values[0],"new day immediately uses yesterday not day before");near(7,drawing(f,"smc_pDl").values[0],"previous daily low");eq(d+3600,drawing(f,"smc_pDh").times[0],"high anchored to actual intraday extreme time");eq(d+82800,drawing(f,"smc_pDl").times[0],"low anchored to actual intraday extreme time");eq(d+86400,drawing(f,"smc_pDh").times[1],"MTF line ends on actual last candle");eq(4,drawing(f,"smc_pDh_text").anchor,"MTF text left-center anchor");eq("PDH",drawing(f,"smc_pDh_text").text,"source daily high title");
        in.put("dailyLevelsStyleInput","----");eq(1,drawing(frame(chart(16385,chartBars,null,histories),in),"smc_pDh").style,"dashed MTF style");in.put("dailyLevelsStyleInput","····");eq(2,drawing(frame(chart(16385,chartBars,null,histories),in),"smc_pDh").style,"dotted MTF style");
        f=frame(chart(16408,daily.subList(0,2),daily.get(2),new HashMap<Integer,List<ChartData.Bar>>()),in);near(14,drawing(f,"smc_pDh").values[0],"same-TF level current high preserved");eq(d+86400,drawing(f,"smc_pDh").times[0],"same-TF anchor current broker time");
        f=frame(chart(32769,Arrays.asList(bar(0,10,11,9,10),bar(604800,11,12,10,11)),null,new HashMap<Integer,List<ChartData.Bar>>()),in);eq(0,f.drawings.size(),"daily levels suppressed on weekly chart without daily history");
        List<ChartData.Bar> monthly=Arrays.asList(new ChartData.Bar(d-2678400,10,18,6,12),new ChartData.Bar(d,12,15,8,14));Map<Integer,List<ChartData.Bar>> monthHistory=new HashMap<Integer,List<ChartData.Bar>>();monthHistory.put(49153,monthly);in.put("showDailyLevelsInput","false");in.put("showMonthlyLevelsInput","true");
        f=frame(chart(16408,chartBars,null,monthHistory),in);near(18,drawing(f,"smc_pMh").values[0],"actual31-day native monthly boundary");eq(d,drawing(f,"smc_pMh").times[0],"initialTime fallback when previous month predates available chart bars");
    }
    private static void timeframeAnchors(){
        int[] periods={16385,16388,15},steps={3600,14400,900};long[] starts={1800000000L,1900000000L,1600000000L};
        ChartData[] charts=new ChartData[3];Map<String,String> in=inputs();in.put("showFairValueGapsInput","false");in.put("showDailyLevelsInput","true");
        for(int i=0;i<periods.length;i++){
            long d=starts[i];double multiplier=i==0?1:i==1?10:100;
            List<ChartData.Bar> bars=Arrays.asList(new ChartData.Bar(d,10*multiplier,11*multiplier,9*multiplier,10*multiplier),new ChartData.Bar(d+steps[i],10*multiplier,15*multiplier,8*multiplier,12*multiplier),new ChartData.Bar(d+86400-steps[i],12*multiplier,14*multiplier,7*multiplier,13*multiplier),new ChartData.Bar(d+86400,13*multiplier,14*multiplier,12*multiplier,13*multiplier));
            Map<Integer,List<ChartData.Bar>> histories=new HashMap<Integer,List<ChartData.Bar>>();
            histories.put(16408,Arrays.asList(new ChartData.Bar(d-86400,8*multiplier,9*multiplier,6*multiplier,8*multiplier),new ChartData.Bar(d,10*multiplier,15*multiplier,7*multiplier,13*multiplier),bars.get(3)));
            charts[i]=chart(periods[i],bars.subList(0,3),bars.get(3),histories);
        }
        PlotFrame original=frame(charts[0],in);String saved=signature(original);
        for(int i=0;i<charts.length;i++){
            PlotFrame f=frame(charts[i],in);long last=starts[i]+86400;
            eq(4,f.drawings.size(),"H1/H4/M15 previous-day level geometry");
            eq(last,drawing(f,"smc_pDh").times[1],"H1/H4/M15 high line ends on actual last candle");
            eq(last,drawing(f,"smc_pDl").times[1],"H1/H4/M15 low line ends on actual last candle");
            eq(last,drawing(f,"smc_pDh_text").times[0],"H1/H4/M15 high label sits at last candle");
            eq(last,drawing(f,"smc_pDl_text").times[0],"H1/H4/M15 low label sits at last candle");
            boolean valid=true;double multiplier=i==0?1:i==1?10:100;
            for(PlotFrame.Drawing drawing:f.drawings){for(long time:drawing.times)if(time<starts[i]||time>last)valid=false;for(double price:drawing.values)if(price<7*multiplier||price>15*multiplier)valid=false;}
            check(valid,"new MTF frame contains only the selected timeframe's times/prices");
        }
        PlotFrame again=frame(charts[0],in);
        check(again!=original&&saved.equals(signature(again)),"H1 to H4 to M15 to H1 yields a new identical frame");
        eq(saved,signature(original),"later MTF calculations cannot mutate an earlier frame");
    }
    private static String signature(PlotFrame frame){StringBuilder s=new StringBuilder();for(PlotFrame.Drawing d:frame.drawings)s.append(d.key).append(Arrays.toString(d.times)).append(Arrays.toString(d.values)).append(d.color).append(d.text);return s.toString();}
    private static void missing(){
        final Map<String,String> in=inputs();in.put("fairValueGapsTimeframeInput","H4");final ChartData c=chart(1,bullBars(),null,new HashMap<Integer,List<ChartData.Bar>>());
        final PlotFrame f=new PlotFrame();rejectHistory(new Runnable(){public void run(){SmcMtf.append(f,c,in);}},"missing requested MTF is retryable and never silently uses chart");eq(0,f.drawings.size(),"missing MTF leaves frame unchanged");
        in.put("showFairValueGapsInput","false");in.put("showDailyLevelsInput","true");rejectHistory(new Runnable(){public void run(){SmcMtf.append(f,c,in);}},"missing daily history is retryable");
        Map<Integer,List<ChartData.Bar>> available=new HashMap<Integer,List<ChartData.Bar>>();available.put(16408,Arrays.asList(bar(-86400,10,12,8,11),bar(0,10,15,9,14)));
        SmcMtf.append(f,chart(1,bullBars(),null,available),in);eq(4,f.drawings.size(),"same module retries successfully after native history becomes available");
        in.put("showDailyLevelsInput","false");in.put("fairValueGapsTimeframeInput","H5");reject(new Runnable(){public void run(){SmcMtf.append(f,c,in);}},"unsupported selection rejected even when disabled");
    }
    private static Map<String,String> inputs(){Map<String,String> in=new HashMap<String,String>();in.put("fairValueGapsTimeframeInput","Current");in.put("showFairValueGapsInput","true");in.put("fairValueGapsThresholdInput","false");in.put("fairValueGapsBullColorInput","#4D00FF68");in.put("fairValueGapsBearColorInput","#4DFF0008");in.put("fairValueGapsExtendInput","1");in.put("styleInput","Colored");for(String kind:Arrays.asList("Daily","Weekly","Monthly"))in.put("show"+kind+"LevelsInput","false");for(String kind:Arrays.asList("daily","weekly","monthly")){in.put(kind+"LevelsStyleInput","⎯⎯⎯");in.put(kind+"LevelsColorInput","#FF2157F3");}return in;}
    private static ChartData.Bar bar(long offset,double o,double h,double l,double c){return new ChartData.Bar(T+offset,o,h,l,c);}
    private static ChartData chart(int period,List<ChartData.Bar> closed,ChartData.Bar forming,Map<Integer,List<ChartData.Bar>> histories){int seconds=period<16384?period*60:period<32768?(period-16384)*3600:period==32769?604800:2592000;return new ChartData(1,"demo","TEST",period,closed,forming,3,seconds,T+999999,histories);}
    private static PlotFrame frame(ChartData chart,Map<String,String> in){PlotFrame f=new PlotFrame();SmcMtf.append(f,chart,in);return f;}
    private static PlotFrame.Drawing drawing(PlotFrame f,String key){for(PlotFrame.Drawing d:f.drawings)if(d.key.equals(key))return d;throw new AssertionError("drawing missing: "+key);}
    private static void eq(long want,long have,String label){assertions++;if(want!=have)throw new AssertionError(label+": "+want+" != "+have);}
    private static void eq(String want,String have,String label){assertions++;if(!want.equals(have))throw new AssertionError(label+": "+want+" != "+have);}
    private static void near(double want,double have,String label){assertions++;if(!Double.isFinite(have)||Math.abs(want-have)>1e-10)throw new AssertionError(label+": "+want+" != "+have);}
    private static void check(boolean yes,String label){assertions++;if(!yes)throw new AssertionError(label);}
    private static void reject(Runnable task,String label){assertions++;try{task.run();}catch(IllegalArgumentException expected){return;}throw new AssertionError(label);}
    private static void rejectHistory(Runnable task,String label){assertions++;try{task.run();}catch(HistoryNotReadyException expected){return;}throw new AssertionError(label);}
}
