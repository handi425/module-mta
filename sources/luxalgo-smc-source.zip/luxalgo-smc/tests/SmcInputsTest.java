import converted.smc.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import java.lang.reflect.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import net.metaquotes.metatrader5.modules.api.*;

public final class SmcInputsTest {
    private static int checks;
    private static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
    private static void rejects(String key,String value){
        boolean rejected=false;try{SmcInputs.DESCRIPTOR.normalizeInputs(Collections.singletonMap(key,value));}catch(IllegalArgumentException expected){rejected=true;}
        check(rejected,"Reject invalid " + key + "=" + value);
    }
    public static void main(String[] args)throws Exception {
        ModuleDescriptor d=SmcInputs.DESCRIPTOR;
        check(d.id.equals("luxalgo.smc")&&d.apiVersion==5,"SMC needs deferred API5 and stable independent id");
        check(d.version.equals("1.0.2"),"background optimization is offered as a newer library module");
        Map<String,String> v=d.normalizeInputs(Collections.<String,String>emptyMap());
        Set<String> keys=new HashSet<String>();for(InputDefinition def:d.inputs)keys.add(def.key);
        Pattern input=Pattern.compile("^([A-Za-z][A-Za-z0-9_]*)\\s*=\\s*input");
        int original=0;
        for(String line:Files.readAllLines(Paths.get(args.length>0?args[0]:"mt5-modules/converted/smc/original.pine"),StandardCharsets.UTF_8)){
            Matcher m=input.matcher(line);if(m.find()){original++;check(keys.contains(m.group(1)),"Original input retained: "+m.group(1));}
        }
        check(original>50&&d.inputs.size()==original+8,"All original controls plus eight native section headings");
        check(v.get("modeInput").equals("Historical")&&v.get("styleInput").equals("Colored"),"Original mode/style defaults");
        for(String key:new String[]{"showTrendInput","showSwingsInput","showSwingOrderBlocksInput","showFairValueGapsInput","showDailyLevelsInput","showWeeklyLevelsInput","showMonthlyLevelsInput","showPremiumDiscountZonesInput"})check(v.get(key).equals("false"),key+" defaults off");
        for(String key:new String[]{"showInternalsInput","showStructureInput","showHighLowSwingsInput","showInternalOrderBlocksInput","showEqualHighsLowsInput","fairValueGapsThresholdInput"})check(v.get(key).equals("true"),key+" defaults on");
        check(v.get("swingsLengthInput").equals("50"),"Original swing length50");
        check(v.get("equalHighsLowsLengthInput").equals("3"),"Original EQH/EQL confirmation3");
        check(v.get("fairValueGapsTimeframeInput").equals("Current"),"Pine empty TF maps explicitly to Current");
        check(SmcMtf.timeframeChoices().length==22,"Current plus all21 MT5 periods");
        check(SmcInputs.c(v,"internalBullishOrderBlockColor")==0x333179f5,"OB original RGB and80%transparency");
        check(SmcInputs.c(v,"fairValueGapsBullColorInput")==0x4d00ff68,"FVG original RGB and70%transparency");
        check(SmcInputs.c(v,"equilibriumZoneColorInput")==0xff878b94,"Equilibrium original GRAY");
        check(new SMC().historyPeriods(Collections.<String,String>emptyMap()).length==0,"Default SMC requires no extra histories");
        check(new SMC().historyBars(v)==100000,"Use complete bounded broker history");
        rejects("swingsLengthInput","9");rejects("internalOrderBlocksSizeInput","21");
        rejects("equalHighsLowsLengthInput","0");rejects("equalHighsLowsThresholdInput","0.51");
        rejects("fairValueGapsExtendInput","-1");rejects("fairValueGapsTimeframeInput","H5");
        rejects("modeInput","Realtime");rejects("EnableNotifications","true");
        backgroundAndCache();coalescingAndDetach();boundedQueue();
        System.out.println("SMC inputs PASS: "+checks+" assertions, "+original+" original inputs");
    }
    // Exercise the module scheduler with host tickets without Android UI stubs.
    private static final Method SUBMIT=method("submit",ChartData.class,Map.class,DeferredPlot.class),CANCEL=method("cancel");
    private static Method method(String name,Class<?>... types){try{Method m=SMC.class.getDeclaredMethod(name,types);m.setAccessible(true);return m;}catch(Exception e){throw new AssertionError(e);}}
    private static void submit(SMC module,ChartData chart,Map<String,String> input,Ticket ticket)throws Exception{SUBMIT.invoke(module,chart,input,ticket);}
    private static void cancel(SMC module)throws Exception{CANCEL.invoke(module);}
    private static void idle(SMC module)throws Exception{
        Field state=SMC.class.getDeclaredField("scheduled"),lock=SMC.class.getDeclaredField("lock");state.setAccessible(true);lock.setAccessible(true);
        long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(10);
        for(;;){synchronized(lock.get(module)){if(!state.getBoolean(module))return;}if(System.nanoTime()>deadline)throw new AssertionError("worker failed to become idle");Thread.sleep(1);}
    }
    private static final class Ticket implements DeferredPlot {
        final CountDownLatch done=new CountDownLatch(1),entered=new CountDownLatch(1),release=new CountDownLatch(1);
        final AtomicInteger sequence;boolean block;
        volatile PlotFrame frame;volatile Throwable failure;volatile boolean live=true;volatile int order;volatile String thread;
        Ticket(){this(false,null);}Ticket(boolean block,AtomicInteger sequence){this.block=block;this.sequence=sequence;}
        public boolean isCurrent(){if(block){block=false;entered.countDown();try{if(!release.await(10,TimeUnit.SECONDS))throw new AssertionError("blocked test ticket timed out");}catch(InterruptedException e){throw new AssertionError(e);}}return live;}
        public void publish(PlotFrame frame){this.frame=frame;thread=Thread.currentThread().getName();if(sequence!=null)order=sequence.incrementAndGet();done.countDown();}
        public void fail(Throwable failure){this.failure=failure;done.countDown();}
        void await()throws Exception{check(done.await(10,TimeUnit.SECONDS),"worker responds within deadline");if(failure!=null)throw new AssertionError("unexpected worker failure",failure);}
    }
    private static List<ChartData.Bar> bars(){List<ChartData.Bar> bars=new ArrayList<ChartData.Bar>();for(int i=0;i<800;i++){double p=100+20*Math.sin(i*0.12);bars.add(new ChartData.Bar(1700000000L+i*60L,p,p+1,p-1,p,i,2L*i));}return bars;}
    private static ChartData chart(List<ChartData.Bar> bars,boolean forming,long quote,Map<Integer,List<ChartData.Bar>> histories){
        return new ChartData(7,"fixture","TEST",1,forming?bars.subList(0,bars.size()-1):bars,forming?bars.get(bars.size()-1):null,3,60,quote,histories);
    }
    private static Ticket request(SMC module,ChartData chart,Map<String,String> input)throws Exception{Ticket ticket=new Ticket();submit(module,chart,input,ticket);ticket.await();return ticket;}
    private static List<ChartData.Bar> copy(List<ChartData.Bar> source){List<ChartData.Bar> out=new ArrayList<ChartData.Bar>();for(ChartData.Bar b:source)out.add(new ChartData.Bar(b.time,b.open,b.high,b.low,b.close,b.tickVolume,b.realVolume));return out;}
    private static void backgroundAndCache()throws Exception{
        SMC module=new SMC();List<ChartData.Bar> bars=bars();Map<Integer,List<ChartData.Bar>> histories=Collections.emptyMap();Map<String,String> input=Collections.emptyMap();
        final Thread caller=Thread.currentThread();
        Map<String,String> workerOnly=new AbstractMap<String,String>(){
            public Set<Map.Entry<String,String>> entrySet(){check(Thread.currentThread()!=caller,"normalization occurs off chart thread");return Collections.emptySet();}
        };
        Ticket first=request(module,chart(bars,false,1,histories),workerOnly);
        check(first.thread.equals("SMC-calculation"),"plot submitted from dedicated background worker");
        Ticket unchanged=request(module,chart(copy(bars),false,2,histories),input);
        check(first.frame==unchanged.frame,"exact full-history match reuses frame despite new objects and quote timestamp");
        long[] stats=module.performanceStats();check(stats[0]==2&&stats[1]==1&&stats[2]==1,"requests, calculations and cache hits recorded separately");stats[0]=999;check(module.performanceStats()[0]==2,"statistics are a defensive snapshot");
        List<ChartData.Bar> revised=copy(bars);ChartData.Bar old=revised.get(0);revised.set(0,new ChartData.Bar(old.time,old.open,old.high+0.25,old.low,old.close,old.tickVolume,old.realVolume));
        check(request(module,chart(revised,false,3,histories),input).frame!=first.frame,"oldest historical OHLC revision invalidates cache");
        ChartData.Bar volume=revised.get(350);revised.set(350,new ChartData.Bar(volume.time,volume.open,volume.high,volume.low,volume.close,volume.tickVolume+1,volume.realVolume));
        request(module,chart(revised,false,4,histories),input);check(module.performanceStats()[1]==3,"interior historical volume revision invalidates cache");
        Ticket forming=request(module,chart(revised,true,5,histories),input);check(module.performanceStats()[1]==4,"forming/closed boundary is part of snapshot identity");
        check(request(module,chart(copy(revised),true,6,histories),input).frame==forming.frame,"identical forming OHLCV permits cache reuse");
        Map<String,String> changed=new HashMap<String,String>();changed.put("showSwingsInput","true");request(module,chart(revised,true,7,histories),changed);check(module.performanceStats()[1]==5,"changed normalized inputs invalidate cache");
        changed.put("showDailyLevelsInput","true");Map<Integer,List<ChartData.Bar>> mtf=new HashMap<Integer,List<ChartData.Bar>>();
        mtf.put(16408,Arrays.asList(new ChartData.Bar(1699920000L,100,150,50,100),new ChartData.Bar(1700006400L,100,150,50,100)));
        Ticket higher=request(module,chart(revised,true,8,mtf),changed);mtf.put(16388,Collections.singletonList(new ChartData.Bar(1699920000L,100,200,1,100)));
        check(request(module,chart(revised,true,9,mtf),changed).frame==higher.frame,"disabled unrelated MTF history is excluded from cache key");
        mtf.put(16408,Arrays.asList(new ChartData.Bar(1699920000L,100,151,50,100),new ChartData.Bar(1700006400L,100,150,50,100)));
        check(request(module,chart(revised,true,10,mtf),changed).frame!=higher.frame,"enabled MTF historical revision invalidates cache");
        Map<String,String> need=new HashMap<String,String>();need.put("showWeeklyLevelsInput","true");Ticket missing=new Ticket();submit(module,chart(revised,true,11,mtf),need,missing);
        check(missing.done.await(10,TimeUnit.SECONDS)&&missing.failure instanceof HistoryNotReadyException,"missing broker history remains retryable on worker");
        mtf.put(32769,Arrays.asList(new ChartData.Bar(1699000000L,100,150,50,100),new ChartData.Bar(1699604800L,100,150,50,100)));
        request(module,chart(revised,true,12,mtf),need);check(module.performanceStats()[7]>=module.performanceStats()[5],"compute timing includes maximum and latest durations");idle(module);cancel(module);
    }
    private static void coalescingAndDetach()throws Exception{
        SMC active=new SMC(),other=new SMC();AtomicInteger sequence=new AtomicInteger();Map<String,String> input=Collections.emptyMap();ChartData chart=chart(bars(),false,1,Collections.<Integer,List<ChartData.Bar>>emptyMap());
        Ticket blocking=new Ticket(true,sequence);submit(active,chart,input,blocking);check(blocking.entered.await(10,TimeUnit.SECONDS),"worker enters controlled calculation");
        Ticket latest=null;for(int i=0;i<1000;i++){latest=new Ticket(false,sequence);submit(active,chart,input,latest);}
        Ticket neighbor=new Ticket(false,sequence);submit(other,chart,input,neighbor);blocking.release.countDown();blocking.await();neighbor.await();latest.await();idle(active);idle(other);
        long[] stats=active.performanceStats();check(stats[0]==1001&&stats[3]==999&&stats[1]==1&&stats[2]==1,"one active and one latest pending snapshot coalesce a burst");
        check(neighbor.order<latest.order,"busy chart yields worker to another attachment");
        Ticket stale=new Ticket(true,null);submit(active,chart,input,stale);check(stale.entered.await(10,TimeUnit.SECONDS),"detach fixture starts active worker");Ticket pending=new Ticket();submit(active,chart,input,pending);cancel(active);stale.release.countDown();idle(active);
        check(stale.done.getCount()==1&&pending.done.getCount()==1,"detach drops active and pending results");check(active.performanceStats()[4]>0,"stale work is counted");
        long computations=active.performanceStats()[1];request(active,chart,input);check(active.performanceStats()[1]==computations+1,"detach clears cached snapshot and frame");idle(active);cancel(active);cancel(other);
    }
    private static void boundedQueue()throws Exception{
        SMC blockingModule=new SMC();ChartData chart=chart(bars(),false,1,Collections.<Integer,List<ChartData.Bar>>emptyMap());Map<String,String> input=Collections.emptyMap();Ticket block=new Ticket(true,null);submit(blockingModule,chart,input,block);check(block.entered.await(10,TimeUnit.SECONDS),"queue fixture blocks worker");
        List<SMC> queued=new ArrayList<SMC>();for(int i=0;i<32;i++){SMC module=new SMC();queued.add(module);submit(module,chart,input,new Ticket());}
        SMC overflow=new SMC();Ticket rejected=new Ticket();submit(overflow,chart,input,rejected);
        check(rejected.failure instanceof HistoryNotReadyException&&overflow.performanceStats()[1]==0,"bounded queue saturation is retryable without running calculation on caller");
        for(SMC module:queued)cancel(module);cancel(blockingModule);block.release.countDown();idle(blockingModule);for(SMC module:queued)idle(module);cancel(overflow);
    }
}
