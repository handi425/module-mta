import converted.smc.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import net.metaquotes.metatrader5.modules.api.*;

public final class SmcInputsTest {
    private static int checks;
    private static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
    private static void rejects(String key,String value){
        boolean rejected=false;try{SmcInputs.DESCRIPTOR.normalizeInputs(Collections.singletonMap(key,value));}catch(IllegalArgumentException expected){rejected=true;}
        check(rejected,"Reject invalid " + key + "=" + value);
    }
    public static void main(String[] args)throws Exception {
        ModuleDescriptor d=SmcInputs.DESCRIPTOR;
        check(d.id.equals("luxalgo.smc")&&d.apiVersion==4,"SMC needs API4 and stable independent id");
        Map<String,String> v=d.normalizeInputs(Collections.<String,String>emptyMap());
        Set<String> keys=new HashSet<String>();for(InputDefinition def:d.inputs)keys.add(def.key);
        Pattern input=Pattern.compile("^([A-Za-z][A-Za-z0-9_]*)\\s*=\\s*input");
        int original=0;
        for(String line:Files.readAllLines(Paths.get("mt5-modules/converted/smc/original.pine"),StandardCharsets.UTF_8)){
            Matcher m=input.matcher(line);if(m.find()){original++;check(keys.contains(m.group(1)),"Original input retained: "+m.group(1));}
        }
        check(original>50&&d.inputs.size()==original+8,"All original controls plus eight native section headings");
        check(v.get("modeInput").equals("Historical")&&v.get("styleInput").equals("Colored"),"Original mode/style defaults");
        for(String key:new String[]{"showTrendInput","showSwingsInput","showSwingOrderBlocksInput","showFairValueGapsInput","showDailyLevelsInput","showWeeklyLevelsInput","showMonthlyLevelsInput","showPremiumDiscountZonesInput"})check(v.get(key).equals("false"),key+" defaults off");
        for(String key:new String[]{"showInternalsInput","showStructureInput","showHighLowSwingsInput","showInternalOrderBlocksInput","showEqualHighsLowsInput","fairValueGapsThresholdInput"})check(v.get(key).equals("true"),key+" defaults on");
        check(v.get("swingsLengthInput").equals("50"),"Original swing length50");
        check(v.get("equalHighsLowsLengthInput").equals("3"),"Original EQH/EQL confirmation3");
        check(v.get("fairValueGapsTimeframeInput").equals("Current"),"Pine empty TF maps explicitly to Current");
        check(SmcMtf.timeframeChoices().length==22,"Current plus all21 MT5 periods");
        check(SmcInputs.c(v,"internalBullishOrderBlockColor")==0x333179f5,"OB original RGB and80%transparency");
        check(SmcInputs.c(v,"fairValueGapsBullColorInput")==0x4d00ff68,"FVG original RGB and70%transparency");
        check(SmcInputs.c(v,"equilibriumZoneColorInput")==0xff878b94,"Equilibrium original GRAY");
        check(new SMC().historyPeriods(Collections.<String,String>emptyMap()).length==0,"Default SMC requires no extra histories");
        check(new SMC().historyBars(v)==100000,"Use complete bounded broker history");
        rejects("swingsLengthInput","9");rejects("internalOrderBlocksSizeInput","21");
        rejects("equalHighsLowsLengthInput","0");rejects("equalHighsLowsThresholdInput","0.51");
        rejects("fairValueGapsExtendInput","-1");rejects("fairValueGapsTimeframeInput","H5");
        rejects("modeInput","Realtime");rejects("EnableNotifications","true");
        System.out.println("SMC inputs PASS: "+checks+" assertions, "+original+" original inputs");
    }
}
