import converted.smc.SmcCore;
import converted.smc.SmcInputs;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.metaquotes.metatrader5.modules.api.ChartData;
import net.metaquotes.metatrader5.modules.api.PlotFrame;

/** Analytical fixtures for the published LuxAlgo revision, not screenshots. */
public final class SmcCoreTest {
    private static int assertions;
    public static void main(String[] args) {
        emptyAndFlat();
        strictLegs();
        volatility();
        structureAndOrderBlocks();
        internalAndConfluence();
        mitigation();
        equalsAndPresentation();
        trailingAndCandles();
        limitsAndReplay();
        System.out.println("SmcCoreTest: "+assertions+" assertions passed");
    }
    private static void emptyAndFlat() {
        SmcCore.Result empty=run(new ArrayList<ChartData.Bar>(),options());
        check(empty.frame.drawings.isEmpty()&&empty.breaks.isEmpty()&&empty.pivots.isEmpty(),"empty history is passive");
        SmcCore.Result flat=run(flat(300),options());
        check(flat.breaks.isEmpty()&&flat.pivots.isEmpty(),"flat prices never form a strict leg or fabricated BOS");
        check(flat.internalBlocks.isEmpty()&&flat.swingBlocks.isEmpty(),"no block without a real structure break");
        check(!flat.frame.captureTaps&&flat.frame.buttons.isEmpty()&&flat.frame.oscillator==null,"no touches, trading controls, oscillator or notifications");
    }
    private static void strictLegs() {
        List<ChartData.Bar> rising=new ArrayList<ChartData.Bar>();for(int j=0;j<13;j++)rising.add(bar(j,100+j));
        SmcCore.Result result=run(rising,options("showSwingsInput","true"));
        SmcCore.PivotEvent low=pivot(result,false,false,false,0);
        check(low!=null&&low.confirmedAt==10,"first swing low confirms after exactly ten following bars");
        near(99.5,low.level,"pivot uses candidate price, not confirmation candle");
        check("HL".equals(find(result.frame,"swing_point_10_l").text),"first low versus na is HL in Pine");
        List<ChartData.Bar> tie=new ArrayList<ChartData.Bar>();
        for(int j=0;j<=10;j++)tie.add(bar(j,100+j));
        tie.add(bar(11,110));
        for(int j=12;j<=21;j++)tie.add(bar(j,110-(j-11)));
        result=run(tie,options());
        check(pivot(result,false,false,true,10)==null,"equal next-window high fails strict candidate comparison");
        check(pivot(result,false,false,true,11)!=null,"the last tied high can confirm once its own next window is strictly lower");
        check(result.breaks.isEmpty(),"new lower pivot is not itself a false crossover");
    }
    private static void volatility() {
        List<ChartData.Bar> seed=flat(200);
        SmcCore.Result before=run(seed,options());
        check(Double.isNaN(before.atr[198]),"ATR200 has no partial seed");near(1,before.atr[199],"ATR seed includes first high-low true range");
        seed.add(new ChartData.Bar(time(200),100,130,90,110));
        SmcCore.Result after=run(seed,options());
        near(1.195,after.atr[200],"Wilder recurrence retains199 parts of prior ATR");
        near(90,after.parsedHighs[200],"high-volatility parsed high deliberately swaps to raw low");
        near(130,after.parsedLows[200],"high-volatility parsed low deliberately swaps to raw high");
        List<ChartData.Bar> shortBars=flat(3);shortBars.set(1,new ChartData.Bar(time(1),100,120,80,100));
        SmcCore.Result atrShort=run(shortBars,options());near(120,atrShort.parsedHighs[1],"unseeded ATR never silently substitutes a short ATR");
        SmcCore.Result range=run(shortBars,options("orderBlockFilterInput","Cumulative Mean Range"));
        near(120,range.parsedHighs[1],"cumTR/bar_index denominator is index1 and threshold is twice40");
        near(100.5,range.parsedHighs[0],"na initial cumTR preserves first candle geometry");
        List<ChartData.Bar> initialRange=flat(4);
        initialRange.set(0,new ChartData.Bar(time(0),100,150,50,100));
        initialRange.set(3,new ChartData.Bar(time(3),100,110,90,100));
        range=run(initialRange,options("orderBlockFilterInput","Cumulative Mean Range"));
        near(90,range.parsedHighs[3],"cumTR skips undefined first true range rather than counting first high-low");
        List<ChartData.Bar> gap=flat(200);gap.add(new ChartData.Bar(time(200),120,121,119,120));
        after=run(gap,options());near(1.1,after.atr[200],"ATR includes previous-close gap, not only high-low");
    }
    private static void structureAndOrderBlocks() {
        List<ChartData.Bar> bars=wave(200,new int[]{200,220,240,260,280,300,320,340},new double[]{100,120,100,130,90,140,80,150});
        SmcCore.Result r=run(bars,options("showSwingOrderBlocksInput","true"));
        int[] indices={254,276,297,317,338};String[] tags={"BOS","CHoCH","CHoCH","CHoCH","CHoCH"};
        List<SmcCore.BreakEvent> swing=breaks(r,false);
        check(swing.size()==5,"analytical alternating structure has five breaks");
        for(int j=0;j<indices.length;j++){check(swing.get(j).index==indices[j],"strict close crossing index"+j);check(tags[j].equals(swing.get(j).tag),"trend transition tag"+j);}
        near(120.5,swing.get(0).level,"first bull break belongs to confirmed220high");
        check(swing.get(0).pivotIndex==220&&swing.get(0).bias==1,"break keeps pivot identity and bullish direction");
        check(r.swingTrend==1,"final structure trend is bullish");
        SmcCore.Result first=run(new ArrayList<ChartData.Bar>(bars.subList(0,261)),options("showSwingOrderBlocksInput","true"));
        check(first.swingBlocks.size()==1,"first bullish break creates one live swing block");
        SmcCore.OrderBlock block=first.swingBlocks.get(0);check(block.index==240&&block.bias==1,"bullish OB selects minimum parsed low from pivot to break");
        near(100.5,block.high,"block high from selected candle");near(99.5,block.low,"block low from same selected candle");
        check(count(first.frame,21)==0,"new exact/right rectangles do not use old price-expanding rectangle type");
        PlotFrame.Drawing box=find(first.frame,"swing_ob_0");check(box.times[0]==time(240)&&box.color==0x331848cc,"right-extended block keeps source coordinate and20percent alpha");
        PlotFrame.Drawing border=find(first.frame,"swing_ob_border_0");check(!border.filled&&border.color==box.color,"swing block has source-colored outline");
        List<ChartData.Bar> tied=new ArrayList<ChartData.Bar>(bars.subList(0,261));
        ChartData.Bar next=tied.get(241);tied.set(241,new ChartData.Bar(next.time,next.open,next.high,99.5,next.close));
        check(run(tied,options("showSwingOrderBlocksInput","true")).swingBlocks.get(0).index==240,"equal parsed minima select the earliest slice index");
        SmcCore.Result filtered=run(bars,options("showSwingBullInput","BOS","showSwingBearInput","BOS"));
        check(labelCount(filtered.frame,"BOS")==1&&labelCount(filtered.frame,"CHoCH")==0,"BOS display filter does not suppress underlying trend transitions");
        check(filtered.breaks.size()==r.breaks.size(),"display filtering preserves structure calculations");
    }
    private static void internalAndConfluence() {
        List<ChartData.Bar> nested=wave(20,new int[]{20,40,47,54,59,65},new double[]{100,122,110,118,112,125});
        SmcCore.Result r=run(nested,options("showSwingOrderBlocksInput","true"));
        SmcCore.BreakEvent internal=at(r,true,63),swing=at(r,false,64);
        check(internal!=null&&"BOS".equals(internal.tag),"nested internal118high breaks one bar before swing122high");
        near(118.5,internal.level,"internal pivot is54");check(internal.pivotIndex==54,"internal pivot identity");
        check(swing!=null&&swing.pivotIndex==40,"swing pivot remains earlier larger high");
        check(find(r.frame,"internal_bull_break_63").style==1&&find(r.frame,"swing_bull_break_64").style==3,"source internal dashed and swing solid line styles");
        SmcCore.OrderBlock block=blockAt(r.internalBlocks,59);check(block!=null,"internal OB selects intervening low59");
        check(maybe(r.frame,"internal_ob_border_0")==null&&find(r.frame,"internal_ob_0").filled,"internal order-block border remains absent");
        // ATR is na before200, so current candle is not volatility-swapped here.
        List<ChartData.Bar> currentExtreme=new ArrayList<ChartData.Bar>(nested.subList(0,64));
        ChartData.Bar at=currentExtreme.get(63);currentExtreme.set(63,new ChartData.Bar(at.time,at.open,500,1,at.close));
        SmcCore.Result excluding=run(currentExtreme,options("orderBlockMitigationInput","Close"));
        check(blockAt(excluding.internalBlocks,59)!=null&&blockAt(excluding.internalBlocks,63)==null,"OB slice excludes break candle even if it has the lowest low");
        SmcCore.Result confluence=run(nested,options("internalFilterConfluenceInput","true"));
        check(breaks(confluence,true).isEmpty(),"equal upper and literal lower wick expression fails both strict confluence tests");
        List<ChartData.Bar> biased=new ArrayList<ChartData.Bar>();
        for(ChartData.Bar bar:nested)biased.add(new ChartData.Bar(bar.time,bar.close-0.2,bar.high,bar.low,bar.close));
        confluence=run(biased,options("internalFilterConfluenceInput","true"));
        check(at(confluence,true,63)!=null,"literal min(close,open-low) confluence is retained exactly");
        List<ChartData.Bar> broad=wave(20,new int[]{20,40,60,80},new double[]{100,120,100,130});
        check(breaks(run(broad,options()),true).isEmpty(),"internal pivot equal to swing pivot is excluded");
    }
    private static void mitigation() {
        List<ChartData.Bar> bars=wave(200,new int[]{200,220,240,260},new double[]{100,120,100,130});
        bars.add(new ChartData.Bar(time(261),129,131,99.5,130));
        Map<String,String> config=options("showSwingOrderBlocksInput","true");
        check(blockAt(run(bars,config).swingBlocks,240)!=null,"touching block edge does not mitigate it");
        bars.set(261,new ChartData.Bar(time(261),129,131,99.49,130));
        SmcCore.Result wick=run(bars,config);check(blockAt(wick.swingBlocks,240)==null,"strict wick penetration removes bullish block");
        check(maybe(wick.frame,"swing_ob_0")==null,"mitigated block leaves no stale preallocated slot on chart");
        config=options("showSwingOrderBlocksInput","true","orderBlockMitigationInput","Close");
        check(blockAt(run(bars,config).swingBlocks,240)!=null,"Close mode keeps block despite wick penetration");
        bars.set(261,new ChartData.Bar(time(261),100,131,99,99.49));
        check(blockAt(run(bars,config).swingBlocks,240)==null,"Close mode removes block after closing beyond edge");
        List<ChartData.Bar> bear=wave(200,new int[]{200,220,240,260,280},new double[]{100,120,100,130,90});
        check(blockAt(run(bear,options("showSwingOrderBlocksInput","true")).swingBlocks,260)!=null,"bearish break stores maximum intervening parsed high");
        bear.add(new ChartData.Bar(time(281),90,130.5,89,90));
        check(blockAt(run(bear,options("showSwingOrderBlocksInput","true")).swingBlocks,260)!=null,"bearish block exact high touch does not mitigate");
        bear.set(281,new ChartData.Bar(time(281),90,130.51,89,90));
        check(blockAt(run(bear,options("showSwingOrderBlocksInput","true")).swingBlocks,260)==null,"bearish block high penetration mitigates");
        check(blockAt(run(bear,options("showSwingOrderBlocksInput","true","orderBlockMitigationInput","Close")).swingBlocks,260)!=null,"bearish Close mitigation ignores upper wick");
        List<ChartData.Bar> pair=wave(200,new int[]{200,220,240,260,280,300},new double[]{100,130,120,150,140,170});
        check(run(pair,options("showSwingOrderBlocksInput","true")).swingBlocks.size()==2,"two independent bullish blocks are live before common mitigation");
        pair.add(new ChartData.Bar(time(301),170,171,1,170));
        SmcCore.Result adjacent=run(pair,options("showSwingOrderBlocksInput","true"));
        check(adjacent.swingBlocks.size()==1&&adjacent.swingBlocks.get(0).index==240,"Pine forward-removal skips the adjacent shifted block until next candle");
        check(maybe(adjacent.frame,"swing_ob_1")==null,"skipped source block uses one current display slot without a leftover second box");
        pair.add(new ChartData.Bar(time(302),170,171,1,170));
        check(run(pair,options("showSwingOrderBlocksInput","true")).swingBlocks.isEmpty(),"next candle mitigates remaining adjacent source block");
    }
    private static void equalsAndPresentation() {
        List<ChartData.Bar> repeated=wave(200,new int[]{200,220,240,260,280,300,320},new double[]{100,120,100,120.05,100.03,120.07,100.04});
        SmcCore.Result r=run(repeated,options("showSwingsInput","true"));
        PlotFrame.Drawing eqh=find(r.frame,"equal_high_260");near(120.5,eqh.values[0],"EQH starts at older high");near(120.55,eqh.values[1],"EQH preserves slightly different new high");
        check(eqh.times[0]==time(220)&&eqh.times[1]==time(260)&&eqh.style==2,"EQH connects pivot times with dotted line");
        check(find(r.frame,"equal_high_260_text").times[0]==time(240),"equal label uses rounded pivot-index midpoint");
        check(labelCount(r.frame,"EQL")>=2,"equal lows have independent pivot history");
        SmcCore.Result zero=run(repeated,options("equalHighsLowsThresholdInput","0"));
        check(labelCount(zero.frame,"EQH")==0&&labelCount(zero.frame,"EQL")==0,"zero threshold rejects even equal prices because comparison is strict");
        SmcCore.Result recent=run(repeated,options("showSwingsInput","true","modeInput","Present"));
        check(labelCount(recent.frame,"EQH")==1&&labelCount(recent.frame,"EQL")==1,"Present deletes each equal-high and equal-low predecessor separately");
        int points=0;for(PlotFrame.Drawing d:recent.frame.drawings)if(d.key.startsWith("swing_point_"))points++;
        check(points==2,"Present retains one swing-high label and one swing-low label");
        List<ChartData.Bar> alternating=wave(200,new int[]{200,220,240,260,280,300,320,340},new double[]{100,120,100,130,90,140,80,150});
        SmcCore.Result historical=run(alternating,options()),present=run(alternating,options("modeInput","Present"));
        check(labelCount(historical.frame,"CHoCH")==4&&labelCount(present.frame,"CHoCH")==2,"Present deletion is per bullish/bearish structure call site");
        check(maybe(present.frame,"swing_bull_break_338")!=null&&maybe(present.frame,"swing_bear_break_317")!=null,"latest opposite directions coexist in Present");
        SmcCore.Result mono=run(alternating,options("styleInput","Monochrome","showSwingOrderBlocksInput","true"));
        check(find(mono.frame,"swing_bull_break_338").color==0xffb2b5be&&find(mono.frame,"swing_bear_break_317").color==0xff5d606b,"monochrome source palette");
        if(!mono.swingBlocks.isEmpty())check((find(mono.frame,"swing_ob_0").color>>>24)==51,"monochrome OB still80percent transparent");
    }
    private static void trailingAndCandles() {
        List<ChartData.Bar> all=wave(200,new int[]{200,220,240,260,280},new double[]{100,120,100,130,90});
        List<ChartData.Bar> first=new ArrayList<ChartData.Bar>(all.subList(0,255));
        SmcCore.Result before=run(first,options("showTrendInput","true","showHighLowSwingsInput","true","showPremiumDiscountZonesInput","true"));
        PlotFrame.Drawing high=find(before.frame,"strong_high"),highText=find(before.frame,"strong_high_text");
        check(high.times[1]==time(254)+20*60,"strong/weak endpoint uses20 actual most-recent candle intervals");
        check("Weak High".equals(highText.text),"same-bar bullish BOS not applied to earlier trailing display");
        check(highText.anchor==1&&find(before.frame,"strong_low_text").anchor==2,"strong/weak labels are candle-price anchored");
        PlotFrame.Drawing zone=find(before.frame,"zone_premium");
        near(121.5,zone.values[0],"trailing high includes current254high before visual output");
        near(120.4,zone.values[1],"premium band uses95/5 source weights");
        check((zone.color>>>24)==51&&zone.times[0]==time(240)&&zone.times[1]==time(254),"zone uses latest pivot start and exact last-bar edge");
        check(find(before.frame,"zone_equilibrium_text").anchor==4,"equilibrium preserves label.style_label_left");
        // Internal breaks63; color of that candle still sees neutral internalTrend.
        List<ChartData.Bar> nested=wave(20,new int[]{20,40,47,54,59,65},new double[]{100,122,110,118,112,125});
        SmcCore.Result colored=run(nested,options("showTrendInput","true"));
        check(colored.frame.candles.size()==1,"native candles are overpainted with a dedicated passive series");
        PlotFrame.Candles candles=colored.frame.candles.get(0);
        check("smc_candles".equals(candles.key),"candle series identity");
        int[] colors=candles.colors;
        check(colors[0]==0xfff23645&&colors[63]==0xfff23645&&colors[64]==0xff089981,"candle colors use prior internal trend, with neutral bearish");
        check(!colored.frame.captureTaps&&colored.frame.buttons.isEmpty(),"colored candles do not intercept chart gestures");
        ChartData full=chart(all);ChartData withForming=new ChartData(7,"fixture","TEST",1,new ArrayList<ChartData.Bar>(all.subList(0,all.size()-1)),all.get(all.size()-1),2,60,0,Collections.<Integer,List<ChartData.Bar>>emptyMap());
        check(signature(SmcCore.calculate(full,options())).equals(signature(SmcCore.calculate(withForming,options()))),"same bars replay identically whether last candle is forming");
    }
    private static void limitsAndReplay() {
        List<ChartData.Bar> trend=flat(200);int index=199;double price=100;
        for(int cycle=0;cycle<620;cycle++) {
            for(int k=1;k<=20;k++)trend.add(bar(++index,price+30*k/20.0));
            price+=30;
            for(int k=1;k<=20;k++)trend.add(bar(++index,price-10*k/20.0));
            price-=10;
        }
        Map<String,String> v=options("showSwingOrderBlocksInput","true","swingOrderBlocksSizeInput","20","showSwingsInput","true");
        SmcCore.Result r=run(trend,v);
        check(r.swingBlocks.size()==100,"persistent OB storage is bounded at100 newest entries");
        int boxes=0,lines=0,labels=0;for(PlotFrame.Drawing drawing:r.frame.drawings){if(drawing.key.startsWith("swing_ob_")&&drawing.filled)boxes++;if(drawing.type==2)lines++;if(drawing.type==101)labels++;}
        check(boxes==20,"only configured20 newest active blocks are drawn");check(lines==500&&labels==500,"long history respects independent Pine500-line and500-label caps");
        check(r.swingBlocks.get(0).index>r.swingBlocks.get(99).index,"block storage remains newest-first");
        PlotFrame once=SmcCore.calculate(chart(trend.subList(0,600)),v),twice=SmcCore.calculate(chart(trend.subList(0,600)),v);
        check(signature(once).equals(signature(twice)),"recalculation has no retained state or duplicated objects");
        PlotFrame shorter=SmcCore.calculate(chart(flat(30)),v);check(shorter.drawings.isEmpty(),"symbol/timeframe replacement cannot retain prior frame objects");
    }
    private static Map<String,String> options(String... pairs) {
        Map<String,String> input=new HashMap<String,String>();
        input.put("swingsLengthInput","10");input.put("showHighLowSwingsInput","false");
        for(int j=0;j<pairs.length;j+=2)input.put(pairs[j],pairs[j+1]);
        return SmcInputs.DESCRIPTOR.normalizeInputs(input);
    }
    private static SmcCore.Result run(List<ChartData.Bar> bars,Map<String,String> inputs){return SmcCore.replay(chart(bars),inputs);}
    private static ChartData chart(List<ChartData.Bar> bars){return new ChartData(7,"fixture","TEST",1,new ArrayList<ChartData.Bar>(bars));}
    private static long time(int index){return 1700000000L+index*60L;}
    private static ChartData.Bar bar(int index,double close){return new ChartData.Bar(time(index),close,close+0.5,close-0.5,close);}
    private static List<ChartData.Bar> flat(int count){List<ChartData.Bar> bars=new ArrayList<ChartData.Bar>();for(int j=0;j<count;j++)bars.add(bar(j,100));return bars;}
    private static List<ChartData.Bar> wave(int prefix,int[] indices,double[] levels) {
        List<ChartData.Bar> out=flat(prefix);for(int segment=0;segment<indices.length-1;segment++)for(int at=indices[segment];at<indices[segment+1];at++) {
            double fraction=(at-indices[segment])/(double)(indices[segment+1]-indices[segment]);out.add(bar(at,levels[segment]+fraction*(levels[segment+1]-levels[segment])));
        }
        out.add(bar(indices[indices.length-1],levels[levels.length-1]));return out;
    }
    private static List<SmcCore.BreakEvent> breaks(SmcCore.Result r,boolean internal){List<SmcCore.BreakEvent> out=new ArrayList<SmcCore.BreakEvent>();for(SmcCore.BreakEvent event:r.breaks)if(event.internal==internal)out.add(event);return out;}
    private static SmcCore.BreakEvent at(SmcCore.Result r,boolean internal,int index){for(SmcCore.BreakEvent event:r.breaks)if(event.internal==internal&&event.index==index)return event;return null;}
    private static SmcCore.PivotEvent pivot(SmcCore.Result r,boolean internal,boolean equal,boolean high,int index){for(SmcCore.PivotEvent event:r.pivots)if(event.internal==internal&&event.equal==equal&&event.high==high&&event.index==index)return event;return null;}
    private static SmcCore.OrderBlock blockAt(List<SmcCore.OrderBlock> blocks,int index){for(SmcCore.OrderBlock block:blocks)if(block.index==index)return block;return null;}
    private static int labelCount(PlotFrame frame,String label){int count=0;for(PlotFrame.Drawing drawing:frame.drawings)if(label.equals(drawing.text))count++;return count;}
    private static int count(PlotFrame frame,int type){int count=0;for(PlotFrame.Drawing drawing:frame.drawings)if(drawing.type==type)count++;return count;}
    private static PlotFrame.Drawing maybe(PlotFrame frame,String key){for(PlotFrame.Drawing drawing:frame.drawings)if(key.equals(drawing.key))return drawing;return null;}
    private static PlotFrame.Drawing find(PlotFrame frame,String key){PlotFrame.Drawing found=maybe(frame,key);check(found!=null,"expected drawing "+key);return found;}
    private static String signature(PlotFrame frame){StringBuilder s=new StringBuilder();for(PlotFrame.Drawing d:frame.drawings)s.append(d.key).append(':').append(d.type).append(':').append(java.util.Arrays.toString(d.times)).append(':').append(java.util.Arrays.toString(d.values)).append(':').append(d.color).append(':').append(d.text).append(';');return s.toString();}
    private static void near(double expected,double actual,String message){check(Math.abs(expected-actual)<1e-8,message+" expected="+expected+" actual="+actual);}
    private static void check(boolean condition,String message){assertions++;if(!condition)throw new AssertionError(message);}
}
