package net.metaquotes.metatrader5.modules.api;

import java.util.ArrayList;
import java.util.List;

/** Time/price geometry. Times are broker bar timestamps in seconds; styles 1=dash,2=dot,3=solid. */
public final class PlotFrame {
    public final List<Drawing> drawings = new ArrayList<Drawing>();
    /** API4 candle batches are projected with the chart's bar spacing on paint. */
    public final List<Candles> candles = new ArrayList<Candles>();
    public Oscillator oscillator;
    public boolean captureTaps;
    public final List<Button> buttons=new ArrayList<Button>();
    public PlotFrame button(String key,String label,int right,int top,int width,int height){buttons.add(new Button(key,label,right,top,width,height));return this;}
    public PlotFrame anchor(String key,long time,double price,int color){drawings.add(new Drawing(key,0,1002,new long[]{time},new double[]{price},color,1,3,false,null,0));return this;}
    public static final class Button {
        public final String key,label;public final int right,top,width,height;
        Button(String key,String label,int right,int top,int width,int height){this.key=key;this.label=label;this.right=right;this.top=top;this.width=width;this.height=height;}
    }
    public PlotFrame horizontalLine(String key,int pane,double price,int color,int width,int style) {
        drawings.add(new Drawing(key,pane,1,new long[]{1},new double[]{price},color,width,style,false,null,0));return this;
    }
    /** Price-scale flag, anchored only to value; it creates no native chart object. */
    public PlotFrame priceMarker(String key,int pane,double price,String text,int color,int size) {
        if(!Double.isFinite(price)||text==null||text.isEmpty()||text.length()>64||size<6||size>40)throw new IllegalArgumentException("Invalid price marker");
        drawings.add(new Drawing(key,pane,1003,new long[]{1},new double[]{price},color,1,3,false,text,size));return this;
    }
    public PlotFrame line(String key,int pane,long t1,double p1,long t2,double p2,int color,int width,int style) {
        drawings.add(new Drawing(key,pane,2,new long[]{t1,t2},new double[]{p1,p2},color,width,style,false,null,0));return this;
    }
    public PlotFrame curve(String key,int pane,long[] times,double[] values,int color,int width,int style) {
        drawings.add(new Drawing(key,pane,1001,times,values,color,width,style,false,null,0));return this;
    }
    public PlotFrame rectangle(String key,int pane,long t1,double top,long t2,double bottom,int color,boolean filled) {
        drawings.add(new Drawing(key,pane,21,new long[]{t1,t2},new double[]{top,bottom},color,1,3,filled,null,0));return this;
    }
    /** API4 rectangle preserves the requested alpha, including its outline. */
    public PlotFrame exactRectangle(String key,int pane,long t1,double top,long t2,double bottom,int color,boolean filled) {
        requireRectangle(top,bottom);
        drawings.add(new Drawing(key,pane,1005,new long[]{t1,t2},new double[]{top,bottom},color,1,3,filled,null,0));return this;
    }
    /** API4 rectangle extends to the pane edge while keeping its starting time and prices fixed. */
    public PlotFrame rightRectangle(String key,int pane,long t1,double top,double bottom,int color,boolean filled) {
        requireRectangle(top,bottom);
        drawings.add(new Drawing(key,pane,1006,new long[]{t1,t1},new double[]{top,bottom},color,1,3,filled,null,0));return this;
    }
    public PlotFrame candleSeries(String key,int pane,long[] times,double[] open,double[] high,double[] low,double[] close,int[] colors) {
        if(candles.size()>=8)throw new IllegalArgumentException("Too many candle series");
        int count=times==null?0:times.length;for(Candles series:candles)count+=series.times.length;
        if(count>100000)throw new IllegalArgumentException("Candle frame exceeds chart budget");
        candles.add(new Candles(key,pane,times,open,high,low,close,colors));return this;
    }
    private static void requireRectangle(double top,double bottom) {
        if(!Double.isFinite(top)||!Double.isFinite(bottom))throw new IllegalArgumentException("Invalid rectangle prices");
    }
    public PlotFrame triangle(String key,int pane,long[] times,double[] prices,int color,boolean filled) {
        if(times.length!=3)throw new IllegalArgumentException("Triangle needs three anchors");
        drawings.add(new Drawing(key,pane,22,times,prices,color,1,3,filled,null,0));return this;
    }
    public PlotFrame text(String key,int pane,long time,double price,String text,int color,int size) {
        drawings.add(new Drawing(key,pane,101,new long[]{time},new double[]{price},color,1,3,false,text,size));return this;
    }
    /** 1: bottom center, 2: top center, 3: center, 4: left center. Anchors never follow viewport edges. */
    public PlotFrame anchoredText(String key,int pane,long time,double price,String text,int color,int size,int anchor,boolean bold) {
        if(anchor<1||anchor>4)throw new IllegalArgumentException("Unsupported text anchor");
        drawings.add(new Drawing(key,pane,101,new long[]{time},new double[]{price},color,1,3,false,text,size,anchor,bold));return this;
    }
    public PlotFrame oscillator(String name,int period,int appliedPrice,double minimum,double maximum,double[] levels,int color,int width) {
        oscillator=new Oscillator(name,period,appliedPrice,minimum,maximum,levels,color,width);return this;
    }
    public static final class Drawing {
        public final String key,text;
        public final int pane,type,color,width,style,size;
        public final boolean filled;
        public final int anchor;
        public final boolean bold;
        public final long[] times;
        public final double[] values;
        Drawing(String key,int pane,int type,long[] times,double[] values,int color,int width,int style,boolean filled,String text,int size) {
            this(key,pane,type,times,values,color,width,style,filled,text,size,0,false);
        }
        Drawing(String key,int pane,int type,long[] times,double[] values,int color,int width,int style,boolean filled,String text,int size,int anchor,boolean bold) {
            if(key==null||key.isEmpty()||key.length()>128||pane<0||pane>1||times==null||values==null||times.length!=values.length||times.length>100000||width<1||width>5||style<1||style>3)
                throw new IllegalArgumentException("Invalid chart drawing");
            for(int i=0;i<times.length;i++)if(times[i]<=0||Double.isInfinite(values[i]))throw new IllegalArgumentException("Invalid drawing anchor");
            this.key=key;this.pane=pane;this.type=type;this.times=times.clone();this.values=values.clone();this.color=color;
            this.width=width;this.style=style;this.filled=filled;this.text=text;this.size=size;
            this.anchor=anchor;this.bold=bold;
        }
    }
    /** Defensive copies keep a published batch independent of plugin work arrays. */
    public static final class Candles {
        public final String key;
        public final int pane;
        public final long[] times;
        public final double[] open,high,low,close;
        public final int[] colors;
        private Candles(String key,int pane,long[] times,double[] open,double[] high,double[] low,double[] close,int[] colors) {
            if(key==null||key.isEmpty()||key.length()>128||pane<0||pane>1||times==null||open==null||high==null||low==null||close==null||colors==null||
                    times.length<1||times.length>100000||open.length!=times.length||high.length!=times.length||low.length!=times.length||close.length!=times.length||colors.length!=times.length)
                throw new IllegalArgumentException("Invalid candle batch");
            long previous=0;
            for(int i=0;i<times.length;i++){
                if(times[i]<=previous||!Double.isFinite(open[i])||!Double.isFinite(high[i])||!Double.isFinite(low[i])||!Double.isFinite(close[i])||
                        high[i]<low[i]||open[i]<low[i]||open[i]>high[i]||close[i]<low[i]||close[i]>high[i])
                    throw new IllegalArgumentException("Invalid candle OHLC or time");
                previous=times[i];
            }
            this.key=key;this.pane=pane;this.times=times.clone();this.open=open.clone();this.high=high.clone();this.low=low.clone();this.close=close.clone();this.colors=colors.clone();
        }
    }
    public static final class Oscillator {
        public final String name;public final int period,appliedPrice,color,width;
        public final double minimum,maximum;public final double[] levels;
        Oscillator(String name,int period,int appliedPrice,double minimum,double maximum,double[] levels,int color,int width) {
            if(!"Relative Strength Index".equals(name)||period<1||appliedPrice<0||appliedPrice>6||levels==null||levels.length>16||minimum>=maximum)
                throw new IllegalArgumentException("Unsupported native oscillator");
            this.name=name;this.period=period;this.appliedPrice=appliedPrice;this.minimum=minimum;this.maximum=maximum;
            this.levels=levels.clone();this.color=color;this.width=width;
        }
    }
}
