package net.metaquotes.metatrader5.modules.api;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ModuleDescriptor {
    public static final int API_VERSION = 4;
    public final String id, name, version;
    public final int apiVersion;
    public final List<InputDefinition> inputs;

    public ModuleDescriptor(String id, String name, String version, int apiVersion, List<InputDefinition> inputs) {
        if (!validId(id) || name == null || name.isEmpty() || name.length() > 128 || version == null ||
                version.isEmpty() || version.length() > 32 || !supportsApiVersion(apiVersion) || inputs == null || inputs.size() > 128)
            throw new IllegalArgumentException("Unsupported module descriptor");
        this.id = id; this.name = name; this.version = version; this.apiVersion = apiVersion;
        List<InputDefinition> copy = new ArrayList<InputDefinition>(inputs);
        HashSet<String> keys = new HashSet<String>();
        for (InputDefinition input : copy) if (input == null || !keys.add(input.key))
            throw new IllegalArgumentException("Duplicate module input");
        this.inputs = Collections.unmodifiableList(copy);
    }

    public Map<String, String> normalizeInputs(Map<String, String> supplied) {
        Map<String, String> values = new LinkedHashMap<String, String>();
        for (InputDefinition input : inputs) values.put(input.key,
                input.validate(supplied != null && supplied.containsKey(input.key) ? supplied.get(input.key) : input.defaultValue));
        if (supplied != null) for (String key : supplied.keySet()) if (!values.containsKey(key))
            throw new IllegalArgumentException("Unknown module input: " + key);
        return Collections.unmodifiableMap(values);
    }

    public static boolean validId(String value) {
        return value != null && value.length() >= 3 && value.length() <= 64 &&
                value.matches("[a-z][a-z0-9]*([._-][a-z0-9]+)*");
    }
    /** Earlier native, Canvas and price-marker modules remain loadable. */
    public static boolean supportsApiVersion(int value) { return value >= 1 && value <= API_VERSION; }
}
