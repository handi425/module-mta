package net.metaquotes.metatrader5.modules.api;

/** API4: requested broker history is still loading. The host clears this
 * instance's frame and retries on a later chart tick without faulting it. */
public final class HistoryNotReadyException extends IllegalStateException {
    public HistoryNotReadyException(String message) { super(message); }
}
