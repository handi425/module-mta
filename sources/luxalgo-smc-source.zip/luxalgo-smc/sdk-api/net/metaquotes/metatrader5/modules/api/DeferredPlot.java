package net.metaquotes.metatrader5.modules.api;

/** API5 calculation ticket. Obtain on the chart thread, calculate on a worker,
 * and submit once; the host dispatches to the UI and rejects stale ownership,
 * chart identities, lifecycle epochs and out-of-order results. */
public interface DeferredPlot {
    boolean isCurrent();
    void publish(PlotFrame frame);
    void fail(Throwable failure);
}
