# Smart Money Concepts [LuxAlgo] — Android conversion

Original indicator: © LuxAlgo, [official TradingView publication](https://www.tradingview.com/script/CnB3fSph-Smart-Money-Concepts-SMC-LuxAlgo/).
This independent port and the retained Pine source are distributed under
[CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/), for
noncommercial use and redistribution. See `LICENSE.txt`. This port is not
endorsed by LuxAlgo or MetaQuotes.

`original.pine` is the complete official public revision7.0 (848 lines), updated
2025-09-23. The supplied `provided-partial.pine` is its exact554-line prefix;
the missing final294 lines were retrieved from the author's public source
endpoint. Complete source SHA-256:
`880717919e24049e19271cc41ba408b93d4dd4e556034b6d837084593db6275a`.

## Runtime and settings

SMC1.0.1 requires the custom Android API4 host (minimum APK6314); APK6315 /
500.6310-mtc.5 is recommended for its chart-layer cleanup fix. The host continues
to accept old API1–3 modules; the seven pre-existing binary files (five custom
ports and two development examples) are not rebuilt by this release. The public
catalog lists six custom indicators. The SMC package is an explicit Java/Canvas conversion,
not a Pine Script interpreter and not an EA. There are no order APIs, alerts,
sound, email, push or Android notifications in the executable SMC code.

All52 source input controls and defaults are retained, with eight section
headings for native MT5 parameters. The source's empty FVG timeframe is shown
as `Current`. The21 supported native MT5 periods are listed explicitly; an
unsupported/missing timeframe is rejected instead of substituting another.
While requested broker history is still loading, the instance clears its own
frame and retries on later chart ticks; no permanent failure or auto-removal
is recorded merely because a timeframe is not ready.
Color inputs retain their original values. SMC1.0.1 caps only OB/FVG fill alpha
at0x26 (38/255, about15% opacity), preserving RGB and any already lower opacity.
Border RGB/alpha and premium/discount/equilibrium zone behavior are unchanged.
Tiny/small/normal fonts use8/10/12dp.

Features include internal/swing BOS and CHoCH, confluence filtering, HH/HL/LH/LL,
strong/weak high/low, internal/swing order blocks, EQH/EQL, FVG, daily/weekly/
monthly highs/lows, premium/discount/equilibrium and optional trend candles.
Historical/Present behavior retains separate drawing call-site lifetimes.

## Calculation and drawing behavior

The core replays the available broker candles in source order, including the
leg confirmation delay, previous-series crossover, ATR200 warmup, cumulative
true-range filter, parsed OB extrema and strict mitigation. Candle colors and
trailing outputs use the source's pre-structure-update state. The confluence
expression and bearish FVG's inverted stored bounds are preserved literally.

FVG security mapping follows lookahead-on historical values, and uses the
latest available partial higher/lower-period broker candle for the forming
bar. Broker history boundaries determine daily, weekly and monthly periods;
months are not synthesized as30 days. Historical higher-timeframe FVG values
can therefore differ from what was visible intrabar, as in the source's
lookahead-on calculation.

The port recomputes MTF levels from the current snapshot rather than retaining
the source's new-bar-only label refresh. This avoids a one-chart-bar delay at a
new broker period and can update same-timeframe high/low intrabar. Previous
period levels use the previous completed broker bar, with extrema times drawn
from available chart history. Data feeds/session calendars can differ from
TradingView; identical pixels/signals across different feeds are not asserted.

Drawings use transient Canvas data, with no native graphic objects, touch
controls or retained geometry after removal/timeframe changes. The left time
and price anchors remain fixed; source extend-right boxes end at the pane edge.
In SMC1.0.1, strong/weak and MTF line endpoints and labels use the latest real
chart candle's time instead of the source's20-bar future offset. Their price
anchors stay exact, and they are never pinned to a viewport edge. FVG boxes
retain their explicit Extend FVG setting. Mitigated OB slots are cleared instead of
preserving the original preallocated-box artifact. Source500-line/500-label/
500-box visual limits are respected; FVG uses two colored boxes with borders.

APK6315 protects replacement chart layers from queued cleanup by a retired
layer. This is a host fix with API4 unchanged; it does not remove indicator
attachments or re-create chart objects when changing timeframe.

The host adds candle batches (only visible bars are painted), exact-opacity
rectangles and extend-right rectangles for API4. Existing legacy rectangles
and FiboZone transparency retain their previous behavior.

## Build and tests

From the complete private project, run:

```powershell
./mt5-modules/build-converted-module.ps1 -SourceDirectory ./mt5-modules/converted/smc/src -EntryClass converted.smc.SMC -OutputPath ./output/indicators/smc.mt5ind -ModuleReadmePath ./mt5-modules/converted/smc/README.txt
./tests/run-converted-tests.ps1
./tests/module-api/run-tests.ps1
```

The signed package contains its attribution README and links to the public
source ZIP. The public ZIP includes source-only SDK interfaces, the original
Pine, modified Java, tests, provenance, checksums and unsigned build commands.
It contains no host implementation, account data or signing keys.
