package converted.smc;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.TreeSet;
import net.metaquotes.metatrader5.modules.api.ChartData;
import net.metaquotes.metatrader5.modules.api.HistoryNotReadyException;
import net.metaquotes.metatrader5.modules.api.PlotFrame;

/** MTF/FVG adaptation of Smart Money Concepts [LuxAlgo], copyright LuxAlgo.
 * CC BY-NC-SA 4.0: https://creativecommons.org/licenses/by-nc-sa/4.0/
 * See original.pine and the distributed attribution/license. No alerts or orders.
 * Native broker bar boundaries are authoritative; no synthetic daily/monthly bars.
 */
public final class SmcMtf {
    private static final String[] TIMEFRAMES={"Current","M1","M2","M3","M4","M5","M6","M10","M12","M15","M20","M30","H1","H2","H3","H4","H6","H8","H12","D1","W1","MN1"};
    private static final int[] PERIODS={0,1,2,3,4,5,6,10,12,15,20,30,16385,16386,16387,16388,16390,16392,16396,16408,32769,49153};
    private static final int MAX_FVG_PAIRS=250; // Pine's 500-box drawing budget.
    private SmcMtf() {}

    public static String[] timeframeChoices(){return TIMEFRAMES.clone();}

    public static int[] historyPeriods(Map<String,String> input){
        TreeSet<Integer> periods=new TreeSet<Integer>();
        int fvg=period(value(input,"fairValueGapsTimeframeInput")); // Validate even if currently disabled.
        if(bool(input,"showFairValueGapsInput")&&fvg!=0)periods.add(fvg);
        if(bool(input,"showDailyLevelsInput"))periods.add(16408);
        if(bool(input,"showWeeklyLevelsInput"))periods.add(32769);
        if(bool(input,"showMonthlyLevelsInput"))periods.add(49153);
        int[] out=new int[periods.size()];int at=0;for(Integer p:periods)out[at++]=p;return out;
    }

    public static void append(PlotFrame frame,ChartData chart,Map<String,String> input){
        if(frame==null||chart==null||input==null)throw new IllegalArgumentException("SMC chart/input unavailable");
        int requested=period(value(input,"fairValueGapsTimeframeInput"));
        if(chart.closedBars.isEmpty()&&chart.formingBar==null)return;
        boolean fvg=bool(input,"showFairValueGapsInput"),daily=bool(input,"showDailyLevelsInput"),weekly=bool(input,"showWeeklyLevelsInput"),monthly=bool(input,"showMonthlyLevelsInput");
        if(!fvg&&!daily&&!weekly&&!monthly)return;
        List<ChartData.Bar> bars=chart.allBars();
        validateBars(bars,"chart");
        // Validate every enabled request before adding any partial MTF output.
        List<ChartData.Bar> gaps=null;
        if(fvg)gaps=history(chart,bars,requested==0?chart.period:requested);
        if(daily&&duration(chart.period)<=duration(16408))history(chart,bars,16408);
        if(weekly&&duration(chart.period)<=duration(32769))history(chart,bars,32769);
        if(monthly&&duration(chart.period)<=duration(49153))history(chart,bars,49153);
        if(gaps!=null)appendGaps(frame,chart,bars,gaps,requested==0?chart.period:requested,input);
        if(daily)appendLevels(frame,chart,bars,16408,"D",value(input,"dailyLevelsStyleInput"),color(input,"dailyLevelsColorInput"));
        if(weekly)appendLevels(frame,chart,bars,32769,"W",value(input,"weeklyLevelsStyleInput"),color(input,"weeklyLevelsColorInput"));
        if(monthly)appendLevels(frame,chart,bars,49153,"M",value(input,"monthlyLevelsStyleInput"),color(input,"monthlyLevelsColorInput"));
    }

    private static final class Gap {
        final long left,right;final double top,bottom;final boolean bullish;final int color;
        Gap(long left,long right,double top,double bottom,boolean bullish,int color){this.left=left;this.right=right;this.top=top;this.bottom=bottom;this.bullish=bullish;this.color=color;}
    }

    private static void appendGaps(PlotFrame frame,ChartData chart,List<ChartData.Bar> bars,List<ChartData.Bar> security,int fvgPeriod,Map<String,String> input){
        List<Gap> active=new ArrayList<Gap>();
        boolean auto=bool(input,"fairValueGapsThresholdInput"),mono=value(input,"styleInput").equals("Monochrome");
        int bull=mono?0x4db2b5be:color(input,"fairValueGapsBullColorInput"),bear=mono?0x4d5d606b:color(input,"fairValueGapsBearColorInput");
        int extend=integer(input,"fairValueGapsExtendInput");if(extend<0)throw new IllegalArgumentException("Extend FVG must be nonnegative");
        double cumulative=0;long previousTime=Long.MIN_VALUE;
        for(int i=0;i<bars.size();i++){
            ChartData.Bar bar=bars.get(i);
            // Source iterates newest-first and removes forwards. Incrementing
            // after removal intentionally retains the shifted next element.
            for(int g=0;g<active.size();g++){
                Gap gap=active.get(g);
                if((gap.bullish&&bar.low<gap.bottom)||(!gap.bullish&&bar.high>gap.top))active.remove(g);
            }
            boolean realtime=chart.formingBar!=null&&i==bars.size()-1;
            int current=securityIndex(security,bars,i,chart.period,fvgPeriod,realtime);
            if(current<0)continue;
            ChartData.Bar now=security.get(current);
            boolean changed=i>0&&now.time!=previousTime;previousTime=now.time;
            double delta=current>0&&security.get(current-1).open!=0?
                (security.get(current-1).close-security.get(current-1).open)/(security.get(current-1).open*100):Double.NaN;
            if(changed&&Double.isFinite(delta))cumulative+=Math.abs(delta);
            double threshold=auto?(i==0?Double.NaN:cumulative/i*2):0;
            if(!changed||current<2||!Double.isFinite(delta)||!Double.isFinite(threshold))continue;
            ChartData.Bar last=security.get(current-1),last2=security.get(current-2);
            boolean bullish=now.low>last2.high&&last.close>last2.high&&delta>threshold;
            boolean bearish=now.high<last2.low&&last.close<last2.low&&-delta>threshold;
            if(!bullish&&!bearish)continue;
            long step=i>0?bar.time-bars.get(i-1).time:Math.max(1,chart.periodSeconds);
            long right=future(now.time,extend,step);
            // The original bearish record deliberately stores top < bottom.
            // Its later strict high > top mitigation must not be normalized.
            if(bullish)active.add(0,new Gap(last.time,right,now.low,last2.high,true,bull));
            if(bearish)active.add(0,new Gap(last.time,right,now.high,last2.low,false,bear));
            // Old box IDs are garbage-collected by Pine and never resurrect.
            while(active.size()>MAX_FVG_PAIRS)active.remove(active.size()-1);
        }
        for(int i=active.size()-1;i>=0;i--){
            Gap gap=active.get(i);double middle=(gap.top+gap.bottom)/2;
            box(frame,"smc_fvg_"+i+"_top",gap.left,gap.top,gap.right,middle,gap.color);
            box(frame,"smc_fvg_"+i+"_bottom",gap.left,middle,gap.right,gap.bottom,gap.color);
        }
    }

    private static void box(PlotFrame frame,String key,long left,double top,long right,double bottom,int color){
        frame.exactRectangle(key,0,left,top,right,bottom,SmcVisuals.zoneFill(color),true);
        frame.exactRectangle(key+"_border",0,left,top,right,bottom,color,false);
    }

    private static void appendLevels(PlotFrame frame,ChartData chart,List<ChartData.Bar> bars,int period,String title,String inputStyle,int color){
        if(duration(chart.period)>duration(period))return;
        List<ChartData.Bar> security=history(chart,bars,period);
        ChartData.Bar last=bars.get(bars.size()-1);
        double high,low;long highTime,lowTime;
        if(chart.period==period){high=last.high;low=last.low;highTime=lowTime=last.time;}
        else {
            int current=floor(security,last.time);if(current<1)return;
            ChartData.Bar previous=security.get(current-1),currentBar=security.get(current);
            high=previous.high;low=previous.low;
            highTime=extremeTime(bars,previous.time,currentBar.time,true);
            lowTime=extremeTime(bars,previous.time,currentBar.time,false);
        }
        long right=last.time;int style=style(inputStyle);
        frame.line("smc_p"+title+"h",0,highTime,high,right,high,color,1,style);
        frame.line("smc_p"+title+"l",0,lowTime,low,right,low,color,1,style);
        frame.anchoredText("smc_p"+title+"h_text",0,right,high,"P"+title+"H",color,10,4,false);
        frame.anchoredText("smc_p"+title+"l_text",0,right,low,"P"+title+"L",color,10,4,false);
        // Source refreshes these objects on initial load/new bars. This snapshot
        // port resamples the live same-TF high/low and never lags a new HTF boundary.
    }

    private static long extremeTime(List<ChartData.Bar> bars,long left,long right,boolean high){
        long time=bars.get(0).time;double extreme=high?Double.NEGATIVE_INFINITY:Double.POSITIVE_INFINITY;
        int at=lowerBound(bars,left);
        for(;at<bars.size()&&bars.get(at).time<right;at++){
            ChartData.Bar b=bars.get(at);double v=high?b.high:b.low;
            if(high?v>extreme:v<extreme){extreme=v;time=b.time;}
        }
        return time; // Original initialTime fallback when the period predates chart history.
    }

    private static int securityIndex(List<ChartData.Bar> security,List<ChartData.Bar> bars,int i,int chartPeriod,int requested,boolean realtime){
        ChartData.Bar bar=bars.get(i);
        if(duration(requested)>=duration(chartPeriod))return floor(security,bar.time);
        int first=lowerBound(security,bar.time);
        long end=i+1<bars.size()?bars.get(i+1).time:realtime?Long.MAX_VALUE:nextBoundary(bar.time,chartPeriod);
        if(first>=security.size()||security.get(first).time>=end)return -1;
        if(!realtime)return first; // lookahead_on selects first historical LTF intrabar.
        int last=floor(security,end-1);return Math.max(first,last); // realtime: latest available intrabar.
    }

    private static List<ChartData.Bar> history(ChartData chart,List<ChartData.Bar> bars,int period){
        if(period==chart.period)return bars;
        List<ChartData.Bar> history=chart.history(period);
        if(history.isEmpty())throw new HistoryNotReadyException("Riwayat SMC "+name(period)+" belum tersedia");
        validateBars(history,name(period));return history;
    }
    private static void validateBars(List<ChartData.Bar> bars,String label){long previous=0;for(ChartData.Bar b:bars){if(b==null||b.time<=previous)throw new IllegalArgumentException("Riwayat SMC "+label+" tidak berurutan");previous=b.time;}}
    private static int lowerBound(List<ChartData.Bar> bars,long time){int lo=0,hi=bars.size();while(lo<hi){int mid=(lo+hi)>>>1;if(bars.get(mid).time<time)lo=mid+1;else hi=mid;}return lo;}
    private static int floor(List<ChartData.Bar> bars,long time){int at=lowerBound(bars,time);return at<bars.size()&&bars.get(at).time==time?at:at-1;}
    private static long future(long time,int count,long step){if(time<=0||count<0||step<=0||count>(Long.MAX_VALUE-time)/step)throw new IllegalArgumentException("SMC future time exceeds range");return time+count*step;}
    private static long nextBoundary(long time,int period){
        if(period!=49153)return future(time,1,duration(period));
        // Only needed when a historical final chart bar has no following native
        // boundary. A month is never treated as a fixed30-day interval.
        Calendar month=Calendar.getInstance(TimeZone.getTimeZone("UTC"));month.setTimeInMillis(Math.multiplyExact(time,1000L));month.add(Calendar.MONTH,1);return month.getTimeInMillis()/1000L;
    }
    private static long duration(int p){boolean valid=false;for(int candidate:PERIODS)if(candidate!=0&&candidate==p){valid=true;break;}if(!valid)throw new IllegalArgumentException("Timeframe SMC tidak didukung");if(p<=30)return p*60L;if(p<=16408)return (p-16384)*3600L;if(p==32769)return 604800L;return 2592000L;}
    private static int period(String text){for(int i=0;i<TIMEFRAMES.length;i++)if(TIMEFRAMES[i].equals(text))return PERIODS[i];throw new IllegalArgumentException("Timeframe FVG SMC tidak didukung: "+text);}
    private static String name(int period){for(int i=0;i<PERIODS.length;i++)if(PERIODS[i]==period)return TIMEFRAMES[i];throw new IllegalArgumentException("Timeframe SMC tidak didukung");}
    private static int style(String value){if(value.equals("⎯⎯⎯"))return 3;if(value.equals("----"))return 1;if(value.equals("····"))return 2;throw new IllegalArgumentException("SMC line style unsupported");}
    private static String value(Map<String,String> input,String key){String value=input.get(key);if(value==null)throw new IllegalArgumentException("SMC input missing: "+key);return value;}
    private static boolean bool(Map<String,String> input,String key){String v=value(input,key);if(!v.equals("true")&&!v.equals("false"))throw new IllegalArgumentException("SMC boolean invalid: "+key);return Boolean.parseBoolean(v);}
    private static int integer(Map<String,String> input,String key){return Integer.parseInt(value(input,key));}
    private static int color(Map<String,String> input,String key){return net.metaquotes.metatrader5.modules.api.InputDefinition.parseColor(value(input,key));}
}
