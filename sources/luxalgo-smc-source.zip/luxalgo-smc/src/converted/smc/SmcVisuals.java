package converted.smc;

/**
 * Visual adaptation of Smart Money Concepts [LuxAlgo], Copyright LuxAlgo.
 * CC BY-NC-SA 4.0: https://creativecommons.org/licenses/by-nc-sa/4.0/
 * User-requested OB/FVG fill cap; preserve RGB and already lower opacity.
 */
final class SmcVisuals {
    private SmcVisuals() {}
    static int zoneFill(int color) {
        return (color&0x00ffffff)|(Math.min(color>>>24,0x26)<<24);
    }
}
