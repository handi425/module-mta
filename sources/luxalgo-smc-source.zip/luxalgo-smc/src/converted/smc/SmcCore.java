package converted.smc;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.metaquotes.metatrader5.modules.api.ChartData;
import net.metaquotes.metatrader5.modules.api.PlotFrame;

/**
 * Noncommercial Android adaptation of Smart Money Concepts [LuxAlgo], public
 * TradingView revision 7.0 (2025-09-23), Copyright LuxAlgo.
 * https://www.tradingview.com/script/CnB3fSph-Smart-Money-Concepts-SMC-LuxAlgo/
 * CC BY-NC-SA 4.0: https://creativecommons.org/licenses/by-nc-sa/4.0/
 * Changes: deterministic OHLC replay, passive Canvas geometry, no alerts, and
 * removed order-block boxes do not retain stale preallocated display slots.
 */
public final class SmcCore {
    private static final int BULL=1, BEAR=-1, MONO_BULL=0xffb2b5be, MONO_BEAR=0xff5d606b;
    private SmcCore() {}

    /** Inputs are normalized by the module descriptor before this call. */
    public static PlotFrame calculate(ChartData chart,Map<String,String> values) {
        return replay(chart,values).frame;
    }

    /** Replay diagnostics are also used by independent fixture tests. */
    public static final class Result {
        public final PlotFrame frame;
        public final List<BreakEvent> breaks;
        public final List<PivotEvent> pivots;
        public final List<OrderBlock> internalBlocks,swingBlocks;
        public final double[] atr,parsedHighs,parsedLows;
        public final int internalTrend,swingTrend;
        private Result(Engine e,PlotFrame frame) {
            this.frame=frame;breaks=Collections.unmodifiableList(e.breaks);
            pivots=Collections.unmodifiableList(e.pivotEvents);
            internalBlocks=Collections.unmodifiableList(new ArrayList<OrderBlock>(e.internalBlocks));
            swingBlocks=Collections.unmodifiableList(new ArrayList<OrderBlock>(e.swingBlocks));
            atr=e.atr;parsedHighs=e.parsedHighs;parsedLows=e.parsedLows;
            internalTrend=e.internalTrend;swingTrend=e.swingTrend;
        }
    }
    public static final class BreakEvent {
        public final boolean internal;
        public final int index,pivotIndex,bias;
        public final double level;
        public final String tag;
        BreakEvent(boolean internal,int index,Pivot pivot,int bias,String tag) {
            this.internal=internal;this.index=index;this.pivotIndex=pivot.index;
            this.level=pivot.level;this.bias=bias;this.tag=tag;
        }
    }
    public static final class PivotEvent {
        public final boolean internal,equal,high;
        public final int index,confirmedAt;
        public final double level;
        PivotEvent(boolean internal,boolean equal,boolean high,int index,int at,double level) {
            this.internal=internal;this.equal=equal;this.high=high;this.index=index;
            this.confirmedAt=at;this.level=level;
        }
    }
    public static final class OrderBlock {
        public final int index,bias;
        public final double high,low;
        public final long time;
        OrderBlock(int index,int bias,List<ChartData.Bar> bars,double[] highs,double[] lows) {
            this.index=index;this.bias=bias;time=bars.get(index).time;
            high=highs[index];low=lows[index];
        }
    }
    private static final class Pivot {
        double level=Double.NaN,last=Double.NaN;
        int index;
        boolean crossed;
    }
    private static final class Trailing {
        double top=Double.NaN,bottom=Double.NaN;
        int index=-1,topIndex=-1,bottomIndex=-1;
    }

    public static Result replay(ChartData chart,Map<String,String> normalized) {
        if(chart==null)throw new IllegalArgumentException("Missing chart");
        Map<String,String> values=normalized==null?SmcInputs.DESCRIPTOR.normalizeInputs(null):normalized;
        Engine e=new Engine(chart,values);
        return e.run();
    }

    /** One independent Pine function call-site history per leg length/context. */
    private static final class Leg {
        final int size;
        final ArrayDeque<Integer> high=new ArrayDeque<Integer>(),low=new ArrayDeque<Integer>();
        int state;
        Leg(int size){this.size=size;}
        int update(List<ChartData.Bar> bars,int i) {
            ChartData.Bar b=bars.get(i);
            while(!high.isEmpty()&&bars.get(high.peekLast()).high<=b.high)high.removeLast();
            while(!low.isEmpty()&&bars.get(low.peekLast()).low>=b.low)low.removeLast();
            high.addLast(i);low.addLast(i);
            while(high.peekFirst()<=i-size)high.removeFirst();
            while(low.peekFirst()<=i-size)low.removeFirst();
            if(i<size)return 0;
            int previous=state;
            ChartData.Bar candidate=bars.get(i-size);
            if(candidate.high>bars.get(high.peekFirst()).high)state=0;
            else if(candidate.low<bars.get(low.peekFirst()).low)state=1;
            return state-previous;
        }
    }

    /** Range extrema with first-index tie-breaking, excluding the break candle. */
    private static final class Extremes {
        final int base;
        final int[] max,min;
        final double[] highs,lows;
        Extremes(double[] highs,double[] lows) {
            this.highs=highs;this.lows=lows;int b=1;
            while(b<highs.length)b<<=1;
            base=b;max=new int[b*2];min=new int[b*2];Arrays.fill(max,-1);Arrays.fill(min,-1);
            for(int i=0;i<highs.length;i++)max[b+i]=min[b+i]=i;
            for(int i=b-1;i>0;i--){max[i]=pick(max[i*2],max[i*2+1],true);min[i]=pick(min[i*2],min[i*2+1],false);}
        }
        int pick(int a,int b,boolean maximum) {
            if(a<0)return b;if(b<0)return a;
            double x=maximum?highs[a]:lows[a],y=maximum?highs[b]:lows[b];
            if(x==y)return Math.min(a,b);
            return (maximum?x>y:x<y)?a:b;
        }
        int index(int from,int exclusiveTo,boolean maximum) {
            int result=-1,l=base+from,r=base+exclusiveTo;int[] tree=maximum?max:min;
            while(l<r){if((l&1)!=0)result=pick(result,tree[l++],maximum);if((r&1)!=0)result=pick(result,tree[--r],maximum);l>>=1;r>>=1;}
            return result;
        }
    }

    /** Pine has separate 500-object limits for lines, labels, and boxes. */
    private static final class Geometry {
        final LinkedHashMap<String,PlotFrame.Drawing> objects=new LinkedHashMap<String,PlotFrame.Drawing>();
        final ArrayDeque<String> lines=new ArrayDeque<String>(),labels=new ArrayDeque<String>(),boxes=new ArrayDeque<String>();
        final int[] counts=new int[3];
        final Map<String,String[]> present=new LinkedHashMap<String,String[]>();
        final boolean recent;
        Geometry(boolean recent){this.recent=recent;}
        int kind(PlotFrame.Drawing d){return d.type==101?1:d.type==2?0:2;}
        ArrayDeque<String> queue(int kind){return kind==0?lines:kind==1?labels:boxes;}
        void remove(String key){PlotFrame.Drawing old=objects.remove(key);if(old!=null)counts[kind(old)]--;}
        void add(PlotFrame primitive) {
            PlotFrame.Drawing d=primitive.drawings.get(0);remove(d.key);int k=kind(d);
            objects.put(d.key,d);queue(k).addLast(d.key);counts[k]++;
            while(counts[k]>500){String key=queue(k).removeFirst();remove(key);}
        }
        void replaceScope(String scope,String...keys) {
            if(!recent)return;
            String[] previous=present.put(scope,keys);
            if(previous!=null)for(String key:previous)remove(key);
        }
    }

    private static final class Engine {
        final ChartData chart;
        final Map<String,String> v;
        final List<ChartData.Bar> bars;
        final int n;
        final boolean mono;
        final Geometry geometry;
        final double[] atr,parsedHighs,parsedLows;
        final int[] candleColors;
        final List<BreakEvent> breaks=new ArrayList<BreakEvent>();
        final List<PivotEvent> pivotEvents=new ArrayList<PivotEvent>();
        final List<OrderBlock> internalBlocks=new ArrayList<OrderBlock>(),swingBlocks=new ArrayList<OrderBlock>();
        final Pivot swingHigh=new Pivot(),swingLow=new Pivot(),internalHigh=new Pivot(),internalLow=new Pivot(),equalHigh=new Pivot(),equalLow=new Pivot();
        final Trailing trailing=new Trailing();
        final Leg swingLeg,internalLeg=new Leg(5),equalLeg;
        final Extremes extremes;
        int internalTrend,swingTrend;
        Engine(ChartData chart,Map<String,String> v) {
            this.chart=chart;this.v=v;bars=chart.allBars();n=bars.size();
            mono="Monochrome".equals(s("styleInput"));geometry=new Geometry("Present".equals(s("modeInput")));
            atr=new double[n];parsedHighs=new double[n];parsedLows=new double[n];candleColors=new int[n];
            swingLeg=new Leg(i("swingsLengthInput"));equalLeg=new Leg(i("equalHighsLowsLengthInput"));
            prepare();extremes=new Extremes(parsedHighs,parsedLows);
        }
        boolean b(String key){return SmcInputs.b(v,key);}
        int i(String key){return SmcInputs.i(v,key);}
        double d(String key){return SmcInputs.d(v,key);}
        int c(String key){return SmcInputs.c(v,key);}
        String s(String key){return SmcInputs.s(v,key);}
        int ink(boolean bullish,boolean internal) {
            if(mono)return bullish?MONO_BULL:MONO_BEAR;
            return c(internal?(bullish?"internalBullColorInput":"internalBearColorInput"):(bullish?"swingBullColorInput":"swingBearColorInput"));
        }
        void prepare() {
            double seed=0,rma=Double.NaN,cumulative=0;
            for(int j=0;j<n;j++) {
                ChartData.Bar bar=bars.get(j);
                double tr=j==0?bar.high-bar.low:Math.max(bar.high-bar.low,Math.max(Math.abs(bar.high-bars.get(j-1).close),Math.abs(bar.low-bars.get(j-1).close)));
                if(j<200){seed+=tr;if(j==199)rma=seed/200.0;}else rma=(rma*199.0+tr)/200.0;
                atr[j]=rma;
                // ta.tr (without handle_na) is na on bar zero, unlike ta.atr's TR.
                if(j>0)cumulative+=tr;
                double volatility="Atr".equals(s("orderBlockFilterInput"))?rma:(j==0?Double.NaN:cumulative/j);
                boolean volatileBar=bar.high-bar.low>=2*volatility;
                parsedHighs[j]=volatileBar?bar.low:bar.high;
                parsedLows[j]=volatileBar?bar.high:bar.low;
            }
        }
        Result run() {
            for(int j=0;j<n;j++) {
                ChartData.Bar bar=bars.get(j);
                double oldSwingHigh=swingHigh.level,oldSwingLow=swingLow.level,oldInternalHigh=internalHigh.level,oldInternalLow=internalLow.level;
                // Original execution order: visuals see the trend before today's breaks.
                candleColors[j]=ink(internalTrend==BULL,false);
                if(b("showHighLowSwingsInput")||b("showPremiumDiscountZonesInput")) {
                    trailing.top=Math.max(bar.high,trailing.top);
                    if(trailing.top==bar.high)trailing.topIndex=j;
                    trailing.bottom=Math.min(bar.low,trailing.bottom);
                    if(trailing.bottom==bar.low)trailing.bottomIndex=j;
                    if(j==n-1)trailingGeometry(j);
                }
                pivot(j,swingLeg,false,false);
                pivot(j,internalLeg,false,true);
                if(b("showEqualHighsLowsInput"))pivot(j,equalLeg,true,false);
                if(b("showInternalsInput")||b("showInternalOrderBlocksInput")||b("showTrendInput"))structure(j,true,oldInternalHigh,oldInternalLow);
                if(b("showStructureInput")||b("showSwingOrderBlocksInput")||b("showHighLowSwingsInput"))structure(j,false,oldSwingHigh,oldSwingLow);
                if(b("showInternalOrderBlocksInput"))mitigate(internalBlocks,bar);
                if(b("showSwingOrderBlocksInput"))mitigate(swingBlocks,bar);
            }
            if(n>0){if(b("showInternalOrderBlocksInput"))blockGeometry(internalBlocks,true);if(b("showSwingOrderBlocksInput"))blockGeometry(swingBlocks,false);}
            PlotFrame frame=new PlotFrame();
            if(b("showTrendInput")&&n>0) {
                int count=Math.min(n,100000),offset=n-count;
                long[] time=new long[count];double[] open=new double[count],high=new double[count],low=new double[count],close=new double[count];int[] colors=new int[count];
                for(int k=0;k<count;k++){ChartData.Bar bar=bars.get(k+offset);time[k]=bar.time;open[k]=bar.open;high[k]=bar.high;low[k]=bar.low;close[k]=bar.close;colors[k]=candleColors[k+offset];}
                frame.candleSeries("smc_candles",0,time,open,high,low,close,colors);
            }
            frame.drawings.addAll(geometry.objects.values());return new Result(this,frame);
        }
        void pivot(int at,Leg leg,boolean equal,boolean internal) {
            int change=leg.update(bars,at);if(change==0)return;
            boolean high=change<0;int index=at-leg.size;
            Pivot p=equal?(high?equalHigh:equalLow):internal?(high?internalHigh:internalLow):(high?swingHigh:swingLow);
            double level=high?bars.get(index).high:bars.get(index).low;
            if(equal&&Math.abs(p.level-level)<d("equalHighsLowsThresholdInput")*atr[at])equalGeometry(p,index,level,high);
            p.last=p.level;p.level=level;p.crossed=false;p.index=index;
            pivotEvents.add(new PivotEvent(internal,equal,high,index,at,level));
            if(!equal&&!internal) {
                trailing.index=index;
                if(high){trailing.top=level;trailing.topIndex=index;}else{trailing.bottom=level;trailing.bottomIndex=index;}
                if(b("showSwingsInput")) {
                    String key="swing_point_"+at+(high?"_h":"_l");geometry.replaceScope(high?"swing_high":"swing_low",key);
                    String tag=high?(p.level>p.last?"HH":"LH"):(p.level<p.last?"LL":"HL");
                    text(key,index,level,tag,ink(!high,false),10,high?1:2);
                }
            }
        }
        void equalGeometry(Pivot p,int index,double level,boolean high) {
            String key="equal_"+(high?"high_":"low_")+index;
            geometry.replaceScope(high?"equal_high":"equal_low",key,key+"_text");
            int color=ink(!high,false);
            line(key,p.index,p.level,index,level,color,2);
            text(key+"_text",(int)Math.round((p.index+index)*0.5),level,high?"EQH":"EQL",color,SmcInputs.size(s("equalHighsLowsSizeInput")),high?1:2);
        }
        void structure(int at,boolean internal,double previousHigh,double previousLow) {
            if(at==0)return;
            ChartData.Bar bar=bars.get(at);double previousClose=bars.get(at-1).close;
            boolean bullishBar=true,bearishBar=true;
            if(b("internalFilterConfluenceInput")) {
                double upper=bar.high-Math.max(bar.close,bar.open),literalLower=Math.min(bar.close,bar.open-bar.low);
                bullishBar=upper>literalLower;bearishBar=upper<literalLower;
            }
            Pivot high=internal?internalHigh:swingHigh,low=internal?internalLow:swingLow;
            boolean differentHigh=finite(internalHigh.level)&&finite(swingHigh.level)&&internalHigh.level!=swingHigh.level;
            boolean differentLow=finite(internalLow.level)&&finite(swingLow.level)&&internalLow.level!=swingLow.level;
            if(bar.close>high.level&&previousClose<=previousHigh&&!high.crossed&&(!internal||differentHigh&&bullishBar))broken(at,internal,high,BULL);
            if(bar.close<low.level&&previousClose>=previousLow&&!low.crossed&&(!internal||differentLow&&bearishBar))broken(at,internal,low,BEAR);
        }
        void broken(int at,boolean internal,Pivot p,int bias) {
            int oldTrend=internal?internalTrend:swingTrend;
            String tag=oldTrend==-bias?"CHoCH":"BOS";
            breaks.add(new BreakEvent(internal,at,p,bias,tag));p.crossed=true;
            if(internal)internalTrend=bias;else swingTrend=bias;
            String filter=s(internal?(bias==BULL?"showInternalBullInput":"showInternalBearInput"):(bias==BULL?"showSwingBullInput":"showSwingBearInput"));
            boolean show=b(internal?"showInternalsInput":"showStructureInput")&&("All".equals(filter)||tag.equals(filter));
            if(show) {
                String scope=(internal?"internal_":"swing_")+(bias==BULL?"bull":"bear"),key=scope+"_break_"+at;
                geometry.replaceScope(scope,key,key+"_text");
                int color=ink(bias==BULL,internal);
                line(key,p.index,p.level,at,p.level,color,internal?1:3);
                text(key+"_text",(int)Math.round((p.index+at)*0.5),p.level,tag,color,SmcInputs.size(s(internal?"internalStructureSize":"swingStructureSize")),bias==BULL?1:2);
            }
            if(b(internal?"showInternalOrderBlocksInput":"showSwingOrderBlocksInput")) {
                int index=extremes.index(p.index,at,bias==BEAR);
                if(index>=0){List<OrderBlock> blocks=internal?internalBlocks:swingBlocks;if(blocks.size()>=100)blocks.remove(blocks.size()-1);blocks.add(0,new OrderBlock(index,bias,bars,parsedHighs,parsedLows));}
            }
        }
        void mitigate(List<OrderBlock> blocks,ChartData.Bar bar) {
            boolean close="Close".equals(s("orderBlockMitigationInput"));
            double bearish=close?bar.close:bar.high,bullish=close?bar.close:bar.low;
            // Match Pine's forward array enumeration while removing at index:
            // the next shifted element is visited on the following candle.
            for(int index=0;index<blocks.size();index++) {
                OrderBlock block=blocks.get(index);
                if(block.bias==BEAR?bearish>block.high:bullish<block.low)blocks.remove(index);
            }
        }
        void blockGeometry(List<OrderBlock> blocks,boolean internal) {
            int count=Math.min(blocks.size(),i(internal?"internalOrderBlocksSizeInput":"swingOrderBlocksSizeInput"));
            for(int j=0;j<count;j++) {
                OrderBlock block=blocks.get(j);
                int color=mono?alpha(block.bias==BULL?MONO_BULL:MONO_BEAR,51):c(internal?(block.bias==BULL?"internalBullishOrderBlockColor":"internalBearishOrderBlockColor"):(block.bias==BULL?"swingBullishOrderBlockColor":"swingBearishOrderBlockColor"));
                geometry.add(new PlotFrame().rightRectangle((internal?"internal_ob_":"swing_ob_")+j,0,block.time,block.high,block.low,SmcVisuals.zoneFill(color),true));
                if(!internal)geometry.add(new PlotFrame().rightRectangle("swing_ob_border_"+j,0,block.time,block.high,block.low,color,false));
            }
        }
        void trailingGeometry(int at) {
            ChartData.Bar last=bars.get(at);
            if(b("showHighLowSwingsInput")&&at>0) {
                // Keep annotations on a real candle when timeframe/spacing changes.
                long right=last.time;
                if(finite(trailing.top)&&trailing.topIndex>=0) {
                    geometry.add(new PlotFrame().line("strong_high",0,bars.get(trailing.topIndex).time,trailing.top,right,trailing.top,ink(false,false),1,3));
                    geometry.add(new PlotFrame().anchoredText("strong_high_text",0,right,trailing.top,swingTrend==BEAR?"Strong High":"Weak High",ink(false,false),8,1,false));
                }
                if(finite(trailing.bottom)&&trailing.bottomIndex>=0) {
                    geometry.add(new PlotFrame().line("strong_low",0,bars.get(trailing.bottomIndex).time,trailing.bottom,right,trailing.bottom,ink(true,false),1,3));
                    geometry.add(new PlotFrame().anchoredText("strong_low_text",0,right,trailing.bottom,swingTrend==BULL?"Strong Low":"Weak Low",ink(true,false),8,2,false));
                }
            }
            if(b("showPremiumDiscountZonesInput")&&finite(trailing.top)&&finite(trailing.bottom)&&trailing.index>=0) {
                double top=trailing.top,bottom=trailing.bottom;
                int mid=(int)Math.round((trailing.index+at)*0.5);
                zone("premium",mid,top,top,0.95*top+0.05*bottom,"Premium",mono?MONO_BEAR:c("premiumZoneColorInput"),1);
                zone("equilibrium",at,(top+bottom)*0.5,0.525*top+0.475*bottom,0.525*bottom+0.475*top,"Equilibrium",c("equilibriumZoneColorInput"),4);
                zone("discount",mid,bottom,0.95*bottom+0.05*top,bottom,"Discount",mono?MONO_BULL:c("discountZoneColorInput"),2);
            }
        }
        void zone(String key,int labelIndex,double level,double top,double bottom,String tag,int color,int anchor) {
            geometry.add(new PlotFrame().exactRectangle("zone_"+key,0,bars.get(trailing.index).time,top,bars.get(n-1).time,bottom,alpha(color,51),true));
            text("zone_"+key+"_text",labelIndex,level,tag,color,10,anchor);
        }
        void line(String key,int from,double first,int to,double second,int color,int style) {
            geometry.add(new PlotFrame().line(key,0,bars.get(from).time,first,bars.get(to).time,second,color,1,style));
        }
        void text(String key,int index,double level,String label,int color,int size,int anchor) {
            geometry.add(new PlotFrame().anchoredText(key,0,bars.get(index).time,level,label,color,size,anchor,false));
        }
    }
    private static int alpha(int color,int alpha){return color&0x00ffffff|alpha<<24;}
    private static boolean finite(double value){return !Double.isNaN(value)&&!Double.isInfinite(value);}
}
