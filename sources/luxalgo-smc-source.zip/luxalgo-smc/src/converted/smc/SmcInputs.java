// Derived from Smart Money Concepts [LuxAlgo], © LuxAlgo.
// CC BY-NC-SA 4.0: https://creativecommons.org/licenses/by-nc-sa/4.0/
// Android conversion: typed native parameter definitions; notifications removed.
package converted.smc;

import java.util.Arrays;
import java.util.Map;
import net.metaquotes.metatrader5.modules.api.InputDefinition;
import net.metaquotes.metatrader5.modules.api.ModuleDescriptor;

public final class SmcInputs {
    private SmcInputs() {}
    public static final int GREEN=0xff089981, RED=0xfff23645, BLUE=0xff2157f3;
    public static final int MONO_BULLISH=0xffb2b5be, MONO_BEARISH=0xff5d606b;
    public static final ModuleDescriptor DESCRIPTOR = new ModuleDescriptor(
        "luxalgo.smc", "Smart Money Concepts [LuxAlgo]", "1.0.0", 4, Arrays.asList(
        section("sectionSmart", "Smart Money Concepts"),
        InputDefinition.choice("modeInput", "Mode", "Historical", "Historical", "Present"),
        InputDefinition.choice("styleInput", "Style", "Colored", "Colored", "Monochrome"),
        InputDefinition.bool("showTrendInput", "Color Candles", false),
        section("sectionInternal", "Real Time Internal Structure"),
        InputDefinition.bool("showInternalsInput", "Show Internal Structure", true),
        structure("showInternalBullInput", "Bullish Structure"),
        InputDefinition.color("internalBullColorInput", "Bullish Structure Color", GREEN),
        structure("showInternalBearInput", "Bearish Structure"),
        InputDefinition.color("internalBearColorInput", "Bearish Structure Color", RED),
        InputDefinition.bool("internalFilterConfluenceInput", "Confluence Filter", false),
        sizes("internalStructureSize", "Internal Label Size", "tiny"),
        section("sectionSwing", "Real Time Swing Structure"),
        InputDefinition.bool("showStructureInput", "Show Swing Structure", true),
        structure("showSwingBullInput", "Bullish Structure"),
        InputDefinition.color("swingBullColorInput", "Bullish Structure Color", GREEN),
        structure("showSwingBearInput", "Bearish Structure"),
        InputDefinition.color("swingBearColorInput", "Bearish Structure Color", RED),
        sizes("swingStructureSize", "Swing Label Size", "small"),
        InputDefinition.bool("showSwingsInput", "Show Swings Points", false),
        InputDefinition.integer("swingsLengthInput", "Swing Length", 50, 10, Integer.MAX_VALUE),
        InputDefinition.bool("showHighLowSwingsInput", "Show Strong/Weak High/Low", true),
        section("sectionBlocks", "Order Blocks"),
        InputDefinition.bool("showInternalOrderBlocksInput", "Internal Order Blocks", true),
        InputDefinition.integer("internalOrderBlocksSizeInput", "Internal Order Blocks Count", 5, 1, 20),
        InputDefinition.bool("showSwingOrderBlocksInput", "Swing Order Blocks", false),
        InputDefinition.integer("swingOrderBlocksSizeInput", "Swing Order Blocks Count", 5, 1, 20),
        InputDefinition.choice("orderBlockFilterInput", "Order Block Filter", "Atr", "Atr", "Cumulative Mean Range"),
        InputDefinition.choice("orderBlockMitigationInput", "Order Block Mitigation", "High/Low", "Close", "High/Low"),
        InputDefinition.color("internalBullishOrderBlockColor", "Internal Bullish OB", 0x333179f5),
        InputDefinition.color("internalBearishOrderBlockColor", "Internal Bearish OB", 0x33f77c80),
        InputDefinition.color("swingBullishOrderBlockColor", "Bullish OB", 0x331848cc),
        InputDefinition.color("swingBearishOrderBlockColor", "Bearish OB", 0x33b22833),
        section("sectionEqual", "EQH/EQL"),
        InputDefinition.bool("showEqualHighsLowsInput", "Equal High/Low", true),
        InputDefinition.integer("equalHighsLowsLengthInput", "Bars Confirmation", 3, 1, Integer.MAX_VALUE),
        InputDefinition.decimal("equalHighsLowsThresholdInput", "Threshold", 0.1, 0, 0.5),
        sizes("equalHighsLowsSizeInput", "Label Size", "tiny"),
        section("sectionGaps", "Fair Value Gaps"),
        InputDefinition.bool("showFairValueGapsInput", "Fair Value Gaps", false),
        InputDefinition.bool("fairValueGapsThresholdInput", "Auto Threshold", true),
        InputDefinition.choice("fairValueGapsTimeframeInput", "Timeframe", "Current", SmcMtf.timeframeChoices()),
        InputDefinition.color("fairValueGapsBullColorInput", "Bullish FVG", 0x4d00ff68),
        InputDefinition.color("fairValueGapsBearColorInput", "Bearish FVG", 0x4dff0008),
        InputDefinition.integer("fairValueGapsExtendInput", "Extend FVG", 1, 0, Integer.MAX_VALUE),
        section("sectionLevels", "Highs & Lows MTF"),
        InputDefinition.bool("showDailyLevelsInput", "Daily", false),
        styles("dailyLevelsStyleInput", "Daily Line Style"),
        InputDefinition.color("dailyLevelsColorInput", "Daily Color", BLUE),
        InputDefinition.bool("showWeeklyLevelsInput", "Weekly", false),
        styles("weeklyLevelsStyleInput", "Weekly Line Style"),
        InputDefinition.color("weeklyLevelsColorInput", "Weekly Color", BLUE),
        InputDefinition.bool("showMonthlyLevelsInput", "Monthly", false),
        styles("monthlyLevelsStyleInput", "Monthly Line Style"),
        InputDefinition.color("monthlyLevelsColorInput", "Monthly Color", BLUE),
        section("sectionZones", "Premium & Discount Zones"),
        InputDefinition.bool("showPremiumDiscountZonesInput", "Premium/Discount Zones", false),
        InputDefinition.color("premiumZoneColorInput", "Premium Zone", RED),
        InputDefinition.color("equilibriumZoneColorInput", "Equilibrium Zone", 0xff878b94),
        InputDefinition.color("discountZoneColorInput", "Discount Zone", GREEN)));

    private static InputDefinition section(String key,String title) { return InputDefinition.text(key,title,"════ " + title + " ════"); }
    private static InputDefinition structure(String key,String title) { return InputDefinition.choice(key,title,"All","All","BOS","CHoCH"); }
    private static InputDefinition sizes(String key,String title,String value) { return InputDefinition.choice(key,title,value,"tiny","small","normal"); }
    private static InputDefinition styles(String key,String title) { return InputDefinition.choice(key,title,"⎯⎯⎯","⎯⎯⎯","----","····"); }
    public static boolean b(Map<String,String> v,String key){ return Boolean.parseBoolean(v.get(key)); }
    public static int i(Map<String,String> v,String key){ return Integer.parseInt(v.get(key)); }
    public static double d(Map<String,String> v,String key){ return Double.parseDouble(v.get(key)); }
    public static int c(Map<String,String> v,String key){ return InputDefinition.parseColor(v.get(key)); }
    public static String s(Map<String,String> v,String key){ return v.get(key); }
    public static int size(String value){ return "tiny".equalsIgnoreCase(value)?8:"small".equalsIgnoreCase(value)?10:12; }
}
