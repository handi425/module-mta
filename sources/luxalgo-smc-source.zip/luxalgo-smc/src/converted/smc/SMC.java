// Smart Money Concepts [LuxAlgo], © LuxAlgo; independent Android conversion.
// CC BY-NC-SA 4.0 https://creativecommons.org/licenses/by-nc-sa/4.0/
// Original: https://www.tradingview.com/script/CnB3fSph-Smart-Money-Concepts-SMC-LuxAlgo/
// Changes: Java/Canvas port, broker history mapping, native inputs, all alerts removed.
package converted.smc;

import java.util.Map;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import net.metaquotes.metatrader5.modules.api.ChartData;
import net.metaquotes.metatrader5.modules.api.DeferredPlot;
import net.metaquotes.metatrader5.modules.api.HistoryIndicatorPlugin;
import net.metaquotes.metatrader5.modules.api.HistoryNotReadyException;
import net.metaquotes.metatrader5.modules.api.ModuleDescriptor;
import net.metaquotes.metatrader5.modules.api.ModuleEnvironment;
import net.metaquotes.metatrader5.modules.api.PlotFrame;

public final class SMC implements HistoryIndicatorPlugin {
    // One replay at a time bounds peak memory across attachments. A run yields
    // to the back of this queue, so a frequently ticking chart cannot starve others.
    private static final ThreadPoolExecutor WORKER=new ThreadPoolExecutor(1,1,30,TimeUnit.SECONDS,
        new ArrayBlockingQueue<Runnable>(32),new ThreadFactory(){
            public Thread newThread(Runnable task){Thread thread=new Thread(task,"SMC-calculation");thread.setDaemon(true);return thread;}
        },new ThreadPoolExecutor.AbortPolicy());
    static {WORKER.allowCoreThreadTimeOut(true);}
    private final Object lock=new Object();
    private final long[] stats=new long[8];
    private long generation;
    private boolean scheduled;
    private Request pending;
    private Cached cached;
    private final Runnable work=new Runnable(){public void run(){runOne();}};

    public ModuleDescriptor describe(){ return SmcInputs.DESCRIPTOR; }
    public int[] historyPeriods(Map<String,String> supplied){ return SmcMtf.historyPeriods(SmcInputs.DESCRIPTOR.normalizeInputs(supplied)); }
    public int historyBars(Map<String,String> supplied){ return 100000; }
    public void onChartUpdate(ModuleEnvironment environment,ChartData chart,Map<String,String> supplied)throws Exception {
        // ChartData and the host's parameter map are immutable snapshots. No
        // history copy, input normalization, hashing or replay belongs on main.
        submit(chart,supplied,environment.defer(chart));
    }
    public void onDetach(ModuleEnvironment environment,int chartId)throws Exception {
        cancel();environment.clear(chartId);
    }
    /** Read-only counters: requests, computations, cache hits, coalesced requests,
     * stale drops, last compute microseconds, total compute microseconds, maximum
     * compute microseconds. Timing covers replay/MTF, excluding cache comparison. */
    public long[] performanceStats(){synchronized(lock){return stats.clone();}}

    private void submit(ChartData chart,Map<String,String> supplied,DeferredPlot ticket){
        Request rejected=null;
        synchronized(lock){
            stats[0]++;
            if(pending!=null)stats[3]++;
            pending=new Request(chart,supplied,ticket,generation);
            if(!scheduled){
                scheduled=true;
                try{WORKER.execute(work);}catch(RejectedExecutionException busy){rejected=pending;pending=null;scheduled=false;}
            }
        }
        if(rejected!=null)busy(rejected);
    }
    private void cancel(){synchronized(lock){generation++;pending=null;cached=null;}}
    private void runOne(){
        Request request;
        synchronized(lock){request=pending;pending=null;}
        try{
            if(request!=null)process(request);
        }catch(Throwable failure){
            if(request!=null&&current(request))request.ticket.fail(failure);
        }finally{
            Request rejected=null;
            synchronized(lock){
                if(pending==null)scheduled=false;
                else try{WORKER.execute(work);}catch(RejectedExecutionException busy){rejected=pending;pending=null;scheduled=false;}
            }
            if(rejected!=null)busy(rejected);
        }
    }
    private void busy(Request request){
        // Saturation is retried on the next host update, never a permanent fault
        // and never a CallerRuns calculation on the chart thread.
        if(current(request))request.ticket.fail(new HistoryNotReadyException("SMC calculation queue is busy; retrying"));
    }
    private boolean current(Request request){
        boolean valid; synchronized(lock){valid=request.generation==generation;}
        if(valid)valid=request.ticket.isCurrent();
        if(!valid)synchronized(lock){stats[4]++;}
        return valid;
    }
    private void process(Request request){
        if(!current(request))return;
        Map<String,String> input=SmcInputs.DESCRIPTOR.normalizeInputs(request.supplied);
        int[] periods=SmcMtf.historyPeriods(input);
        long fingerprint=fingerprint(request.chart,periods);
        Cached previous;synchronized(lock){previous=cached;}
        PlotFrame result;
        if(previous!=null&&previous.fingerprint==fingerprint&&previous.input.equals(input)&&same(previous.chart,request.chart,periods)){
            result=previous.frame;synchronized(lock){stats[2]++;}
        }else{
            long started=System.nanoTime();synchronized(lock){stats[1]++;}
            try{result=calculate(request.chart,input);}
            finally{
                long micros=Math.max(0,(System.nanoTime()-started)/1000L);
                synchronized(lock){stats[5]=micros;stats[6]+=micros;stats[7]=Math.max(stats[7],micros);}
            }
        }
        if(!current(request))return;
        synchronized(lock){
            if(request.generation!=generation){stats[4]++;return;}
            cached=new Cached(request.chart,input,fingerprint,result);
        }
        request.ticket.publish(result); // The ticket dispatches/revalidates on main.
    }
    private static final class Request {
        final ChartData chart;final Map<String,String> supplied;final DeferredPlot ticket;final long generation;
        Request(ChartData chart,Map<String,String> supplied,DeferredPlot ticket,long generation){this.chart=chart;this.supplied=supplied;this.ticket=ticket;this.generation=generation;}
    }
    private static final class Cached {
        final ChartData chart;final Map<String,String> input;final long fingerprint;final PlotFrame frame;
        Cached(ChartData chart,Map<String,String> input,long fingerprint,PlotFrame frame){this.chart=chart;this.input=input;this.fingerprint=fingerprint;this.frame=frame;}
    }
    private static long fingerprint(ChartData chart,int[] periods){
        long hash=bars(0xcbf29ce484222325L,chart.closedBars);
        hash=mix(hash,chart.formingBar==null?0:1);
        if(chart.formingBar!=null)hash=bar(hash,chart.formingBar);
        for(int period:periods)if(period!=chart.period){hash=mix(hash,period);hash=bars(hash,chart.history(period));}
        return hash;
    }
    private static long bars(long hash,List<ChartData.Bar> bars){hash=mix(hash,bars.size());for(ChartData.Bar bar:bars)hash=bar(hash,bar);return hash;}
    private static long bar(long hash,ChartData.Bar bar){
        hash=mix(hash,bar.time);hash=mix(hash,Double.doubleToLongBits(bar.open));hash=mix(hash,Double.doubleToLongBits(bar.high));
        hash=mix(hash,Double.doubleToLongBits(bar.low));hash=mix(hash,Double.doubleToLongBits(bar.close));
        hash=mix(hash,bar.tickVolume);return mix(hash,bar.realVolume);
    }
    private static long mix(long hash,long value){return (hash^value)*0x100000001b3L;}
    private static boolean same(ChartData a,ChartData b,int[] periods){
        if(a.chartId!=b.chartId||a.period!=b.period||a.periodSeconds!=b.periodSeconds||!a.server.equals(b.server)||!a.symbol.equals(b.symbol)
            ||!sameBars(a.closedBars,b.closedBars)||!sameBar(a.formingBar,b.formingBar))return false;
        for(int period:periods)if(period!=b.period&&!sameBars(a.history(period),b.history(period)))return false;
        return true; // Fingerprints only reject; every hit is confirmed exactly.
    }
    private static boolean sameBars(List<ChartData.Bar> a,List<ChartData.Bar> b){
        if(a.size()!=b.size())return false;for(int i=0;i<a.size();i++)if(!sameBar(a.get(i),b.get(i)))return false;return true;
    }
    private static boolean sameBar(ChartData.Bar a,ChartData.Bar b){
        return a==b||a!=null&&b!=null&&a.time==b.time&&Double.doubleToLongBits(a.open)==Double.doubleToLongBits(b.open)
            &&Double.doubleToLongBits(a.high)==Double.doubleToLongBits(b.high)&&Double.doubleToLongBits(a.low)==Double.doubleToLongBits(b.low)
            &&Double.doubleToLongBits(a.close)==Double.doubleToLongBits(b.close)&&a.tickVolume==b.tickVolume&&a.realVolume==b.realVolume;
    }
    public static PlotFrame frame(ChartData chart,Map<String,String> supplied){
        Map<String,String> input=SmcInputs.DESCRIPTOR.normalizeInputs(supplied);
        return calculate(chart,input);
    }
    private static PlotFrame calculate(ChartData chart,Map<String,String> input){
        PlotFrame frame=SmcCore.calculate(chart,input);
        SmcMtf.append(frame,chart,input);
        return frame;
    }
}
