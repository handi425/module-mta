// Smart Money Concepts [LuxAlgo], © LuxAlgo; independent Android conversion.
// CC BY-NC-SA 4.0 https://creativecommons.org/licenses/by-nc-sa/4.0/
// Original: https://www.tradingview.com/script/CnB3fSph-Smart-Money-Concepts-SMC-LuxAlgo/
// Changes: Java/Canvas port, broker history mapping, native inputs, all alerts removed.
package converted.smc;

import java.util.Map;
import net.metaquotes.metatrader5.modules.api.ChartData;
import net.metaquotes.metatrader5.modules.api.HistoryIndicatorPlugin;
import net.metaquotes.metatrader5.modules.api.ModuleDescriptor;
import net.metaquotes.metatrader5.modules.api.ModuleEnvironment;
import net.metaquotes.metatrader5.modules.api.PlotFrame;

public final class SMC implements HistoryIndicatorPlugin {
    public ModuleDescriptor describe(){ return SmcInputs.DESCRIPTOR; }
    public int[] historyPeriods(Map<String,String> supplied){ return SmcMtf.historyPeriods(SmcInputs.DESCRIPTOR.normalizeInputs(supplied)); }
    public int historyBars(Map<String,String> supplied){ return 100000; }
    public void onChartUpdate(ModuleEnvironment environment,ChartData chart,Map<String,String> supplied)throws Exception {
        environment.publish(chart.chartId,frame(chart,supplied));
    }
    public void onDetach(ModuleEnvironment environment,int chartId)throws Exception { environment.clear(chartId); }
    public static PlotFrame frame(ChartData chart,Map<String,String> supplied){
        Map<String,String> input=SmcInputs.DESCRIPTOR.normalizeInputs(supplied);
        PlotFrame frame=SmcCore.calculate(chart,input);
        SmcMtf.append(frame,chart,input);
        return frame;
    }
}
