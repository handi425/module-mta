Smart Money Concepts [LuxAlgo] - independent Android conversion
Copyright (c) LuxAlgo. CC BY-NC-SA 4.0.
https://creativecommons.org/licenses/by-nc-sa/4.0/

Original:
https://www.tradingview.com/script/CnB3fSph-Smart-Money-Concepts-SMC-LuxAlgo/

Converted source, original Pine source, tests, provenance and license:
https://github.com/handi425/module-mta/blob/main/sources/luxalgo-smc-source.zip

Module version: 1.0.2.
Changes: Java/Canvas conversion, native parameter controls and MT5 broker
history mapping. All alert/notification declarations are removed from the
executable port. No trading/order functionality. Drawings remain anchored to
source candle times and prices, without native chart objects or touch controls.
OB/FVG fill alpha is capped at0x26 (about15% opacity), preserving original RGB
and any lower opacity; border RGB/alpha and premium/discount zones are unchanged.
Strong/weak and MTF line endpoints and labels use the latest real chart candle,
replacing the original20-bar future offset; labels never follow viewport edges.

Requires custom MetaTrader 5 module API5, APK6316 / 500.6310-mtc.6 or later.
The host retains the replacement-layer cleanup fix introduced in APK6315.
Calculation runs on a bounded background worker, coalesces pending requests
and reuses unchanged OHLCV/input snapshots. The host rejects stale results and
culls offscreen geometry. Signal rules and full-history calculations remain;
history is not trimmed to obtain speed.
The official MetaTrader 5 mobile app does not load these converted modules.
No general Pine Script or MQL5 interpreter is included.

Noncommercial use and redistribution only under the license above.
Not endorsed by LuxAlgo or MetaQuotes.
