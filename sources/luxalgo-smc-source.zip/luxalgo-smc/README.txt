Smart Money Concepts [LuxAlgo] - independent Android conversion
Copyright (c) LuxAlgo. CC BY-NC-SA 4.0.
https://creativecommons.org/licenses/by-nc-sa/4.0/

Original:
https://www.tradingview.com/script/CnB3fSph-Smart-Money-Concepts-SMC-LuxAlgo/

Converted source, original Pine source, tests, provenance and license:
https://github.com/handi425/module-mta/blob/main/sources/luxalgo-smc-source.zip

Changes: Java/Canvas conversion, native parameter controls and MT5 broker
history mapping. All alert/notification declarations are removed from the
executable port. No trading/order functionality. Drawings remain anchored to
source candle times and prices, without native chart objects or touch controls.

Requires custom MetaTrader 5 APK6314 or later with module API4.
The official MetaTrader 5 mobile app does not load these converted modules.
No general Pine Script or MQL5 interpreter is included.

Noncommercial use and redistribution only under the license above.
Not endorsed by LuxAlgo or MetaQuotes.
